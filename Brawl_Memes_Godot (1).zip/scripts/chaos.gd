extends "res://scripts/base_fps.gd"
# MEME CHAOS: individual survival in a ridiculous arena. No weapons. Opponents are AI bots.

const BOT_NAMES: Array = ["Доге", "Кот", "Панда", "Троллфейс", "Банан", "Скелет", "Сус"]
const BOT_TEX: Array = ["a03", "a04", "a05", "a01", "a12", "a14", "a11"]

var kit = null
var hp: float = 100.0
var max_hp: float = 100.0
var alive_player: bool = true
var state: String = "countdown"
var cd: float = 4.0
var cd_last: int = 99
var round_t: float = 0.0
var survive_t: float = 0.0
var place: int = 0
var bots: Array = []
var hazards: Array = []
var warnings: Array = []
var bumpers: Array = []
var pads: Array = []
var event_cd: float = 3.0
var low_g_t: float = 0.0
var wind_t: float = 0.0
var wind_v: Vector3 = Vector3.ZERO
var shake: float = 0.0
var hurt_t: float = 0.0
var bump_cd: float = 0.0
var spin_node: Node3D = null
var end_t: float = 0.0
var won: bool = false
var winner_name: String = ""
var recorded: bool = false

func setup(m: String) -> void:
	mode = m
	vp = get_viewport().get_visible_rect().size
	base_speed = 5.6
	_build_world()
	_make_player(Vector3(0, 0.6, 24), 0.0)
	_make_base_hud()
	(btn_panels["interact"] as Panel).visible = false
	_spawn_bots()
	locked = true
	banner("РАУНД СКОРО НАЧНЁТСЯ!", Color("55eeff"), 1.4)

# ---------- world ----------
func _build_world() -> void:
	kit = Node3D.new()
	kit.set_script(load("res://scripts/village.gd"))
	add_child(kit)
	var we: WorldEnvironment = WorldEnvironment.new()
	var env: Environment = Environment.new()
	var sky: Sky = Sky.new()
	var sm: ProceduralSkyMaterial = ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.55, 0.3, 0.95)
	sm.sky_horizon_color = Color(1.0, 0.7, 0.85)
	sm.ground_horizon_color = Color(1.0, 0.7, 0.85)
	sm.ground_bottom_color = Color(0.3, 0.15, 0.5)
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 1.1
	we.environment = env
	add_child(we)
	var sun: DirectionalLight3D = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55.0, 30.0, 0.0)
	sun.light_energy = 1.0
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 80.0
	add_child(sun)
	var pl: StaticBody3D = kit.body_at(Vector3.ZERO)
	kit.add_box(pl, Vector3(0, -0.5, 0), Vector3(70, 1, 70), kit.mat("rainbow", Color.WHITE, 0.14))
	kit.add_col(pl, Vector3(0, -0.5, 0), Vector3(70, 1, 70))
	var rim: Material = kit.cmat(Color(1.0, 0.25, 0.55))
	kit.add_box(self, Vector3(0, 0.1, 34.75), Vector3(70, 0.2, 0.5), rim)
	kit.add_box(self, Vector3(0, 0.1, -34.75), Vector3(70, 0.2, 0.5), rim)
	kit.add_box(self, Vector3(34.75, 0.1, 0), Vector3(0.5, 0.2, 70), rim)
	kit.add_box(self, Vector3(-34.75, 0.1, 0), Vector3(0.5, 0.2, 70), rim)
	for p in [Vector3(-14, 0, -10), Vector3(14, 0, -12), Vector3(-18, 0, 12), Vector3(18, 0, 8), Vector3(0, 0, -20), Vector3(0, 0, 14)]:
		_bumper(p)
	for p in [Vector3(-8, 0, 0), Vector3(8, 0, 0), Vector3(0, 0, 26)]:
		_pad(p)
	spin_node = Node3D.new()
	spin_node.position = Vector3(0, 0.4, -2)
	add_child(spin_node)
	kit.add_box(spin_node, Vector3.ZERO, Vector3(20, 0.8, 0.8), kit.cmat(Color(1.0, 0.6, 0.1)))
	kit.add_box(spin_node, Vector3(5, 0.45, 0), Vector3(2, 0.1, 0.9), kit.cmat(Color(1, 1, 1)))
	kit.add_box(spin_node, Vector3(-5, 0.45, 0), Vector3(2, 0.1, 0.9), kit.cmat(Color(1, 1, 1)))
	kit.add_cyl(spin_node, Vector3(0, 0.2, 0), 1.0, 1.0, 1.2, kit.cmat(Color(0.2, 0.2, 0.3)), 14)
	var cols: Array = [Color(1, 0.4, 0.6), Color(0.3, 0.8, 1.0), Color(1, 0.85, 0.2), Color(0.5, 1.0, 0.5), Color(0.8, 0.5, 1.0)]
	for i in 10:
		var a: float = float(i) * TAU / 10.0
		var d: TorusMesh = TorusMesh.new()
		d.inner_radius = 3.0
		d.outer_radius = 6.5
		var mi: MeshInstance3D = MeshInstance3D.new()
		mi.mesh = d
		mi.material_override = kit.cmat(cols[i % 5])
		mi.position = Vector3(cos(a) * 85.0, 8.0 + float(i % 3) * 8.0, sin(a) * 85.0)
		mi.rotation_degrees = Vector3(70, float(i) * 30.0, 0)
		add_child(mi)
	for i in 14:
		var a2: float = float(i) * TAU / 14.0 + 0.2
		var rr: float = 48.0 + float(i % 3) * 8.0
		var bp: Vector3 = Vector3(cos(a2) * rr, 5.0 + float(i % 4) * 3.0, sin(a2) * rr)
		kit.add_sphere(self, bp, 2.2, kit.cmat(cols[i % 5]), Vector3(1.0, 1.25, 1.0))
		kit.add_cyl(self, bp + Vector3(0, -4.0, 0), 0.03, 0.03, 5.0, kit.cmat(Color(0.9, 0.9, 0.9)), 4)
	for c in [Vector3(-34, 0, -34), Vector3(34, 0, -34), Vector3(-34, 0, 34), Vector3(34, 0, 34)]:
		kit.add_cyl(self, c + Vector3(0, 4.0, 0), 1.4, 1.6, 8.0, kit.cmat(Color(1.0, 0.85, 0.2)), 12)
		kit.add_sphere(self, c + Vector3(0, 8.6, 0), 1.7, kit.cmat(Color(1.0, 0.3, 0.5)))

func _bumper(p: Vector3) -> void:
	var b: StaticBody3D = kit.body_at(p)
	kit.add_cyl(b, Vector3(0, 0.8, 0), 1.3, 1.5, 1.6, kit.cmat(Color(1.0, 0.3, 0.6)), 16)
	kit.add_cyl(b, Vector3(0, 1.65, 0), 1.3, 1.3, 0.12, kit.cmat(Color(1.0, 0.9, 0.2)), 16)
	kit.add_cyl_col(b, Vector3(0, 0.8, 0), 1.4, 1.6)
	bumpers.append(p)

func _pad(p: Vector3) -> void:
	var mi: MeshInstance3D = kit.add_cyl(self, p + Vector3(0, 0.04, 0), 1.6, 1.6, 0.08, kit.cmat(Color(0.2, 1.0, 0.4), true), 20)
	mi.name = "pad"
	kit.add_box(self, p + Vector3(0, 0.1, 0), Vector3(0.5, 0.05, 1.2), kit.cmat(Color(1, 1, 1), true))
	pads.append(p)

func _spawn_bots() -> void:
	for i in BOT_NAMES.size():
		var a: float = float(i) * TAU / float(BOT_NAMES.size())
		var n: Node3D = Node3D.new()
		n.position = Vector3(cos(a) * 20.0, 0.0, sin(a) * 20.0)
		var spr: Sprite3D = Sprite3D.new()
		spr.texture = load("res://assets/stickers/%s.png" % BOT_TEX[i])
		spr.pixel_size = 0.0085
		spr.billboard = BaseMaterial3D.BILLBOARD_FIXED_Y
		spr.shaded = false
		spr.double_sided = true
		spr.alpha_cut = SpriteBase3D.ALPHA_CUT_OPAQUE_PREPASS
		spr.position = Vector3(0, 1.1, 0)
		n.add_child(spr)
		var lb: Label3D = Label3D.new()
		lb.text = BOT_NAMES[i]
		lb.font_size = 40
		lb.pixel_size = 0.008
		lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		lb.outline_size = 10
		lb.position = Vector3(0, 2.5, 0)
		n.add_child(lb)
		add_child(n)
		bots.append({"n": n, "name": BOT_NAMES[i], "hp": 100.0, "alive": true, "kv": Vector3.ZERO, "vy": 0.0, "tg": n.position, "tcd": randf_range(0.5, 2.0), "spd": 4.2 + randf() * 1.6, "skill": 0.45 + randf() * 0.5})

# ---------- helpers ----------
func _alive_bots() -> int:
	var c: int = 0
	for b in bots:
		if b["alive"]:
			c += 1
	return c

func _rand_target() -> Vector3:
	var cands: Array = []
	if alive_player:
		cands.append(player.global_position)
		cands.append(player.global_position)
	for b in bots:
		if b["alive"]:
			cands.append((b["n"] as Node3D).position)
	if cands.is_empty():
		return Vector3.ZERO
	return cands[randi() % cands.size()]

func _clampp(v: Vector3, lim: float) -> Vector3:
	return Vector3(clampf(v.x, -lim, lim), v.y, clampf(v.z, -lim, lim))

func _mat_unshaded(col: Color, alpha: bool = false) -> StandardMaterial3D:
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = col
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	if alpha:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return m

func _warn_disc(p: Vector3, r: float, dur: float) -> void:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var c: CylinderMesh = CylinderMesh.new()
	c.top_radius = r
	c.bottom_radius = r
	c.height = 0.05
	c.radial_segments = 28
	mi.mesh = c
	mi.material_override = _mat_unshaded(Color(1.0, 0.1, 0.1, 0.4), true)
	add_child(mi)
	mi.position = Vector3(p.x, 0.05, p.z)
	var tw: Tween = create_tween()
	tw.tween_interval(dur)
	tw.tween_callback(mi.queue_free)
	warnings.append({"p": p, "r": r, "until": round_t + dur})

func _warn_strip(horiz: bool, off: float, width: float, dur: float) -> void:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var bm: BoxMesh = BoxMesh.new()
	bm.size = Vector3(110.0, 0.05, width) if horiz else Vector3(width, 0.05, 110.0)
	mi.mesh = bm
	mi.material_override = _mat_unshaded(Color(1.0, 0.15, 0.1, 0.3), true)
	add_child(mi)
	mi.position = Vector3(0, 0.06, off) if horiz else Vector3(off, 0.06, 0)
	var tw: Tween = create_tween()
	tw.tween_interval(dur)
	tw.tween_callback(mi.queue_free)

func _fx_explosion(p: Vector3, r: float, col: Color) -> void:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var sm: SphereMesh = SphereMesh.new()
	sm.radius = 1.0
	sm.height = 2.0
	mi.mesh = sm
	var m: StandardMaterial3D = _mat_unshaded(Color(col.r, col.g, col.b, 0.8), true)
	mi.material_override = m
	add_child(mi)
	mi.position = p
	mi.scale = Vector3(0.3, 0.3, 0.3)
	var tw: Tween = create_tween()
	tw.tween_property(mi, "scale", Vector3(r, r, r), 0.3)
	tw.parallel().tween_property(m, "albedo_color:a", 0.0, 0.45)
	tw.tween_callback(mi.queue_free)

func _blast(p: Vector3, r: float, dmg: float, knock: float) -> void:
	_fx_explosion(Vector3(p.x, 0.6, p.z), r, Color(1.0, 0.55, 0.15))
	if alive_player:
		var pp: Vector3 = player.global_position
		var d: Vector3 = Vector3(pp.x - p.x, 0, pp.z - p.z)
		if d.length() < r and pp.y < 3.5:
			_hurt_player(dmg * (1.0 - 0.5 * d.length() / r), d.normalized() * knock)
	for b in bots:
		if not b["alive"]:
			continue
		var bp: Vector3 = (b["n"] as Node3D).position
		var d2: Vector3 = Vector3(bp.x - p.x, 0, bp.z - p.z)
		if d2.length() < r:
			_hurt_bot(b, dmg * (1.0 - 0.5 * d2.length() / r), d2.normalized() * knock)

# ---------- damage / elimination ----------
func _hurt_player(a: float, kb: Vector3) -> void:
	if not alive_player or over:
		return
	hp -= a
	push += Vector3(kb.x, 0, kb.z)
	boost_y = maxf(boost_y, minf(5.0, kb.length() * 0.25))
	hurt_t = 0.4
	shake = maxf(shake, 0.5)
	Game.vibrate(60)
	if hp <= 0.0:
		hp = 0.0
		_eliminate_player("раздавлен")

func _hurt_bot(b: Dictionary, a: float, kb: Vector3) -> void:
	if not b["alive"]:
		return
	b["hp"] = float(b["hp"]) - a
	b["kv"] = (b["kv"] as Vector3) + Vector3(kb.x, 0, kb.z)
	if float(b["hp"]) <= 0.0:
		_eliminate_bot(b, "раздавлен")

func _eliminate_bot(b: Dictionary, why: String) -> void:
	if not b["alive"]:
		return
	b["alive"] = false
	var n: Node3D = b["n"]
	_fx_explosion(n.position + Vector3(0, 1.0, 0), 2.0, Color(1, 1, 0.5))
	n.visible = false
	toast("%s выбыл (%s)! Осталось: %d" % [b["name"], why, _alive_bots() + (1 if alive_player else 0)])

func _eliminate_player(why: String) -> void:
	if not alive_player:
		return
	alive_player = false
	place = 1 + _alive_bots()
	survive_t = round_t
	fly = true
	player.collision_mask = 0
	player.position = Vector3(player.position.x, 14.0, player.position.z)
	vel_y = 0.0
	banner("ТЫ ВЫБЫЛ (%s)!\nТвоё место: %d. Режим зрителя" % [why, place], Color("ff6666"), 3.0)
	Game.vibrate(200)

# ---------- events ----------
func _trigger_event() -> void:
	var pool: Array = ["toilet", "banana", "sofa", "fridge", "boom", "potato"]
	if round_t > 20.0:
		pool.append_array(["walls", "lowg", "wind"])
	var ev: String = pool[randi() % pool.size()]
	var cnt: int = 3 + int(round_t / 30.0)
	if ev == "toilet":
		banner("ВНИМАНИЕ!\nГИГАНТСКИЕ УНИТАЗЫ С НЕБА!", Color("ffffff"))
		for i in cnt:
			_spawn_drop("toilet", _rand_target(), 1.3 + 0.35 * float(i))
	elif ev == "fridge":
		banner("ХОЛОДИЛЬНИКИ ПАДАЮТ!", Color("9fe8ff"))
		for i in cnt:
			_spawn_drop("fridge", _rand_target(), 1.3 + 0.35 * float(i))
	elif ev == "banana":
		banner("ВЗРЫВНЫЕ БАНАНЫ!", Color("ffe94a"))
		_spawn_bananas(_rand_target())
	elif ev == "sofa":
		banner("ЛЕТЯЩИЕ ДИВАНЫ!", Color("ff7aa8"))
		for i in 2 + int(round_t / 40.0):
			_spawn_mover("sofa", randf() < 0.5, randf_range(-26.0, 26.0), 1.0 if randf() < 0.5 else -1.0, 1.6 + 0.5 * float(i))
	elif ev == "potato":
		banner("ГИГАНТСКАЯ КАРТОШКА КАТИТСЯ!", Color("ffcf8a"))
		for i in 1 + int(round_t / 60.0):
			_spawn_mover("potato", randf() < 0.5, randf_range(-24.0, 24.0), 1.0 if randf() < 0.5 else -1.0, 1.8 + 0.8 * float(i))
	elif ev == "boom":
		banner("СЛУЧАЙНЫЕ ВЗРЫВЫ!", Color("ff9a3a"))
		for i in cnt + 1:
			_spawn_boom(_rand_target() + Vector3(randf_range(-4, 4), 0, randf_range(-4, 4)), 1.4 + 0.3 * float(i))
	elif ev == "walls":
		banner("ДВИЖУЩИЕСЯ СТЕНЫ!\nПРЫГАЙ!", Color("fff06a"))
		var horiz: bool = randf() < 0.5
		_spawn_mover("wall", horiz, 0.0, 1.0, 1.8)
		_spawn_mover("wall", horiz, 12.0, -1.0, 2.4)
		_spawn_mover("wall", horiz, -12.0, 1.0, 3.0)
	elif ev == "lowg":
		banner("ЛУННАЯ ГРАВИТАЦИЯ!", Color("a8c8ff"))
		low_g_t = 10.0
	elif ev == "wind":
		banner("СИЛЬНЫЙ ВЕТЕР!\nДЕРЖИСЬ ПОДАЛЬШЕ ОТ КРАЯ!", Color("c8ffd8"))
		wind_t = 8.0
		var a: float = randf() * TAU
		wind_v = Vector3(cos(a), 0, sin(a)) * 4.5

func _spawn_drop(kind: String, target: Vector3, warn: float) -> void:
	var p: Vector3 = _clampp(Vector3(target.x + randf_range(-3, 3), 0, target.z + randf_range(-3, 3)), 33.0)
	var rad: float = 3.6 if kind == "toilet" else 2.8
	_warn_disc(p, rad, warn)
	var n: Node3D = _make_toilet() if kind == "toilet" else _make_fridge()
	n.position = Vector3(p.x, 40.0, p.z)
	add_child(n)
	hazards.append({"type": "drop", "n": n, "p": p, "vy": 0.0, "warn": warn, "rad": rad, "dmg": 55.0 if kind == "toilet" else 60.0, "knock": 14.0})

func _spawn_bananas(center: Vector3) -> void:
	for i in 5:
		var p: Vector3 = _clampp(Vector3(center.x + randf_range(-9, 9), 0, center.z + randf_range(-9, 9)), 32.0)
		var tm: float = 2.0 + randf() * 1.2
		_warn_disc(p, 5.5, tm)
		var n: Node3D = _make_banana()
		n.position = Vector3(p.x, 0.25, p.z)
		add_child(n)
		hazards.append({"type": "banana", "n": n, "p": p, "timer": tm})

func _spawn_boom(p0: Vector3, tm: float) -> void:
	var p: Vector3 = _clampp(p0, 33.0)
	_warn_disc(p, 4.2, tm)
	hazards.append({"type": "boom", "p": p, "timer": tm})

func _spawn_mover(kind: String, horiz: bool, off: float, sgn: float, delay: float) -> void:
	var start: Vector3
	var dirv: Vector3
	if horiz:
		start = Vector3(-sgn * 52.0, 0, off)
		dirv = Vector3(sgn, 0, 0)
	else:
		start = Vector3(off, 0, -sgn * 52.0)
		dirv = Vector3(0, 0, sgn)
	var n: Node3D = Node3D.new()
	var half_along: float = 1.8
	var half_perp: float = 1.8
	var dmg: float = 35.0
	var knock: float = 15.0
	var ymin: float = 0.0
	var ymax: float = 2.4
	var yc: float = 0.9
	var spd: float = 15.0
	var bob: float = 0.25
	var mesh: Node3D = null
	if kind == "sofa":
		_build_sofa(n, horiz)
	elif kind == "potato":
		mesh = _build_potato(n)
		half_along = 2.6
		half_perp = 2.6
		dmg = 45.0
		knock = 17.0
		ymax = 4.5
		yc = 2.0
		spd = 11.0
		bob = 0.0
	else:
		_build_wall(n, horiz)
		half_along = 0.7
		half_perp = 7.0
		dmg = 25.0
		knock = 12.0
		ymax = 0.8
		yc = 0.0
		spd = 9.0
		bob = 0.0
	n.position = Vector3(start.x, yc, start.z)
	add_child(n)
	_warn_strip(horiz, off, half_perp * 2.0, delay)
	hazards.append({"type": "mover", "kind": kind, "n": n, "mesh": mesh, "pos": start, "dir": dirv, "speed": spd, "delay": delay, "y": yc, "bob": bob, "ph": randf() * 6.0,
		"horiz": horiz, "hx": half_along if horiz else half_perp, "hz": half_perp if horiz else half_along,
		"dmg": dmg, "knock": knock, "ymin": ymin, "ymax": ymax, "hits": []})

# ---------- object builders ----------
func _build_sofa(n: Node3D, horiz: bool) -> void:
	var cols: Array = [Color(1, 0.4, 0.6), Color(0.3, 0.8, 1.0), Color(1, 0.6, 0.2), Color(0.5, 0.9, 0.4)]
	var c: Color = cols[randi() % 4]
	var root: Node3D = Node3D.new()
	root.rotation_degrees = Vector3(0, 0 if horiz else 90, 0)
	n.add_child(root)
	kit.add_box(root, Vector3(0, 0, 0), Vector3(2.6, 0.55, 1.1), kit.cmat(c))
	kit.add_box(root, Vector3(0, 0.55, -0.45), Vector3(2.6, 0.9, 0.25), kit.cmat(c.darkened(0.15)))
	kit.add_box(root, Vector3(-1.3, 0.25, 0), Vector3(0.3, 0.85, 1.1), kit.cmat(c.darkened(0.2)))
	kit.add_box(root, Vector3(1.3, 0.25, 0), Vector3(0.3, 0.85, 1.1), kit.cmat(c.darkened(0.2)))
	kit.add_box(root, Vector3(-0.6, 0.35, 0.1), Vector3(1.0, 0.2, 0.8), kit.cmat(c.lightened(0.25)))
	kit.add_box(root, Vector3(0.6, 0.35, 0.1), Vector3(1.0, 0.2, 0.8), kit.cmat(c.lightened(0.25)))

func _build_potato(n: Node3D) -> Node3D:
	var mesh: Node3D = Node3D.new()
	n.add_child(mesh)
	kit.add_sphere(mesh, Vector3.ZERO, 2.2, kit.cmat(Color(0.75, 0.57, 0.32)), Vector3(1.2, 0.9, 1.0))
	for i in 9:
		var dv: Vector3 = Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)).normalized()
		kit.add_sphere(mesh, Vector3(dv.x * 2.6, dv.y * 2.0, dv.z * 2.2), 0.28, kit.cmat(Color(0.35, 0.22, 0.1)))
	return mesh

func _build_wall(n: Node3D, horiz: bool) -> void:
	var size: Vector3 = Vector3(0.8, 0.7, 14.0) if horiz else Vector3(14.0, 0.7, 0.8)
	kit.add_box(n, Vector3(0, 0.35, 0), size, kit.cmat(Color(1.0, 0.85, 0.1)))
	for i in 6:
		var off: float = -6.0 + float(i) * 2.4
		var sz: Vector3 = Vector3(0.82, 0.72, 1.0) if horiz else Vector3(1.0, 0.72, 0.82)
		var pos: Vector3 = Vector3(0, 0.35, off) if horiz else Vector3(off, 0.35, 0)
		kit.add_box(n, pos, sz, kit.cmat(Color(0.1, 0.1, 0.1)))

func _make_toilet() -> Node3D:
	var n: Node3D = Node3D.new()
	var w: Material = kit.cmat(Color(0.97, 0.97, 1.0))
	kit.add_cyl(n, Vector3(0, 0.25, 0), 0.3, 0.25, 0.5, w, 12)
	kit.add_cyl(n, Vector3(0, 0.65, 0.1), 0.55, 0.4, 0.4, w, 14)
	kit.add_cyl(n, Vector3(0, 0.87, 0.1), 0.55, 0.55, 0.07, kit.cmat(Color(0.3, 0.55, 1.0)), 14)
	kit.add_box(n, Vector3(0, 1.0, -0.5), Vector3(0.8, 0.9, 0.35), w)
	kit.add_sphere(n, Vector3(0.3, 1.5, -0.5), 0.07, kit.cmat(Color(1, 0.85, 0.2)))
	n.scale = Vector3(2.2, 2.2, 2.2)
	return n

func _make_fridge() -> Node3D:
	var n: Node3D = Node3D.new()
	kit.add_box(n, Vector3(0, 1.4, 0), Vector3(1.5, 2.8, 1.4), kit.cmat(Color(0.95, 0.97, 1.0)))
	kit.add_box(n, Vector3(0, 1.9, 0.71), Vector3(1.5, 0.05, 0.02), kit.cmat(Color(0.5, 0.5, 0.55)))
	kit.add_box(n, Vector3(0.55, 2.3, 0.75), Vector3(0.07, 0.7, 0.07), kit.cmat(Color(0.6, 0.6, 0.65)))
	kit.add_box(n, Vector3(0.55, 1.3, 0.75), Vector3(0.07, 0.9, 0.07), kit.cmat(Color(0.6, 0.6, 0.65)))
	return n

func _make_banana() -> Node3D:
	var n: Node3D = Node3D.new()
	var y: Material = kit.cmat(Color(1.0, 0.88, 0.1))
	var c1: MeshInstance3D = MeshInstance3D.new()
	var cm: CapsuleMesh = CapsuleMesh.new()
	cm.radius = 0.24
	cm.height = 1.2
	c1.mesh = cm
	c1.material_override = y
	c1.rotation_degrees = Vector3(0, 0, 90)
	c1.position = Vector3(-0.3, 0, 0)
	n.add_child(c1)
	var c2: MeshInstance3D = MeshInstance3D.new()
	c2.mesh = cm
	c2.material_override = y
	c2.rotation_degrees = Vector3(0, 35, 90)
	c2.position = Vector3(0.45, 0, -0.2)
	n.add_child(c2)
	kit.add_sphere(n, Vector3(-0.95, 0, 0), 0.12, kit.cmat(Color(0.4, 0.25, 0.1)))
	return n

# ---------- main tick ----------
func _update_info() -> void:
	var alive_n: int = _alive_bots() + (1 if alive_player else 0)
	if alive_player:
		info_l.text = "Осталось: %d из 8  |  Время: %d с  |  HP %d" % [alive_n, int(round_t), int(hp)]
	else:
		info_l.text = "РЕЖИМ ЗРИТЕЛЯ  |  Осталось: %d  |  Твоё место: %d" % [alive_n, place]

func _hud_extra() -> void:
	if alive_player:
		hud.draw_rect(Rect2(24, 56, 320, 26), Color(0, 0, 0, 0.6))
		hud.draw_rect(Rect2(28, 60, 312.0 * clampf(hp / max_hp, 0.0, 1.0), 18), Color("44ee66"))
	if hurt_t > 0.0:
		hud.draw_rect(Rect2(Vector2.ZERO, vp), Color(1, 0, 0, minf(0.4, hurt_t)))
	if low_g_t > 0.0:
		hud.draw_rect(Rect2(Vector2.ZERO, vp), Color(0.3, 0.5, 1.0, 0.08))

func _tick(delta: float) -> void:
	hurt_t = maxf(0.0, hurt_t - delta)
	_update_info()
	if state == "countdown":
		cd -= delta
		var sn: int = int(ceil(cd)) - 1
		if sn != cd_last:
			cd_last = sn
			if sn >= 1:
				banner(str(sn), Color("ffffff"), 0.6)
			elif sn == 0:
				banner("ПОЕХАЛИ!", Color("55ff88"), 0.8)
		if cd <= 0.0:
			state = "play"
			locked = false
			event_cd = 2.5
		_update_bots(delta)
		return
	round_t += delta
	spin_node.rotation.y += delta * (0.9 + minf(round_t / 120.0, 1.0))
	gravity_scale = 0.35 if (low_g_t > 0.0 and alive_player) else 1.0
	low_g_t = maxf(0.0, low_g_t - delta)
	if wind_t > 0.0:
		wind_t -= delta
		if alive_player:
			push += wind_v * delta * 2.0
			if push.length() > 7.0:
				push = push.normalized() * 7.0
	var keep_w: Array = []
	for w in warnings:
		if float(w["until"]) > round_t:
			keep_w.append(w)
	warnings = keep_w
	if state == "play":
		event_cd -= delta
		if event_cd <= 0.0:
			_trigger_event()
			event_cd = maxf(1.2 if round_t > 120.0 else 2.2, 6.0 - round_t * 0.04)
	_update_hazards(delta)
	_update_bots(delta)
	_player_interactions(delta)
	# camera shake
	if alive_player:
		if shake > 0.0:
			cam.position = Vector3(randf_range(-1.0, 1.0) * shake * 0.12, 1.6 + randf_range(-1.0, 1.0) * shake * 0.08, 0.0)
			shake = maxf(0.0, shake - delta * 1.5)
		else:
			cam.position = Vector3(0, 1.6, 0)
	if state == "play":
		_check_end()
	elif state == "ended":
		end_t -= delta
		if end_t <= 0.0:
			_finish_rewards(won)

func _player_interactions(delta: float) -> void:
	bump_cd = maxf(0.0, bump_cd - delta)
	if not alive_player:
		return
	var pp: Vector3 = player.global_position
	for bp in bumpers:
		var d: Vector3 = Vector3(pp.x - bp.x, 0, pp.z - bp.z)
		if d.length() < 1.95 and pp.y < 1.8 and bump_cd <= 0.0:
			push = d.normalized() * 13.0
			boost_y = 4.0
			bump_cd = 0.4
			Game.click()
	for pd in pads:
		if Vector2(pp.x - pd.x, pp.z - pd.z).length() < 1.6 and player.is_on_floor():
			boost_y = 13.0
			Game.click()
	# spinner
	var rel: Vector3 = (pp - spin_node.position).rotated(Vector3.UP, -spin_node.rotation.y)
	if absf(rel.x) < 10.0 and absf(rel.z) < 0.9 and pp.y < 0.85:
		var side: float = 1.0 if rel.z >= 0.0 else -1.0
		var kdir: Vector3 = Vector3(0, 0, side).rotated(Vector3.UP, spin_node.rotation.y)
		_hurt_player(12.0, kdir * 13.0)
	if pp.y < -6.0:
		_eliminate_player("упал с арены")

func _update_hazards(delta: float) -> void:
	var keep: Array = []
	for h in hazards:
		var typ: String = h["type"]
		var done: bool = false
		if typ == "drop":
			h["warn"] = float(h["warn"]) - delta
			if float(h["warn"]) <= 0.0:
				h["vy"] = float(h["vy"]) - 40.0 * delta
				var n: Node3D = h["n"]
				n.position.y += float(h["vy"]) * delta
				if n.position.y <= 0.0:
					n.position.y = 0.0
					_blast(h["p"], float(h["rad"]), float(h["dmg"]), float(h["knock"]))
					shake = maxf(shake, 0.8)
					done = true
					var tw: Tween = create_tween()
					tw.tween_interval(1.5)
					tw.tween_property(n, "scale", Vector3(0.01, 0.01, 0.01), 0.3)
					tw.tween_callback(n.queue_free)
		elif typ == "banana":
			h["timer"] = float(h["timer"]) - delta
			var bn: Node3D = h["n"]
			var pulse: float = 1.0 + 0.2 * sin(round_t * 22.0)
			bn.scale = Vector3(pulse, pulse, pulse)
			if float(h["timer"]) <= 0.0:
				_blast(h["p"], 5.5, 50.0, 13.0)
				shake = maxf(shake, 0.5)
				bn.queue_free()
				done = true
		elif typ == "boom":
			h["timer"] = float(h["timer"]) - delta
			if float(h["timer"]) <= 0.0:
				_blast(h["p"], 4.2, 45.0, 14.0)
				shake = maxf(shake, 0.6)
				done = true
		elif typ == "mover":
			h["delay"] = float(h["delay"]) - delta
			if float(h["delay"]) <= 0.0:
				var mp: Vector3 = h["pos"]
				var dv: Vector3 = h["dir"]
				mp += dv * float(h["speed"]) * delta
				h["pos"] = mp
				var mn: Node3D = h["n"]
				mn.position = Vector3(mp.x, float(h["y"]) + sin(round_t * 4.0 + float(h["ph"])) * float(h["bob"]), mp.z)
				if h["mesh"] != null:
					(h["mesh"] as Node3D).rotate(dv.cross(Vector3.UP).normalized(), float(h["speed"]) / 2.2 * delta)
				_mover_hits(h)
				if absf(mp.x) > 62.0 or absf(mp.z) > 62.0:
					mn.queue_free()
					done = true
		if not done:
			keep.append(h)
	hazards = keep

func _mover_hits(h: Dictionary) -> void:
	var mp: Vector3 = h["pos"]
	var hits: Array = h["hits"]
	var dv: Vector3 = h["dir"]
	var hx: float = float(h["hx"])
	var hz: float = float(h["hz"])
	var ymin: float = float(h["ymin"])
	var ymax: float = float(h["ymax"])
	var kdir: Vector3 = dv * float(h["knock"])
	if alive_player and not hits.has("p"):
		var pp: Vector3 = player.global_position
		if absf(pp.x - mp.x) < hx and absf(pp.z - mp.z) < hz and pp.y < ymax and pp.y + 1.7 > ymin:
			hits.append("p")
			_hurt_player(float(h["dmg"]), kdir)
	for i in bots.size():
		var b: Dictionary = bots[i]
		if not b["alive"] or hits.has(i):
			continue
		var bp: Vector3 = (b["n"] as Node3D).position
		if absf(bp.x - mp.x) < hx and absf(bp.z - mp.z) < hz and bp.y < ymax:
			hits.append(i)
			_hurt_bot(b, float(h["dmg"]), kdir)

func _update_bots(delta: float) -> void:
	for b in bots:
		if not b["alive"]:
			continue
		var n: Node3D = b["n"]
		var p: Vector3 = n.position
		var kv: Vector3 = b["kv"]
		var mv: Vector3 = Vector3.ZERO
		if state != "countdown":
			b["tcd"] = float(b["tcd"]) - delta
			var tg: Vector3 = b["tg"]
			if float(b["tcd"]) <= 0.0 or Vector2(p.x - tg.x, p.z - tg.z).length() < 1.5:
				b["tg"] = Vector3(randf_range(-28, 28), 0, randf_range(-28, 28))
				b["tcd"] = randf_range(2.0, 5.0)
				tg = b["tg"]
			var dirw: Vector3 = Vector3(tg.x - p.x, 0, tg.z - p.z).normalized()
			mv = dirw * float(b["spd"]) * 0.6
			var flee: Vector3 = Vector3.ZERO
			for w in warnings:
				var wp: Vector3 = w["p"]
				var d2: Vector3 = Vector3(p.x - wp.x, 0, p.z - wp.z)
				var lim: float = float(w["r"]) + 2.5
				if d2.length() < lim:
					flee += d2.normalized() * (1.0 + (lim - d2.length()) * 0.3)
			for h in hazards:
				if h["type"] != "mover":
					continue
				var mp: Vector3 = h["pos"]
				if bool(h["horiz"]):
					if absf(p.z - mp.z) < float(h["hz"]) + 3.0 and absf(p.x - mp.x) < 18.0:
						flee.z += (1.0 if p.z >= mp.z else -1.0) * 2.0
				else:
					if absf(p.x - mp.x) < float(h["hx"]) + 3.0 and absf(p.z - mp.z) < 18.0:
						flee.x += (1.0 if p.x >= mp.x else -1.0) * 2.0
			if flee.length() > 0.01:
				var k: float = clampf(flee.length() * float(b["skill"]), 0.0, 1.0)
				mv = mv.lerp(flee.normalized() * float(b["spd"]) * 1.4, k)
		p += (mv + kv) * delta
		b["kv"] = kv.move_toward(Vector3.ZERO, 14.0 * delta)
		var on_plat: bool = absf(p.x) < 35.0 and absf(p.z) < 35.0
		if on_plat and p.y <= 0.001 and float(b["vy"]) <= 0.0:
			p.y = 0.0
			b["vy"] = 0.0
		else:
			b["vy"] = float(b["vy"]) - 25.0 * delta
			p.y += float(b["vy"]) * delta
		n.position = p
		if p.y < -8.0:
			_eliminate_bot(b, "упал с арены")

# ---------- round end ----------
func _check_end() -> void:
	var ab: int = _alive_bots()
	if alive_player and ab == 0:
		_end(true, Game.nickname)
	elif not alive_player and ab <= 1:
		var wn: String = "никто"
		for b in bots:
			if b["alive"]:
				wn = b["name"]
		_end(false, wn)

func _end(win: bool, wname: String) -> void:
	if state == "ended":
		return
	state = "ended"
	won = win
	winner_name = wname
	end_t = 3.2
	if win:
		survive_t = round_t
		place = 1
		banner("ТЫ ПОБЕДИЛ!\nПоследний выживший!", Color("ffd21f"), 3.0)
	else:
		banner("ПОБЕДИТЕЛЬ: %s!" % wname, Color("ffd21f"), 3.0)

func _on_exit() -> void:
	if state == "countdown" or recorded:
		exit_requested.emit(false)
		return
	if alive_player:
		place = _alive_bots() + 1
		survive_t = round_t
		alive_player = false
	_finish_rewards(false)

func _finish_rewards(win: bool) -> void:
	if recorded:
		return
	recorded = true
	var tr: int = 0
	if place == 1:
		tr = 25
	elif place == 2:
		tr = 12
	elif place == 3:
		tr = 6
	var co: int = 30 + int(survive_t) * 3 + (200 if win else 0)
	Game.add_trophies(tr)
	Game.s["coins"] = int(Game.s["coins"]) + co
	Game.s["xp"] = int(Game.s["xp"]) + 20
	Game.s["m"]["games"] = int(Game.s["m"]["games"]) + 1
	if win:
		Game.s["m"]["wins"] = int(Game.s["m"]["wins"]) + 1
	Game.save_game()
	var title: String = "ПОБЕДА!" if win else "ИГРА ОКОНЧЕНА"
	var txt: String = "Твоё место: %d из 8\nПобедитель: %s\nТы продержался: %d с\nТрофеи: +%d   Монеты: +%d\n(соперники — боты)" % [place, winner_name if winner_name != "" else "—", int(survive_t), tr, co]
	show_result(title, txt, win)
