extends Node3D
# Shared first-person controller and mobile HUD for MEME CHAOS and SCHOOL CHAOS.
# Virtual joystick (left), camera swipe (right), jump, sprint, interaction button.
signal exit_requested(again: bool)

const SENS: float = 0.0045

var mode: String = ""
var vp: Vector2 = Vector2(1280, 720)
var player: CharacterBody3D
var cam: Camera3D
var yaw: float = 0.0
var pitch: float = 0.0
var vel_y: float = 0.0
var boost_y: float = 0.0
var push: Vector3 = Vector3.ZERO
var base_speed: float = 5.4
var gravity_scale: float = 1.0
var jump_speed: float = 7.5
var fly: bool = false
var locked: bool = false
var ui_lock: bool = false
var over: bool = false
var t: float = 0.0
var jump_req: bool = false
var sprint_held: bool = false
var move_idx: int = -1
var look_idx: int = -1
var sprint_idx: int = -1
var joy_o: Vector2 = Vector2.ZERO
var joy_v: Vector2 = Vector2.ZERO
var layer: CanvasLayer
var hud: Control
var info_l: Label
var prompt_l: Label
var toast_l: Label
var toast_t: float = 0.0
var banner_l: Label
var banner_tw: Tween = null
var btns: Dictionary = {}
var btn_labels: Dictionary = {}
var btn_panels: Dictionary = {}
var can_interact: bool = false

# ----- virtual hooks -----
func _tick(_delta: float) -> void:
	pass

func _prompt() -> String:
	return ""

func _do_interact() -> void:
	pass

func _hud_extra() -> void:
	pass

func _on_exit() -> void:
	exit_requested.emit(false)

# ----- setup -----
func _make_player(start: Vector3, yaw0: float) -> void:
	yaw = yaw0
	player = CharacterBody3D.new()
	player.collision_layer = 4
	player.collision_mask = 1
	var cs: CollisionShape3D = CollisionShape3D.new()
	var cap: CapsuleShape3D = CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0, 0.9, 0)
	player.add_child(cs)
	player.position = start
	player.rotation.y = yaw
	add_child(player)
	cam = Camera3D.new()
	cam.position = Vector3(0, 1.6, 0)
	cam.fov = 78.0
	cam.near = 0.05
	cam.far = 260.0
	player.add_child(cam)
	cam.current = true

func _round_btn(key: String, caption: String, center: Vector2, r: float, col: Color, fs: int) -> void:
	btns[key] = [center, r]
	var p: Panel = Panel.new()
	btn_panels[key] = p
	p.position = center - Vector2(r, r)
	p.size = Vector2(r * 2.0, r * 2.0)
	p.add_theme_stylebox_override("panel", Game.style(col, int(r), 5))
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l: Label = Game.make_label(caption, fs)
	l.position = Vector2(0, r - float(fs) * 0.75)
	l.size = Vector2(r * 2.0, float(fs) * 1.6)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	p.add_child(l)
	layer.add_child(p)
	btn_labels[key] = l

func _make_base_hud() -> void:
	layer = CanvasLayer.new()
	add_child(layer)
	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.draw.connect(_on_hud_draw)
	layer.add_child(hud)
	info_l = Game.make_label("", 28)
	info_l.position = Vector2(24, 14)
	layer.add_child(info_l)
	prompt_l = Game.make_label("", 32, Color("ffd21f"))
	prompt_l.position = Vector2(vp.x / 2.0 - 450, vp.y - 150)
	prompt_l.size = Vector2(900, 50)
	prompt_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	layer.add_child(prompt_l)
	toast_l = Game.make_label("", 34, Color("ffd21f"))
	toast_l.position = Vector2(vp.x / 2.0 - 500, 120)
	toast_l.size = Vector2(1000, 50)
	toast_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_l.visible = false
	layer.add_child(toast_l)
	banner_l = Game.make_label("", 60, Color("ffd21f"))
	banner_l.size = Vector2(1100, 170)
	banner_l.position = Vector2((vp.x - 1100.0) / 2.0, 170)
	banner_l.pivot_offset = Vector2(550, 85)
	banner_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner_l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	banner_l.add_theme_constant_override("outline_size", 14)
	banner_l.visible = false
	layer.add_child(banner_l)
	_round_btn("jump", "ПРЫЖОК", Vector2(vp.x - 170, vp.y - 150), 85.0, Color("9b3fe0"), 22)
	_round_btn("interact", "ДЕЙСТВИЕ", Vector2(vp.x - 380, vp.y - 110), 78.0, Color("3cc83c"), 20)
	_round_btn("sprint", "БЕГ", Vector2(vp.x - 110, vp.y - 320), 58.0, Color("ff7a1a"), 24)
	_round_btn("exit", "X", Vector2(vp.x - 60, 56), 40.0, Color("0d1650"), 36)

func toast(text: String) -> void:
	toast_l.text = text
	toast_l.visible = true
	toast_t = 2.2

func banner(text: String, col: Color = Color("ffd21f"), secs: float = 2.2) -> void:
	if banner_tw != null and banner_tw.is_valid():
		banner_tw.kill()
	banner_l.text = text
	banner_l.add_theme_color_override("font_color", col)
	banner_l.visible = true
	banner_l.modulate.a = 1.0
	banner_l.scale = Vector2(1.35, 1.35)
	banner_tw = create_tween()
	banner_tw.tween_property(banner_l, "scale", Vector2.ONE, 0.2)
	banner_tw.tween_interval(secs)
	banner_tw.tween_property(banner_l, "modulate:a", 0.0, 0.4)
	banner_tw.tween_callback(func(): banner_l.visible = false)

func _on_hud_draw() -> void:
	if move_idx != -1:
		hud.draw_circle(joy_o, 90.0, Color(1, 1, 1, 0.12))
		hud.draw_arc(joy_o, 90.0, 0.0, TAU, 40, Color(1, 1, 1, 0.5), 4.0)
		hud.draw_circle(joy_o + joy_v * 90.0, 38.0, Color(1, 1, 1, 0.5))
	hud.draw_circle(vp / 2.0, 3.0, Color(1, 1, 1, 0.85))
	_hud_extra()

# ----- input -----
func _hit_btn(p: Vector2) -> String:
	for k in btns.keys():
		var pn: Panel = btn_panels[k]
		if not pn.visible:
			continue
		var b: Array = btns[k]
		if p.distance_to(b[0]) <= float(b[1]) * 1.2:
			return k
	return ""

func _input(ev: InputEvent) -> void:
	if over or ui_lock:
		return
	if ev is InputEventScreenTouch:
		var te: InputEventScreenTouch = ev as InputEventScreenTouch
		var p: Vector2 = te.position
		if te.pressed:
			var k: String = _hit_btn(p)
			if k != "":
				_press(k, te.index)
			elif p.x < vp.x * 0.45 and move_idx == -1:
				move_idx = te.index
				joy_o = p
				joy_v = Vector2.ZERO
			elif look_idx == -1:
				look_idx = te.index
		else:
			if te.index == move_idx:
				move_idx = -1
				joy_v = Vector2.ZERO
			if te.index == look_idx:
				look_idx = -1
			if te.index == sprint_idx:
				sprint_idx = -1
				sprint_held = false
	elif ev is InputEventScreenDrag:
		var de: InputEventScreenDrag = ev as InputEventScreenDrag
		if de.index == move_idx:
			joy_v = (de.position - joy_o).limit_length(90.0) / 90.0
		elif de.index == look_idx:
			yaw -= de.relative.x * SENS
			pitch = clampf(pitch - de.relative.y * SENS, -1.3, 1.3)

func _press(k: String, idx: int) -> void:
	Game.click()
	if k == "jump":
		jump_req = true
	elif k == "sprint":
		sprint_held = true
		sprint_idx = idx
	elif k == "interact":
		if can_interact and not ui_lock and not locked:
			_do_interact()
	elif k == "exit":
		_on_exit()

func _process(delta: float) -> void:
	if toast_t > 0.0:
		toast_t -= delta
		if toast_t <= 0.0 and toast_l != null:
			toast_l.visible = false

func _exit_tree() -> void:
	Game.run_on(false)

# ----- movement -----
func _physics_process(delta: float) -> void:
	if over:
		return
	t += delta
	player.rotation.y = yaw
	cam.rotation.x = pitch
	var moving: bool = false
	if not ui_lock and not locked:
		var inp: Vector2 = Vector2(joy_v.x, joy_v.y)
		if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
			inp.y -= 1.0
		if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
			inp.y += 1.0
		if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
			inp.x -= 1.0
		if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
			inp.x += 1.0
		if inp.length() > 1.0:
			inp = inp.normalized()
		var bs: Basis = player.global_transform.basis
		if fly:
			var fwd: Vector3 = -cam.global_transform.basis.z
			player.velocity = (bs.x * inp.x + fwd * -inp.y) * 11.0
			player.move_and_slide()
		else:
			var mv: Vector3 = bs.x * inp.x + bs.z * inp.y
			var sp: float = base_speed * (1.6 if (sprint_held or Input.is_key_pressed(KEY_SHIFT)) else 1.0)
			if player.is_on_floor():
				vel_y = -1.0
				if boost_y > 0.0:
					vel_y = boost_y
					boost_y = 0.0
				elif jump_req or Input.is_key_pressed(KEY_SPACE):
					vel_y = jump_speed
			else:
				vel_y -= 22.0 * gravity_scale * delta
			player.velocity = Vector3(mv.x * sp + push.x, vel_y, mv.z * sp + push.z)
			player.move_and_slide()
			vel_y = player.velocity.y
			push = push.move_toward(Vector3.ZERO, 18.0 * delta)
			moving = inp.length() > 0.2 and player.is_on_floor()
	jump_req = false
	Game.run_on(moving)
	_tick(delta)
	if over:
		return
	var pr: String = _prompt()
	can_interact = pr != ""
	prompt_l.text = ("ДЕЙСТВИЕ: " + pr) if can_interact else ""
	(btn_panels["interact"] as Panel).modulate = Color.WHITE if can_interact else Color(0.55, 0.55, 0.55)
	hud.queue_redraw()

# ----- result overlay (used by MEME CHAOS) -----
func show_result(title: String, text: String, win: bool) -> void:
	over = true
	ui_lock = true
	Game.run_on(false)
	var dim: ColorRect = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.78)
	dim.size = vp
	layer.add_child(dim)
	var v: VBoxContainer = VBoxContainer.new()
	v.size = Vector2(620, 560)
	v.position = (vp - v.size) / 2.0
	v.add_theme_constant_override("separation", 14)
	layer.add_child(v)
	var tl: Label = Game.make_label(title, 72, Color("ffd21f") if win else Color.WHITE)
	tl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(tl)
	var st: Label = Game.make_label(text, 34)
	st.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	st.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(st)
	var again: Button = Game.make_button("Ещё раз", 42)
	again.custom_minimum_size = Vector2(0, 90)
	again.pressed.connect(func(): exit_requested.emit(true))
	v.add_child(again)
	var menu: Button = Game.make_button("В меню", 42, Color("0d1650"), Color.WHITE)
	menu.custom_minimum_size = Vector2(0, 90)
	menu.pressed.connect(func(): exit_requested.emit(false))
	v.add_child(menu)
