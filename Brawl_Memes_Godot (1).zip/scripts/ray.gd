extends Node2D
# Rotating light rays for the case-opening sequence.
var color: Color = Color(1.0, 0.9, 0.4, 0.45)

func _process(delta: float) -> void:
	rotation += delta * 0.6

func _draw() -> void:
	var n: int = 14
	for i in n:
		var a0: float = TAU * float(i) / float(n)
		var a1: float = a0 + TAU / float(n) * 0.5
		draw_colored_polygon(PackedVector2Array([Vector2.ZERO, Vector2.from_angle(a0) * 800.0, Vector2.from_angle(a1) * 800.0]), color)
