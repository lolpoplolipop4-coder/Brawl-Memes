extends Control
# UI shell (landscape): menu, modes, shop, case opening, fighters, rating, events, settings.

var content: Control
var battle = null
var cache: Dictionary = {}
var bg_rect: TextureRect
var timer_l: Label = null
var timer_acc: float = 0.0

func vp() -> Vector2:
	return get_viewport_rect().size

func tex(p: String) -> Texture2D:
	if not cache.has(p):
		cache[p] = load(p)
	return cache[p]

func _ready() -> void:
	var bg: TextureRect = TextureRect.new()
	bg.texture = tex("res://assets/ui/menu_bg.jpg")
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.modulate = Color(0.38, 0.52, 0.95)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	bg_rect = bg
	var vig: TextureRect = TextureRect.new()
	var vg: Gradient = Gradient.new()
	vg.set_color(0, Color(0, 0, 0, 0.0))
	vg.set_color(1, Color(0, 0.02, 0.15, 0.6))
	var vt: GradientTexture2D = GradientTexture2D.new()
	vt.gradient = vg
	vt.fill = GradientTexture2D.FILL_RADIAL
	vt.fill_from = Vector2(0.5, 0.5)
	vt.fill_to = Vector2(1.0, 0.5)
	vig.texture = vt
	vig.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	vig.stretch_mode = TextureRect.STRETCH_SCALE
	vig.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vig.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(vig)
	content = Control.new()
	content.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(content)
	if Game.s["registered"]:
		show_menu()
	else:
		show_register()

func _process(delta: float) -> void:
	timer_acc += delta
	if timer_acc < 0.5 or timer_l == null or not is_instance_valid(timer_l):
		return
	timer_acc = 0.0
	if Game.free_case_ready():
		timer_l.text = "Бесплатный кейс готов!"
		return
	var t: Dictionary = Time.get_time_dict_from_system()
	var left: int = 86400 - (int(t["hour"]) * 3600 + int(t["minute"]) * 60 + int(t["second"]))
	if left >= 86399:
		show_menu()
		return
	timer_l.text = "Следующий через %02d:%02d:%02d" % [left / 3600, (left % 3600) / 60, left % 60]

# ---------- helpers ----------
func clear() -> void:
	timer_l = null
	for c in content.get_children():
		c.queue_free()

func icon(path: String, sz: float) -> TextureRect:
	var t: TextureRect = TextureRect.new()
	t.texture = tex(path)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	t.custom_minimum_size = Vector2(sz, sz)
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return t

func pill(icon_path: String, text: String) -> Control:
	var p: PanelContainer = PanelContainer.new()
	p.add_theme_stylebox_override("panel", Game.style(Color("0d1650"), 16, 3))
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 8)
	h.add_child(icon(icon_path, 38))
	h.add_child(Game.make_label(text, 30))
	p.add_child(h)
	return p

func currencies(parent: Container) -> void:
	parent.add_child(pill("res://assets/ui/coin.png", str(Game.s["coins"])))
	parent.add_child(pill("res://assets/ui/gem.png", str(Game.s["gems"])))
	parent.add_child(pill("res://assets/ui/trophy.png", str(Game.s["trophies"])))

func spacer() -> Control:
	var sp: Control = Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return sp

func tbtn(asset: String, cb: Callable, min_size: Vector2) -> TextureButton:
	var b: TextureButton = TextureButton.new()
	b.texture_normal = tex("res://assets/ui/%s.png" % asset)
	b.ignore_texture_size = true
	b.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
	b.custom_minimum_size = min_size
	b.pressed.connect(Game.click)
	b.pressed.connect(cb)
	b.resized.connect(func(): b.pivot_offset = b.size / 2.0)
	b.button_down.connect(func():
		b.modulate = Color(0.8, 0.8, 0.8)
		b.create_tween().tween_property(b, "scale", Vector2(0.94, 0.94), 0.06))
	b.button_up.connect(func():
		b.modulate = Color.WHITE
		b.create_tween().tween_property(b, "scale", Vector2.ONE, 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT))
	return b

func big_btn(text: String, cb: Callable, col: Color = Color("ffd21f"), fc: Color = Color.BLACK, h: float = 80.0, fs: int = 34) -> Button:
	var b: Button = Game.make_button(text, fs, col, fc)
	b.custom_minimum_size = Vector2(0, h)
	b.pressed.connect(cb)
	return b

func new_screen(title: String, back_to: Callable) -> VBoxContainer:
	clear()
	var m: MarginContainer = MarginContainer.new()
	m.set_anchors_preset(Control.PRESET_FULL_RECT)
	m.add_theme_constant_override("margin_left", 30)
	m.add_theme_constant_override("margin_right", 30)
	m.add_theme_constant_override("margin_top", 16)
	m.add_theme_constant_override("margin_bottom", 16)
	content.add_child(m)
	var v: VBoxContainer = VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	m.add_child(v)
	var top: HBoxContainer = HBoxContainer.new()
	top.add_theme_constant_override("separation", 10)
	var back: Button = Game.make_button("<", 40, Color("0d1650"), Color.WHITE)
	back.custom_minimum_size = Vector2(100, 70)
	back.pressed.connect(back_to)
	top.add_child(back)
	var tl: Label = Game.make_label(title, 48, Color("ffd21f"))
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	top.add_child(tl)
	currencies(top)
	v.add_child(top)
	return v

func overlay(w: float, h: float) -> VBoxContainer:
	var dim: ColorRect = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.8)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	content.add_child(dim)
	var p: PanelContainer = PanelContainer.new()
	p.add_theme_stylebox_override("panel", Game.style(Color("12236e"), 24, 5))
	p.size = Vector2(w, h)
	p.position = (vp() - p.size) / 2.0
	dim.add_child(p)
	var m: MarginContainer = MarginContainer.new()
	for k in ["left", "right", "top", "bottom"]:
		m.add_theme_constant_override("margin_" + k, 18)
	p.add_child(m)
	var v: VBoxContainer = VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	m.add_child(v)
	v.set_meta("close", big_btn("Закрыть", dim.queue_free, Color("0d1650"), Color.WHITE, 64, 30))
	return v

# ---------- MENU ----------
func quit_game() -> void:
	get_tree().quit()

func toggle_sound_menu() -> void:
	Game.toggle_sound()
	show_menu()

func claimable() -> int:
	var n: int = 0
	for m in Game.MISSIONS:
		if Game.mission_done(m) and not Game.s["mc"].has(m[0]):
			n += 1
	if Game.can_daily():
		n += 1
	return n

func show_register() -> void:
	clear()
	var cc: CenterContainer = CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	content.add_child(cc)
	var panel: PanelContainer = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", Game.style(Color(0.05, 0.1, 0.4, 0.92), 28, 5))
	cc.add_child(panel)
	var mg: MarginContainer = MarginContainer.new()
	for k in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + k, 36)
	panel.add_child(mg)
	var v: VBoxContainer = VBoxContainer.new()
	v.custom_minimum_size = Vector2(620, 0)
	v.add_theme_constant_override("separation", 16)
	mg.add_child(v)
	var l1: Label = Game.make_label("BRAWL MEMES", 76, Color("ffd21f"))
	l1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l1.add_theme_constant_override("outline_size", 16)
	v.add_child(l1)
	var l2: Label = Game.make_label("Регистрация: придумайте никнейм", 32)
	l2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(l2)
	var le: LineEdit = LineEdit.new()
	le.placeholder_text = "Никнейм (3-12 символов)"
	le.max_length = 12
	le.alignment = HORIZONTAL_ALIGNMENT_CENTER
	le.add_theme_font_size_override("font_size", 40)
	le.custom_minimum_size = Vector2(0, 84)
	v.add_child(le)
	var err: Label = Game.make_label("", 26, Color("ff7777"))
	err.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(err)
	var go: Button = big_btn("НАЧАТЬ ИГРУ", register_pressed.bind(le, err), Color("ffd21f"), Color.BLACK, 100, 42)
	v.add_child(go)
	le.text_submitted.connect(func(_t: String): register_pressed(le, err))

func register_pressed(le: LineEdit, err: Label) -> void:
	var n: String = le.text.strip_edges()
	if n.length() < 3:
		err.text = "Никнейм должен быть не короче 3 символов"
		return
	Game.register(n)
	show_menu()

func show_menu() -> void:
	Game.play_music("menu")
	clear()
	var m: MarginContainer = MarginContainer.new()
	m.set_anchors_preset(Control.PRESET_FULL_RECT)
	m.add_theme_constant_override("margin_left", 26)
	m.add_theme_constant_override("margin_right", 26)
	m.add_theme_constant_override("margin_top", 14)
	m.add_theme_constant_override("margin_bottom", 18)
	content.add_child(m)
	var v: VBoxContainer = VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	m.add_child(v)
	var c: Dictionary = Game.by_id[Game.s["sel"]]
	var top: HBoxContainer = HBoxContainer.new()
	top.add_theme_constant_override("separation", 10)
	var prof: PanelContainer = PanelContainer.new()
	prof.add_theme_stylebox_override("panel", Game.style(Color(0.05, 0.09, 0.32, 0.95), 18, 4))
	var ph: HBoxContainer = HBoxContainer.new()
	ph.add_theme_constant_override("separation", 10)
	ph.add_child(icon(c["tex"], 64))
	var pv: VBoxContainer = VBoxContainer.new()
	pv.add_child(Game.make_label("%s  ур.%d" % [Game.nickname, Game.player_level()], 28))
	pv.add_child(Game.make_label("Трофеи: %d" % Game.s["trophies"], 26, Color("ffd21f")))
	ph.add_child(pv)
	prof.add_child(ph)
	top.add_child(prof)
	top.add_child(spacer())
	top.add_child(icon("res://assets/ui/badge_version.png", 70))
	top.add_child(spacer())
	currencies(top)
	var snd: TextureButton = tbtn("ic_sound", toggle_sound_menu, Vector2(70, 70))
	if not Game.s["snd"]:
		snd.modulate = Color(0.45, 0.45, 0.45)
	top.add_child(snd)
	top.add_child(tbtn("ic_gear", show_settings, Vector2(70, 70)))
	v.add_child(top)
	var mid: HBoxContainer = HBoxContainer.new()
	mid.size_flags_vertical = Control.SIZE_EXPAND_FILL
	mid.add_theme_constant_override("separation", 10)
	var side: VBoxContainer = VBoxContainer.new()
	side.custom_minimum_size = Vector2(320, 0)
	side.add_theme_constant_override("separation", 10)
	side.alignment = BoxContainer.ALIGNMENT_CENTER
	var fb: Button = Game.make_button("БОЙЦЫ", 34, Color("2f8cff"), Color.WHITE)
	fb.custom_minimum_size = Vector2(320, 80)
	fb.pressed.connect(show_fighters)
	var side_btns: Array = [tbtn("btn_shop", show_shop, Vector2(320, 80)), fb, tbtn("btn_rating", show_rank, Vector2(320, 80)), tbtn("btn_achiev", show_events, Vector2(320, 80))]
	for i in side_btns.size():
		var sb: Control = side_btns[i]
		sb.modulate.a = 0.0
		side.add_child(sb)
		var tw: Tween = sb.create_tween()
		tw.tween_interval(0.06 * float(i))
		tw.tween_property(sb, "modulate:a", 1.0, 0.25)
	mid.add_child(side)
	var logo: VBoxContainer = VBoxContainer.new()
	logo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	logo.alignment = BoxContainer.ALIGNMENT_CENTER
	logo.add_theme_constant_override("separation", -6)
	var crown: TextureRect = icon("res://assets/ui/crown.png", 56)
	logo.add_child(crown)
	var lrow: HBoxContainer = HBoxContainer.new()
	lrow.alignment = BoxContainer.ALIGNMENT_CENTER
	lrow.add_theme_constant_override("separation", 14)
	for it in [["BRAWL", Color.WHITE], ["MEMES", Color("ffd21f")]]:
		var l: Label = Game.make_label(it[0], 70, it[1])
		l.add_theme_constant_override("outline_size", 18)
		l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.6))
		l.add_theme_constant_override("shadow_offset_y", 6)
		lrow.add_child(l)
	logo.add_child(lrow)
	var face: TextureRect = icon(c["tex"], 280)
	logo.add_child(face)
	var nm: Label = Game.make_label("%s · %s" % [c["name"], Game.RAR_NAMES[c["rar"]]], 26, Game.rar_colors[c["rar"]].lightened(0.35))
	nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	logo.add_child(nm)
	mid.add_child(logo)
	var right: VBoxContainer = VBoxContainer.new()
	right.custom_minimum_size = Vector2(340, 0)
	right.alignment = BoxContainer.ALIGNMENT_CENTER
	right.add_theme_constant_override("separation", 8)
	var gift: TextureButton = tbtn("btn_gift", free_case, Vector2(260, 100))
	if not Game.free_case_ready():
		gift.disabled = true
		gift.modulate = Color(0.5, 0.5, 0.5)
	right.add_child(gift)
	timer_l = Game.make_label("", 22, Color("ffd21f"))
	timer_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	right.add_child(timer_l)
	timer_acc = 1.0
	var n: int = claimable()
	var ev: Button = big_btn("Миссии и награды\n" + ("Можно забрать: %d" % n if n > 0 else "Выполняйте задания"), show_events, Color("0d1650"), Color.WHITE, 110, 26)
	right.add_child(ev)
	mid.add_child(right)
	v.add_child(mid)
	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	var nc: Button = big_btn("НОВЫЙ КЕЙС!", show_shop, Color("2f8cff"), Color.WHITE, 110, 34)
	nc.custom_minimum_size = Vector2(340, 110)
	var chest: TextureRect = icon("res://assets/ui/case_b.png", 80)
	chest.position = Vector2(14, 16)
	nc.add_child(chest)
	nc.alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(nc)
	row.add_child(spacer())
	row.add_child(tbtn("btn_play", show_modes, Vector2(400, 124)))
	v.add_child(row)

func free_case() -> void:
	if not Game.free_case_ready():
		return
	Game.s["free_day"] = Game.today()
	open_case("a", true)

# ---------- MODES ----------
func show_modes() -> void:
	var v: VBoxContainer = new_screen("ВЫБОР ИГР", show_menu)
	var wrap: CenterContainer = CenterContainer.new()
	wrap.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var grid: GridContainer = GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 16)
	grid.add_theme_constant_override("v_separation", 10)
	for it in [["battle", "mode_pvp", "Мем-бой", "3 соперника"], ["sandbox", "mode_creative", "Песочница", "строй блоки"], ["survival", "mode_survival", "Выживание", "держись дольше"], ["arena", "mode_adventure", "Мем-арена", "5 волн мемов"], ["wood", "", "Сбор дров", "30 дров в грузовик"], ["mp", "", "Мультиплеер", "по сети, до 10 убийств"], ["chaos", "mode_chaos", "Мем-хаос", "выживи среди катастроф"], ["school", "mode_school", "Школьный хаос", "безумные задания учителей"]]:
		var mode: String = it[0]
		var cell: VBoxContainer = VBoxContainer.new()
		if it[1] == "":
			var is_mp: bool = mode == "mp"
			var wb: Button = Game.make_button("\n\nМУЛЬТИПЛЕЕР" if is_mp else "\n\nСБОР ДРОВ", 26 if is_mp else 28, Color("2f8cff") if is_mp else Color("ff7a1a"), Color.WHITE if is_mp else Color.BLACK)
			wb.custom_minimum_size = Vector2(270, 190)
			wb.pressed.connect(show_lobby if is_mp else start_battle.bind(mode))
			var li: TextureRect = icon("res://assets/ui/ic_people.png" if is_mp else "res://assets/ui/logs_icon.png", 90)
			li.position = Vector2(90, 16)
			wb.add_child(li)
			cell.add_child(wb)
		else:
			cell.add_child(tbtn(it[1], start_battle.bind(mode), Vector2(270, 190)))
		var cap: Label = Game.make_label("%s\n%s" % [it[2], it[3]], 22)
		cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		cell.add_child(cap)
		grid.add_child(cell)
	wrap.add_child(grid)
	v.add_child(wrap)

func start_battle(mode: String) -> void:
	Game.play_music("game")
	content.visible = false
	bg_rect.visible = false
	if battle != null:
		remove_child(battle)
		battle.queue_free()
	battle = Node3D.new()
	battle.name = "Battle"
	var script_path: String = "res://scripts/fps.gd"
	if mode == "chaos":
		script_path = "res://scripts/chaos.gd"
	elif mode == "school":
		script_path = "res://scripts/school.gd"
	battle.set_script(load(script_path))
	add_child(battle)
	battle.setup(mode)
	battle.exit_requested.connect(func(again: bool):
		remove_child(battle)
		battle.queue_free()
		battle = null
		if mode == "mp":
			Game.mp_leave()
		content.visible = true
		bg_rect.visible = true
		Game.play_music("menu")
		if again:
			start_battle(mode)
		else:
			show_modes())

# ---------- SHOP ----------
func show_shop() -> void:
	var v: VBoxContainer = new_screen("МАГАЗИН · КЕЙСЫ", show_menu)
	var row: HBoxContainer = HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_theme_constant_override("separation", 16)
	for cid in ["a", "b"]:
		var cd: Dictionary = Game.CASES[cid]
		var p: PanelContainer = PanelContainer.new()
		p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		p.add_theme_stylebox_override("panel", Game.style(Color("12236e"), 22, 4))
		var h: HBoxContainer = HBoxContainer.new()
		h.add_theme_constant_override("separation", 12)
		var img: TextureRect = icon(cd["card"], 250)
		img.custom_minimum_size = Vector2(240, 320)
		h.add_child(img)
		var col: VBoxContainer = VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.alignment = BoxContainer.ALIGNMENT_CENTER
		col.add_theme_constant_override("separation", 10)
		var nm: Label = Game.make_label(cd["name"], 34)
		nm.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		col.add_child(nm)
		col.add_child(Game.make_label("16 мемов внутри", 24, Color("ffd21f")))
		var unit: String = "монет" if cd["cur"] == "coins" else "гемов"
		var buy: Button = big_btn("%d %s" % [cd["price"], unit], buy_case.bind(cid), Color("ffd21f"), Color.BLACK, 84, 32)
		buy.disabled = not Game.can_pay(cd["cur"], cd["price"])
		col.add_child(buy)
		col.add_child(big_btn("Награды", show_pool.bind(cid), Color("2f8cff"), Color.WHITE, 70, 28))
		h.add_child(col)
		p.add_child(h)
		row.add_child(p)
	v.add_child(row)
	var info: Label = Game.make_label("Шансы: Обычный 60% · Редкий 25% · Эпический 10% · Легендарный 4% · Мифический 1%", 22)
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(info)
	var ex: HBoxContainer = HBoxContainer.new()
	ex.add_theme_constant_override("separation", 14)
	var e1: Button = big_btn("500 монет за 20 гемов", exchange.bind("gems", 20, "coins", 500), Color("0d1650"), Color.WHITE, 70, 26)
	var e2: Button = big_btn("50 гемов за 800 монет", exchange.bind("coins", 800, "gems", 50), Color("0d1650"), Color.WHITE, 70, 26)
	e1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	e2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ex.add_child(e1)
	ex.add_child(e2)
	v.add_child(ex)

func exchange(pay_cur: String, pay_amt: int, get_cur: String, get_amt: int) -> void:
	if Game.pay(pay_cur, pay_amt):
		Game.add(get_cur, get_amt)
	show_shop()

func buy_case(cid: String) -> void:
	var cd: Dictionary = Game.CASES[cid]
	if Game.pay(cd["cur"], cd["price"]):
		open_case(cid, false)

func show_pool(cid: String) -> void:
	var v: VBoxContainer = overlay(1100, 620)
	var cd: Dictionary = Game.CASES[cid]
	var ban: TextureRect = icon(cd["banner"], 90)
	ban.custom_minimum_size = Vector2(0, 90)
	v.add_child(ban)
	var sc: ScrollContainer = ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var grid: GridContainer = GridContainer.new()
	grid.columns = 8
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	for c in Game.chars:
		if c["case"] != cid:
			continue
		var p: PanelContainer = PanelContainer.new()
		p.add_theme_stylebox_override("panel", Game.style(Game.rar_colors[c["rar"]].darkened(0.3), 12, 3))
		var vb: VBoxContainer = VBoxContainer.new()
		var im: TextureRect = icon(c["tex"], 100)
		im.modulate = Color.WHITE if Game.s["owned"].has(c["id"]) else Color(0.35, 0.35, 0.35)
		vb.add_child(im)
		var l: Label = Game.make_label(Game.RAR_NAMES[c["rar"]], 15)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		vb.add_child(l)
		p.add_child(vb)
		grid.add_child(p)
	sc.add_child(grid)
	v.add_child(sc)
	v.add_child(v.get_meta("close"))

# ---------- CASE OPENING ----------
func open_case(cid: String, free: bool) -> void:
	var res: Dictionary = Game.roll_case(cid)
	clear()
	Game.vibrate(30)
	var size_v: Vector2 = vp()
	var dark: ColorRect = ColorRect.new()
	dark.color = Color.BLACK
	dark.set_anchors_preset(Control.PRESET_FULL_RECT)
	content.add_child(dark)
	var center: Vector2 = size_v / 2.0 + Vector2(0, -20)
	var got: Dictionary = res["char"]
	var rc: Color = Game.rar_colors[got["rar"]]
	var rays = Node2D.new()
	rays.set_script(load("res://scripts/ray.gd"))
	rays.color = Color(rc.r, rc.g, rc.b, 0.4)
	rays.position = center
	rays.scale = Vector2(0.1, 0.1)
	rays.modulate.a = 0.0
	content.add_child(rays)
	var chest: Node2D = Node2D.new()
	chest.position = center
	content.add_child(chest)
	var lid_t: Texture2D = tex("res://assets/ui/chest_%s_lid.png" % cid)
	var body_t: Texture2D = tex("res://assets/ui/chest_%s_body.png" % cid)
	var sc: float = 440.0 / float(lid_t.get_width())
	var total_h: float = float(lid_t.get_height() + body_t.get_height()) * sc
	var lid: Node2D = Node2D.new()
	var ls: Sprite2D = Sprite2D.new()
	ls.texture = lid_t
	ls.scale = Vector2(sc, sc)
	lid.add_child(ls)
	lid.position = Vector2(0, -total_h / 2.0 + float(lid_t.get_height()) * sc / 2.0)
	var bs: Sprite2D = Sprite2D.new()
	bs.texture = body_t
	bs.scale = Vector2(sc, sc)
	bs.position = Vector2(0, -total_h / 2.0 + float(lid_t.get_height()) * sc + float(body_t.get_height()) * sc / 2.0)
	chest.add_child(bs)
	chest.add_child(lid)
	var title: Label = Game.make_label(Game.CASES[cid]["name"], 52, Color("ffd21f"))
	title.position = Vector2(size_v.x / 2.0 - 300, 14)
	title.size = Vector2(600, 70)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	content.add_child(title)
	# reward card
	var card: PanelContainer = PanelContainer.new()
	card.add_theme_stylebox_override("panel", Game.style(rc.darkened(0.45), 28, 7))
	card.size = Vector2(820, 470)
	card.position = size_v / 2.0 - Vector2(410, 255)
	card.pivot_offset = Vector2(410, 235)
	card.scale = Vector2.ZERO
	var cm: MarginContainer = MarginContainer.new()
	for k in ["left", "right", "top", "bottom"]:
		cm.add_theme_constant_override("margin_" + k, 20)
	card.add_child(cm)
	var ch: HBoxContainer = HBoxContainer.new()
	ch.add_theme_constant_override("separation", 20)
	cm.add_child(ch)
	var im: TextureRect = icon(got["tex"], 330)
	im.size_flags_vertical = Control.SIZE_EXPAND_FILL
	ch.add_child(im)
	var cv: VBoxContainer = VBoxContainer.new()
	cv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cv.alignment = BoxContainer.ALIGNMENT_CENTER
	cv.add_theme_constant_override("separation", 10)
	ch.add_child(cv)
	cv.add_child(Game.make_label(Game.RAR_NAMES[got["rar"]].to_upper(), 42, rc.lightened(0.3)))
	var nl: Label = Game.make_label(got["name"], 44)
	nl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	cv.add_child(nl)
	cv.add_child(Game.make_label("HP %d    Урон %d" % [got["hp"], got["dmg"]], 30))
	cv.add_child(Game.make_label(got["abil_name"], 30, Color("55eeff")))
	var dl: Label = Game.make_label("НОВЫЙ БОЕЦ!" if not res["dup"] else "Дубликат! Уровень %d, +%d монет" % [Game.level(got["id"]), res["coins"]], 30, Color("ffd21f"))
	dl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	cv.add_child(dl)
	content.add_child(card)
	var btns: HBoxContainer = HBoxContainer.new()
	btns.add_theme_constant_override("separation", 14)
	btns.size = Vector2(700, 90)
	btns.position = Vector2(size_v.x / 2.0 - 350, size_v.y - 110)
	btns.modulate.a = 0.0
	var take: Button = big_btn("Забрать", show_shop, Color("ffd21f"), Color.BLACK, 90, 40)
	take.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	btns.add_child(take)
	if not free:
		var cd: Dictionary = Game.CASES[cid]
		var again: Button = big_btn("Ещё раз", buy_case.bind(cid), Color("2f8cff"), Color.WHITE, 90, 40)
		again.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		again.disabled = not Game.can_pay(cd["cur"], cd["price"])
		btns.add_child(again)
	content.add_child(btns)
	var tw: Tween = create_tween()
	for i in 8:
		tw.tween_property(chest, "rotation", 0.07 if i % 2 == 0 else -0.07, 0.07)
	tw.tween_property(chest, "rotation", 0.0, 0.05)
	tw.tween_callback(func(): Game.vibrate(60))
	tw.tween_property(chest, "scale", Vector2(1.12, 1.12), 0.1)
	tw.tween_property(chest, "scale", Vector2(1.0, 1.0), 0.1)
	tw.tween_property(lid, "position:y", lid.position.y - 150.0, 0.45).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(lid, "rotation", -0.25, 0.45)
	tw.parallel().tween_property(rays, "modulate:a", 1.0, 0.5)
	tw.parallel().tween_property(rays, "scale", Vector2(1.0, 1.0), 0.7)
	tw.tween_interval(0.5)
	tw.tween_callback(func(): Game.vibrate(120))
	tw.tween_property(chest, "modulate:a", 0.0, 0.3)
	tw.parallel().tween_property(card, "scale", Vector2.ONE, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(btns, "modulate:a", 1.0, 0.3)

# ---------- FIGHTERS ----------
func show_fighters() -> void:
	var v: VBoxContainer = new_screen("БОЙЦЫ  %d / %d" % [Game.s["owned"].size(), Game.chars.size()], show_menu)
	var sc: ScrollContainer = ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var grid: GridContainer = GridContainer.new()
	grid.columns = 6
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	for c in Game.chars:
		var owned: bool = Game.s["owned"].has(c["id"])
		var rc: Color = Game.rar_colors[c["rar"]]
		var b: Button = Button.new()
		b.custom_minimum_size = Vector2(186, 232)
		b.focus_mode = Control.FOCUS_NONE
		var sel: bool = Game.s["sel"] == c["id"]
		var st: StyleBoxFlat = Game.style(rc.darkened(0.35) if owned else Color("1b2350"), 16, 7 if sel else 3)
		if sel:
			st.border_color = Color.WHITE
		for nme in ["normal", "hover", "pressed"]:
			b.add_theme_stylebox_override(nme, st)
		var vb: VBoxContainer = VBoxContainer.new()
		vb.set_anchors_preset(Control.PRESET_FULL_RECT)
		vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var im: TextureRect = icon(c["tex"], 140)
		im.modulate = Color.WHITE if owned else Color(0, 0, 0, 0.7)
		vb.add_child(im)
		var nl: Label = Game.make_label(c["name"] if owned else "???", 20)
		nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		nl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		vb.add_child(nl)
		var ll: Label = Game.make_label(("Ур.%d" % Game.level(c["id"])) if owned else Game.RAR_NAMES[c["rar"]], 20, rc.lightened(0.3))
		ll.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		vb.add_child(ll)
		b.add_child(vb)
		var cid: String = c["id"]
		b.pressed.connect(Game.click)
		b.pressed.connect(show_char.bind(cid))
		grid.add_child(b)
	sc.add_child(grid)
	v.add_child(sc)

func show_char(id: String) -> void:
	var c: Dictionary = Game.by_id[id]
	var owned: bool = Game.s["owned"].has(id)
	var v: VBoxContainer = overlay(900, 520)
	var h: HBoxContainer = HBoxContainer.new()
	h.size_flags_vertical = Control.SIZE_EXPAND_FILL
	h.add_theme_constant_override("separation", 20)
	var im: TextureRect = icon(c["tex"], 330)
	im.modulate = Color.WHITE if owned else Color(0, 0, 0, 0.7)
	h.add_child(im)
	var col: VBoxContainer = VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 10)
	col.add_child(Game.make_label(Game.RAR_NAMES[c["rar"]].to_upper(), 36, Game.rar_colors[c["rar"]].lightened(0.3)))
	col.add_child(Game.make_label(c["name"] if owned else "Не найден", 44))
	var txt: String = "Откройте в кейсе:\n" + Game.CASES[c["case"]]["name"]
	if owned:
		txt = "Уровень %d\nHP %d   Урон %d   Скорость %d\n%s\n%s" % [Game.level(id), Game.stat(id, "hp"), Game.stat(id, "dmg"), Game.stat(id, "spd"), c["abil_name"], Game.ABIL_TEXT[c["abil"]]]
	var sl: Label = Game.make_label(txt, 28)
	sl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(sl)
	if owned:
		col.add_child(big_btn("Выбрать бойца", select_char.bind(id), Color("ffd21f"), Color.BLACK, 80, 36))
	h.add_child(col)
	v.add_child(h)
	v.add_child(v.get_meta("close"))

func select_char(id: String) -> void:
	Game.s["sel"] = id
	Game.save_game()
	show_fighters()

# ---------- RANK ----------
func show_rank() -> void:
	var v: VBoxContainer = new_screen("РЕЙТИНГ", show_menu)
	var names: Array = ["MemeLord", "DogeKing", "Нойон228", "CatBoss", "Пельмень", "Sus_Man", "Тэнгри", "Байкал_777"]
	var list: Array = []
	for i in names.size():
		list.append([names[i], 9500 - i * 1150])
	list.append([Game.nickname, Game.s["trophies"]])
	list.sort_custom(func(a, b): return a[1] > b[1])
	var sc: ScrollContainer = ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var vb: VBoxContainer = VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 8)
	for i in list.size():
		var me: bool = list[i][0] == Game.nickname
		var p: PanelContainer = PanelContainer.new()
		p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		p.add_theme_stylebox_override("panel", Game.style(Color("8a6400") if me else Color("0d1650"), 14, 3))
		var h: HBoxContainer = HBoxContainer.new()
		var l: Label = Game.make_label("%d.  %s" % [i + 1, list[i][0]], 34)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(l)
		h.add_child(Game.make_label(str(list[i][1]), 34, Color("ffd21f")))
		p.add_child(h)
		vb.add_child(p)
	sc.add_child(vb)
	v.add_child(sc)

# ---------- EVENTS ----------
func show_events() -> void:
	var v: VBoxContainer = new_screen("СОБЫТИЯ И НАГРАДЫ", show_menu)
	var h: HBoxContainer = HBoxContainer.new()
	h.size_flags_vertical = Control.SIZE_EXPAND_FILL
	h.add_theme_constant_override("separation", 20)
	var left: VBoxContainer = VBoxContainer.new()
	left.custom_minimum_size = Vector2(420, 0)
	left.add_theme_constant_override("separation", 14)
	var can: bool = Game.can_daily()
	left.add_child(Game.make_label("Ежедневная награда\nСерия: %d дн." % Game.s["streak"], 34))
	var d: Button = big_btn("Забрать награду" if can else "Приходите завтра", claim_daily_ui, Color("ffd21f"), Color.BLACK, 100, 36)
	d.disabled = not can
	left.add_child(d)
	h.add_child(left)
	var sc: ScrollContainer = ScrollContainer.new()
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var list: VBoxContainer = VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 10)
	for m in Game.MISSIONS:
		var prog: int = mini(int(Game.s["m"][m[0]]), int(m[2]))
		var claimed: bool = Game.s["mc"].has(m[0])
		var p: PanelContainer = PanelContainer.new()
		p.add_theme_stylebox_override("panel", Game.style(Color("0d1650"), 14, 3))
		var row: HBoxContainer = HBoxContainer.new()
		var unit: String = "монет" if m[3] == "coins" else "гемов"
		var l: Label = Game.make_label("%s\n%d / %d  ·  награда %d %s" % [m[1], prog, m[2], m[4], unit], 28)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(l)
		var b: Button = Game.make_button("Готово" if claimed else "Забрать", 30)
		b.custom_minimum_size = Vector2(200, 80)
		b.disabled = claimed or not Game.mission_done(m)
		b.pressed.connect(claim_mission_ui.bind(m))
		row.add_child(b)
		p.add_child(row)
		list.add_child(p)
	sc.add_child(list)
	h.add_child(sc)
	v.add_child(h)

func claim_daily_ui() -> void:
	Game.claim_daily()
	show_events()

func claim_mission_ui(m: Array) -> void:
	Game.claim_mission(m)
	show_events()

# ---------- SETTINGS ----------
func show_settings(msg: String = "", ok: bool = true) -> void:
	var v: VBoxContainer = new_screen("НАСТРОЙКИ", show_menu)
	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.add_child(Game.make_label("Имя:", 34))
	var le: LineEdit = LineEdit.new()
	le.text = Game.s["name"]
	le.max_length = 12
	le.add_theme_font_size_override("font_size", 36)
	le.custom_minimum_size = Vector2(0, 76)
	le.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(le)
	var sv: Button = big_btn("Сохранить", save_name.bind(le), Color("ffd21f"), Color.BLACK, 76, 32)
	sv.custom_minimum_size = Vector2(260, 76)
	row.add_child(sv)
	v.add_child(row)
	var prow: HBoxContainer = HBoxContainer.new()
	prow.add_theme_constant_override("separation", 12)
	prow.add_child(Game.make_label("Промокод:", 34))
	var pe: LineEdit = LineEdit.new()
	pe.placeholder_text = "Введите промокод"
	pe.add_theme_font_size_override("font_size", 36)
	pe.custom_minimum_size = Vector2(0, 76)
	pe.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	prow.add_child(pe)
	var pb: Button = big_btn("Активировать", redeem_promo.bind(pe), Color("2f8cff"), Color.WHITE, 76, 30)
	pb.custom_minimum_size = Vector2(260, 76)
	prow.add_child(pb)
	v.add_child(prow)
	if msg != "":
		v.add_child(Game.make_label(msg, 28, Color("55ee88") if ok else Color("ff7777")))
	var grid: GridContainer = GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 14)
	grid.add_theme_constant_override("v_separation", 14)
	var b1: Button = big_btn("Звук: " + ("вкл" if Game.s["snd"] else "выкл"), toggle_sound_settings, Color("2f8cff"), Color.WHITE, 90, 34)
	var b2: Button = big_btn("Вибрация: " + ("вкл" if Game.s["vib"] else "выкл"), toggle_vib, Color("9b3fe0"), Color.WHITE, 90, 34)
	var b6: Button = big_btn("Сбросить школу", reset_school_ui, Color("9b3fe0"), Color.WHITE, 90, 30)
	var b4: Button = big_btn("Выйти из игры", quit_game, Color("ff7a1a"), Color.BLACK, 90, 34)
	var b5: Button = big_btn("Сменить аккаунт (удалить данные)", change_account, Color("d7322d"), Color.WHITE, 90, 28)
	for b in [b1, b2, b6, b4, b5]:
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(b)
	v.add_child(grid)

func save_name(le: LineEdit) -> void:
	var n: String = le.text.strip_edges()
	if n != "":
		Game.s["name"] = n
		Game.nickname = n
		Game.save_game()
	show_settings()

func toggle_sound_settings() -> void:
	Game.toggle_sound()
	show_settings()

func toggle_vib() -> void:
	Game.s["vib"] = not Game.s["vib"]
	Game.save_game()
	show_settings()

func change_account() -> void:
	Game.wipe_account()
	show_register()

func redeem_promo(le: LineEdit) -> void:
	var r: int = Game.redeem(le.text)
	if r == 3:
		show_settings("Промокод активирован: все бойцы разблокированы!", true)
	elif r == 0:
		show_settings("Промокод активирован: +100000 монет и +100000 гемов!", true)
	elif r == 2:
		show_settings("Этот промокод уже использован", false)
	else:
		show_settings("Неверный промокод", false)

func reset_school_ui() -> void:
	Game.reset_school()
	show_settings("Прогресс школы сброшен", true)

# ---------- MULTIPLAYER LOBBY ----------
const MP_PORT: int = 7777
var lobby_status: Label = null
var lobby_list: Label = null
var lobby_start: Button = null
var mp_signals: bool = false

func local_ips() -> String:
	var out: PackedStringArray = PackedStringArray()
	for a in IP.get_local_addresses():
		var s: String = str(a)
		if s.count(".") == 3 and not s.begins_with("127.") and not s.begins_with("169.254."):
			out.append(s)
	return ", ".join(out) if out.size() > 0 else "не найден (проверьте Wi-Fi)"

func lobby_back() -> void:
	Game.mp_leave()
	show_modes()

func show_lobby(status: String = "") -> void:
	var v: VBoxContainer = new_screen("МУЛЬТИПЛЕЕР", lobby_back)
	var info: Label = Game.make_label("Простой мультиплеер: один игрок создаёт игру, остальные вводят его IP. Бой в деревне до 10 убийств или 5 минут. Нужна одна Wi-Fi сеть (или проброс порта 7777/UDP, либо VPN).", 24)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(info)
	var row: HBoxContainer = HBoxContainer.new()
	row.add_theme_constant_override("separation", 24)
	var left: VBoxContainer = VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 10)
	left.add_child(Game.make_label("Я — хост", 34, Color("ffd21f")))
	var ips: Label = Game.make_label("Твой IP: " + local_ips(), 24)
	ips.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	left.add_child(ips)
	left.add_child(big_btn("Создать игру", host_game, Color("3cc83c"), Color.BLACK, 80, 34))
	row.add_child(left)
	var right: VBoxContainer = VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 10)
	right.add_child(Game.make_label("Подключиться к другу", 34, Color("ffd21f")))
	var le: LineEdit = LineEdit.new()
	le.placeholder_text = "IP хоста, например 192.168.1.5"
	le.add_theme_font_size_override("font_size", 32)
	le.custom_minimum_size = Vector2(0, 70)
	right.add_child(le)
	right.add_child(big_btn("Подключиться", join_game.bind(le), Color("2f8cff"), Color.WHITE, 80, 34))
	row.add_child(right)
	v.add_child(row)
	lobby_status = Game.make_label(status, 28, Color("55eeff"))
	lobby_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(lobby_status)
	lobby_list = Game.make_label("", 28)
	v.add_child(lobby_list)
	lobby_start = big_btn("НАЧАТЬ МАТЧ", start_match_pressed, Color("ffd21f"), Color.BLACK, 90, 42)
	lobby_start.visible = Game.mp_host
	v.add_child(lobby_start)
	_refresh_lobby()

func _refresh_lobby() -> void:
	if lobby_list == null or not is_instance_valid(lobby_list):
		return
	var s: String = "Игроки в лобби:\n"
	for id in Game.mp_roster.keys():
		s += "• %s%s\n" % [Game.mp_roster[id]["name"], " (хост)" if int(id) == 1 else ""]
	lobby_list.text = s

func _mp_status(text: String) -> void:
	if lobby_status != null and is_instance_valid(lobby_status):
		lobby_status.text = text

func _mp_connect_signals() -> void:
	if mp_signals:
		return
	mp_signals = true
	multiplayer.connected_to_server.connect(_on_mp_connected)
	multiplayer.connection_failed.connect(_on_mp_failed)
	multiplayer.server_disconnected.connect(_on_mp_server_lost)
	multiplayer.peer_disconnected.connect(_on_mp_peer_left)

func host_game() -> void:
	Game.mp_leave()
	var peer: ENetMultiplayerPeer = ENetMultiplayerPeer.new()
	var err: int = peer.create_server(MP_PORT, 7)
	if err != OK:
		_mp_status("Не удалось создать игру (порт %d занят?)" % MP_PORT)
		return
	multiplayer.multiplayer_peer = peer
	Game.mp_host = true
	Game.mp_roster = {1: {"name": Game.nickname, "char": Game.s["sel"]}}
	_mp_connect_signals()
	lobby_start.visible = true
	_mp_status("Игра создана! Назови друзьям свой IP (порт %d). Когда все зайдут — жми «НАЧАТЬ МАТЧ»." % MP_PORT)
	_refresh_lobby()

func join_game(le: LineEdit) -> void:
	var ip: String = le.text.strip_edges()
	if ip == "":
		_mp_status("Введите IP хоста")
		return
	Game.mp_leave()
	var peer: ENetMultiplayerPeer = ENetMultiplayerPeer.new()
	var err: int = peer.create_client(ip, MP_PORT)
	if err != OK:
		_mp_status("Не удалось начать подключение (проверьте IP)")
		return
	multiplayer.multiplayer_peer = peer
	_mp_connect_signals()
	_mp_status("Подключение к %s ..." % ip)

func start_match_pressed() -> void:
	if not Game.mp_host:
		return
	rpc("rpc_start_match")

func _on_mp_connected() -> void:
	rpc_id(1, "rpc_hello", Game.nickname, Game.s["sel"])
	_mp_status("Подключено! Ждём, пока хост начнёт матч...")

func _on_mp_failed() -> void:
	Game.mp_leave()
	_mp_status("Не удалось подключиться. Проверьте IP и что вы в одной сети.")

func _on_mp_server_lost() -> void:
	Game.mp_leave()
	if battle != null:
		remove_child(battle)
		battle.queue_free()
		battle = null
		content.visible = true
		bg_rect.visible = true
		Game.play_music("menu")
	show_lobby("Хост отключился")

func _on_mp_peer_left(id: int) -> void:
	if multiplayer.is_server():
		Game.mp_roster.erase(id)
		rpc("rpc_roster", Game.mp_roster)
		_refresh_lobby()
		if battle != null and battle.get("net") != null:
			battle.get("net").sync_roster()

@rpc("any_peer", "call_remote", "reliable")
func rpc_hello(pname: String, char_id: String) -> void:
	if not multiplayer.is_server():
		return
	var id: int = multiplayer.get_remote_sender_id()
	Game.mp_roster[id] = {"name": pname, "char": char_id}
	rpc("rpc_roster", Game.mp_roster)
	_refresh_lobby()

@rpc("authority", "call_remote", "reliable")
func rpc_roster(r: Dictionary) -> void:
	Game.mp_roster = r
	_refresh_lobby()
	if battle != null and battle.get("net") != null:
		battle.get("net").sync_roster()

@rpc("authority", "call_local", "reliable")
func rpc_start_match() -> void:
	start_battle("mp")
