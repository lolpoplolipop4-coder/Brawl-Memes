extends "res://scripts/base_fps.gd"
# SCHOOL CHAOS: first-person comedy adventure in a large Soviet-style school with NPC teacher missions.

const H: float = 3.4
const ITEM_NAMES: Dictionary = {"sock": "второй носок", "potato": "мешок картошки", "cucumber": "огурец", "diary": "дневник физрука", "bun": "булочка"}

var NPCS: Dictionary = {
	"bio": {"name": "Биологичка Тамара Петровна", "tex": "a04", "pos": Vector3(-16, 0, -11.8), "idle": ["Иди учись, пока я не заставила тебя пересаживать фикус!", "Знаешь, чем картошка лучше двоечника? Картошка хотя бы даёт урожай.", "Тихо! Моя герань слушает Баха."]},
	"director": {"name": "Директор Иван Сергеевич", "tex": "b06", "pos": Vector3(32, 0, 12.6), "idle": ["Я очень занят. Видишь, я смотрю в окно с важным видом.", "Если услышишь звонок — это не перемена, это мой будильник.", "Расписание у меня в голове. Но голова сейчас на обеде."]},
	"pe": {"name": "Физрук Палыч", "tex": "a08", "pos": Vector3(-24, 0, 8.8), "idle": ["Три круга вокруг школы! Зачем? Для здоровья и моей рыбалки!", "Свисток — мой посох. Слушайся свистка!", "Я не толстый, я — тактический запас энергии."]},
	"cook": {"name": "Повариха Тётя Валя", "tex": "b04", "pos": Vector3(0, 0, 12.8), "idle": ["Компот сегодня по особому рецепту: никто не знает, из чего.", "Котлета — это не еда, это судьба на тарелке.", "Булочки не растут на деревьях! Они растут на противнях."]},
	"chem": {"name": "Химичка Эльвира Марковна", "tex": "a01", "pos": Vector3(0, 0, -11.8), "idle": ["Не трогай колбу с надписью «НЕ ТРОГАТЬ». Особенно если она подмигивает.", "На прошлой неделе я случайно вывела говорящий огурец. Он ушёл в политику.", "Реакции нет? Тогда добавь ещё немного драмы."]},
	"lib": {"name": "Библиотекарь Зинаида", "tex": "b07", "pos": Vector3(16, 0, -11.8), "idle": ["ТШШШ! Книги спят.", "Эта книга опаздывает с возвратом с 1987 года. Мы ждём.", "Читай, а то мозг превратится в кисель."]},
	"vice": {"name": "Завуч Аркадий Львович", "tex": "b02", "pos": Vector3(28.5, 0, -11.5), "idle": ["Опоздал на урок? Это не опоздание, это эксклюзивный выход.", "Чай в учительской закончился. Это чрезвычайная ситуация федерального масштаба.", "Дневник! Где дневник? А, это не твой, это мой."]},
}

var MISSIONS: Array = [
	{"npc": "bio", "title": "Второй носок и картошка", "goal": {"sock": 1, "potato": 5}, "coins": 150, "gems": 20,
		"intro": ["ГДЕ МОИ ПЯТЬ МЕШКОВ КАРТОШКИ?!", "Ты не понимаешь! Без картошки сорвана лабораторная «Размножение корнеплодов»!", "И ещё: я потеряла второй носок. Левый, в красную полоску. Он где-то в школе — я чувствую это пяткой.", "Найди ВТОРОЙ НОСОК и ПЯТЬ МЕШКОВ КАРТОШКИ и принеси мне. Награда будет ужасно щедрой!"],
		"wait": ["Ты принёс не всё?! Моя картошка плачет в одиночестве, а нога мёрзнет!"],
		"done": ["НОСОК! И КАРТОШКА! Все пять мешков!", "Ты спас лабораторную работу и мою левую ногу. Держи награду, герой!"]},
	{"npc": "director", "title": "Огуречная доставка", "goal": {"cucumber": 12}, "coins": 250, "gems": 30,
		"intro": ["Молодой человек! У школы чрезвычайная ситуация: у меня закончились огурцы.", "Ровно двенадцать штук. Совет школы собирается на закрытый салатный комитет.", "Огурцы растут где попало: в кабинетах, во дворе, возможно, в столовой. Принеси мне двенадцать.", "И никому ни слова. Огурцы — государственная тайна!"],
		"wait": ["Огурцов не хватает! Салат без огурцов — это просто грусть в миске."],
		"done": ["Двенадцать огурцов. Идеально. Я прослезился.", "Объявляю тебе благодарность и вот эту награду. Салатный комитет спасён!"]},
	{"npc": "pe", "title": "Дневник физрука", "goal": {"diary": 1}, "coins": 300, "gems": 40,
		"intro": ["Мой дневник пропал! Там оценки, расписание рыбалки и рецепт фирменного компота!", "Я оставил его где-то в школе... Может, в учительской? Я там после урока чаёвничал.", "Найди дневник и верни — освобожу от бега на целый день! Ну, на один урок."],
		"wait": ["Дневника нет? Без него я не знаю, какой сегодня день недели!"],
		"done": ["МОЙ ДНЕВНИК! Даже закладка с котиком цела!", "Ты настоящий спортсмен. Вот награда, а бегать всё равно будешь. Шучу!"]},
	{"npc": "cook", "title": "Великая доставка булочек", "goal": {"bun": 30}, "coins": 500, "gems": 60,
		"intro": ["Дорогой! Завтра приедет инспекция из Министерства Булок!", "Булочки разбежались по всей школе — на партах, в коридорах, даже во дворе. Мне нужно ТРИДЦАТЬ штук!", "Собери все школьные булочки и принеси на кухню. Ни одной не съешь по дороге! Я считаю!"],
		"wait": ["Булочек меньше тридцати! Инспектор заметит и заплачет."],
		"done": ["Тридцать! Ровно тридцать! Я пересчитала дважды.", "Министерство Булок будет довольно. Держи награду и компот. Из чего? Лучше не знать."]},
]

var kit = null
var sd: Dictionary = {}
var items: Array = []
var npc_nodes: Dictionary = {}
var npc_excl: Dictionary = {}
var target: Dictionary = {}
var anim: Array = []
var dlg_ui: Control = null
var dlg_lines: Array = []
var dlg_idx: int = 0
var dlg_label: Label
var dlg_btn: Button
var dlg_cb: Callable = Callable()
var obj_l: Label
var mk_t: float = 0.0

func setup(m: String) -> void:
	mode = m
	vp = get_viewport().get_visible_rect().size
	base_speed = 5.2
	sd = Game.s["school"]
	for k in ITEM_NAMES.keys():
		if not sd["inv"].has(k):
			sd["inv"][k] = 0
	kit = Node3D.new()
	kit.set_script(load("res://scripts/village.gd"))
	add_child(kit)
	_environment()
	_yard()
	_building()
	_rooms()
	for id in NPCS.keys():
		_make_npc(id)
	_items()
	_make_player(Vector3(-54, 0.6, 0), -PI / 2.0)
	_make_base_hud()
	obj_l = Game.make_label("", 26)
	obj_l.position = Vector2(24, 52)
	layer.add_child(obj_l)
	_update_markers()
	banner("ШКОЛА №13\nНайди учителей и помоги им!", Color("ffd21f"), 2.5)

# ---------- world helpers ----------
func _environment() -> void:
	var we: WorldEnvironment = WorldEnvironment.new()
	var env: Environment = Environment.new()
	var sky: Sky = Sky.new()
	var sm: ProceduralSkyMaterial = ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.3, 0.55, 0.95)
	sm.sky_horizon_color = Color(0.8, 0.9, 1.0)
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(1, 1, 1)
	env.ambient_light_energy = 0.95
	we.environment = env
	add_child(we)
	var sun: DirectionalLight3D = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50.0, 40.0, 0.0)
	sun.light_energy = 0.55
	add_child(sun)

func _label(parent: Node3D, text: String, pos: Vector3, fs: int, ps: float, col: Color, rot_y: float = 0.0) -> Label3D:
	var l: Label3D = Label3D.new()
	l.text = text
	l.font_size = fs
	l.pixel_size = ps
	l.modulate = col
	l.outline_size = 8
	l.outline_modulate = Color(0, 0, 0)
	l.position = pos
	l.rotation_degrees = Vector3(0, rot_y, 0)
	parent.add_child(l)
	return l

func _box_body(pos: Vector3, size: Vector3, col: Color) -> void:
	var b: StaticBody3D = kit.body_at(pos)
	kit.add_box(b, Vector3.ZERO, size, kit.cmat(col))
	kit.add_col(b, Vector3.ZERO, size)

func _seg(cx: float, cz: float, sx: float, sz: float, lower: Color, upper: Color) -> void:
	var b: StaticBody3D = kit.body_at(Vector3(cx, 0, cz))
	kit.add_box(b, Vector3(0, 0.65, 0), Vector3(sx, 1.3, sz), kit.cmat(lower))
	kit.add_box(b, Vector3(0, 1.3 + (H - 1.3) / 2.0, 0), Vector3(sx, H - 1.3, sz), kit.cmat(upper))
	kit.add_col(b, Vector3(0, H / 2.0, 0), Vector3(sx, H, sz))

func _wall_x(z: float, xa: float, xb: float, gaps: Array, lower: Color, upper: Color, gw: float = 2.4) -> void:
	var cur: float = xa
	for g in gaps:
		var g0: float = float(g) - gw / 2.0
		var g1: float = float(g) + gw / 2.0
		if g0 > cur:
			_seg((cur + g0) / 2.0, z, g0 - cur, 0.3, lower, upper)
		_box_body(Vector3(float(g), 3.0, z), Vector3(gw, 0.8, 0.3), upper)
		cur = g1
	if xb > cur:
		_seg((cur + xb) / 2.0, z, xb - cur, 0.3, lower, upper)

func _wall_z(x: float, za: float, zb: float, gaps: Array, lower: Color, upper: Color, gw: float = 2.4) -> void:
	var cur: float = za
	for g in gaps:
		var g0: float = float(g) - gw / 2.0
		var g1: float = float(g) + gw / 2.0
		if g0 > cur:
			_seg(x, (cur + g0) / 2.0, 0.3, g0 - cur, lower, upper)
		_box_body(Vector3(x, 3.0, float(g)), Vector3(0.3, 0.8, gw), upper)
		cur = g1
	if zb > cur:
		_seg(x, (cur + zb) / 2.0, 0.3, zb - cur, lower, upper)

# ---------- yard ----------
func _yard() -> void:
	var g: StaticBody3D = kit.body_at(Vector3.ZERO)
	kit.add_box(g, Vector3(0, -0.05, -10), Vector3(260, 0.1, 180), kit.mat("grass", Color(0.95, 1.0, 0.9), 0.3))
	kit.add_col(g, Vector3(0, -1.0, -10), Vector3(260, 2.0, 180))
	kit.add_box(kit, Vector3(0, 0.03, -30), Vector3(80, 0.06, 26), kit.mat("stone", Color(0.45, 0.45, 0.48), 0.3))
	kit.add_box(kit, Vector3(-47, 0.03, 0), Vector3(14, 0.05, 3.4), kit.mat("dirt", Color.WHITE, 0.3))
	kit.fence(Vector3(-70, 0, -60), Vector3(70, 0, -60))
	kit.fence(Vector3(70, 0, -60), Vector3(70, 0, 40))
	kit.fence(Vector3(70, 0, 40), Vector3(-70, 0, 40))
	kit.fence(Vector3(-70, 0, 40), Vector3(-70, 0, -60))
	for d in [[Vector3(0, 5, -64), Vector3(300, 10, 2)], [Vector3(0, 5, 44), Vector3(300, 10, 2)], [Vector3(-74, 5, -10), Vector3(2, 10, 120)], [Vector3(74, 5, -10), Vector3(2, 10, 120)]]:
		var b: StaticBody3D = kit.body_at(d[0])
		kit.add_col(b, Vector3.ZERO, d[1])
	kit.rng.seed = 777
	var placed: int = 0
	var tries: int = 0
	while placed < 34 and tries < 300:
		tries += 1
		var p: Vector3 = Vector3(kit.rng.randf_range(-66, 66), 0, kit.rng.randf_range(-56, 36))
		if absf(p.x) < 46.0 and p.z > -18.0 and p.z < 18.0:
			continue
		if p.z < -17.0 and p.z > -44.0 and absf(p.x) < 42.0:
			continue
		if absf(p.x + 47.0) < 9.0 and absf(p.z) < 8.0:
			continue
		if kit.rng.randf() < 0.6:
			kit.birch(p)
		else:
			kit.spruce(p)
	# football goal
	var gl: StaticBody3D = kit.body_at(Vector3(-30, 0, -50))
	var wh: Material = kit.cmat(Color(1, 1, 1))
	kit.add_box(gl, Vector3(-3.5, 1.1, 0), Vector3(0.14, 2.2, 0.14), wh)
	kit.add_box(gl, Vector3(3.5, 1.1, 0), Vector3(0.14, 2.2, 0.14), wh)
	kit.add_box(gl, Vector3(0, 2.2, 0), Vector3(7.14, 0.14, 0.14), wh)
	kit.add_col(gl, Vector3(-3.5, 1.1, 0), Vector3(0.3, 2.2, 0.3))
	kit.add_col(gl, Vector3(3.5, 1.1, 0), Vector3(0.3, 2.2, 0.3))
	# basketball hoop
	var bh: StaticBody3D = kit.body_at(Vector3(22, 0, -32))
	kit.add_cyl(bh, Vector3(0, 1.6, 0), 0.08, 0.08, 3.2, kit.cmat(Color(0.3, 0.3, 0.35)), 8)
	kit.add_box(bh, Vector3(0, 3.2, 0.3), Vector3(1.8, 1.1, 0.08), wh)
	var ring: TorusMesh = TorusMesh.new()
	ring.inner_radius = 0.2
	ring.outer_radius = 0.26
	var rm: MeshInstance3D = MeshInstance3D.new()
	rm.mesh = ring
	rm.material_override = kit.cmat(Color(1.0, 0.45, 0.1))
	rm.position = Vector3(0, 2.95, 0.65)
	bh.add_child(rm)
	kit.add_cyl_col(bh, Vector3(0, 1.6, 0), 0.2, 3.2)
	# benches along the wall
	for x in [-30.0, -10.0, 10.0, 30.0]:
		var bn: StaticBody3D = kit.body_at(Vector3(x, 0, -16.2))
		kit.add_box(bn, Vector3(0, 0.45, 0), Vector3(2.4, 0.1, 0.5), kit.mat("planks", Color.WHITE, 0.6))
		kit.add_box(bn, Vector3(0, 0.85, -0.22), Vector3(2.4, 0.5, 0.08), kit.mat("planks", Color.WHITE, 0.6))
		kit.add_col(bn, Vector3(0, 0.5, 0), Vector3(2.4, 1.0, 0.6))
	# garden beds with cucumbers
	for gx in [-45.0, -42.0]:
		kit.add_box(kit, Vector3(gx, 0.12, -21.5), Vector3(2.4, 0.24, 6.0), kit.cmat(Color(0.3, 0.2, 0.12)))
		for i in 3:
			kit.add_sphere(kit, Vector3(gx, 0.45, -23.5 + float(i) * 2.0), 0.55, kit.cmat(Color(0.2, 0.6, 0.25)))
	# flagpole by the entrance
	var fp: StaticBody3D = kit.body_at(Vector3(-46, 0, 8))
	kit.add_cyl(fp, Vector3(0, 3.5, 0), 0.07, 0.07, 7.0, kit.cmat(Color(0.8, 0.8, 0.85)), 8)
	kit.add_box(fp, Vector3(0.7, 6.3, 0), Vector3(1.4, 0.45, 0.04), kit.cmat(Color(1, 1, 1)))
	kit.add_box(fp, Vector3(0.7, 5.95, 0), Vector3(1.4, 0.3, 0.04), kit.cmat(Color(0.2, 0.4, 0.9)))
	kit.add_box(fp, Vector3(0.7, 5.65, 0), Vector3(1.4, 0.3, 0.04), kit.cmat(Color(0.9, 0.15, 0.15)))
	kit.add_cyl_col(fp, Vector3(0, 1.0, 0), 0.15, 2.0)

# ---------- building ----------
func _building() -> void:
	var teal: Color = Color(0.2, 0.55, 0.5)
	var cream: Color = Color(0.97, 0.94, 0.82)
	var brick: Color = Color(0.66, 0.3, 0.25)
	var yellow: Color = Color(0.98, 0.88, 0.55)
	kit.add_box(kit, Vector3(0, -0.04, 0), Vector3(80, 0.12, 28), kit.mat("tiles", Color.WHITE, 0.45))
	kit.add_box(kit, Vector3(-24, 0.0, 8.25), Vector3(31.8, 0.1, 11.4), kit.mat("planks", Color(1.0, 0.8, 0.5), 0.5))
	kit.add_box(kit, Vector3(0, 0.0, 8.25), Vector3(15.8, 0.1, 11.4), kit.mat("tiles", Color(0.75, 1.0, 0.85), 0.45))
	kit.add_box(kit, Vector3(0, H + 0.15, 0), Vector3(81, 0.3, 29), kit.cmat(Color(0.97, 0.95, 0.9)))
	var doors: Array = [-32.0, -16.0, 0.0, 16.0, 32.0]
	_wall_x(-2.5, -40.0, 40.0, doors, teal, cream)
	_wall_x(2.5, -40.0, 40.0, doors, teal, cream)
	_wall_x(-14.0, -40.0, 40.0, [], brick, yellow)
	_wall_x(14.0, -40.0, 40.0, [], brick, yellow)
	_wall_z(-40.0, -14.0, 14.0, [0.0], brick, yellow, 3.4)
	_wall_z(40.0, -14.0, 14.0, [0.0], brick, yellow, 3.4)
	for x in [-24.0, -8.0, 8.0, 24.0]:
		_wall_z(x, -14.0, -2.5, [], teal, cream)
	for x in [-8.0, 8.0, 24.0]:
		_wall_z(x, 2.5, 14.0, [], teal, cream)
	# windows on outer walls
	for i in 10:
		var wx: float = -36.0 + float(i) * 8.0
		for wz in [-14.0, 14.0]:
			kit.add_box(kit, Vector3(wx, 1.95, wz), Vector3(2.6, 1.8, 0.42), kit.cmat(Color(1, 1, 1)))
			kit.add_box(kit, Vector3(wx, 1.95, wz), Vector3(2.2, 1.4, 0.46), kit.cmat(Color(0.55, 0.78, 0.95)))
	# lamps and fans
	for i in 10:
		kit.add_box(kit, Vector3(-36.0 + float(i) * 8.0, H - 0.04, 0.0), Vector3(1.6, 0.06, 0.5), kit.cmat(Color(1, 1, 0.85), true))
	for p in [Vector3(-32, H - 0.04, -8), Vector3(-16, H - 0.04, -8), Vector3(0, H - 0.04, -8), Vector3(16, H - 0.04, -8), Vector3(32, H - 0.04, -8), Vector3(16, H - 0.04, 8), Vector3(32, H - 0.04, 8), Vector3(0, H - 0.04, 8), Vector3(-30, H - 0.04, 8), Vector3(-18, H - 0.04, 8)]:
		kit.add_box(kit, p, Vector3(1.4, 0.06, 1.0), kit.cmat(Color(1, 1, 0.85), true))
	for p in [Vector3(-24, H - 0.2, 8.25), Vector3(0, H - 0.2, 8.25), Vector3(-20, H - 0.2, 0), Vector3(20, H - 0.2, 0)]:
		var fan: Node3D = Node3D.new()
		fan.position = p
		kit.add_child(fan)
		kit.add_box(fan, Vector3.ZERO, Vector3(2.4, 0.04, 0.25), kit.cmat(Color(0.5, 0.35, 0.2)))
		kit.add_box(fan, Vector3.ZERO, Vector3(0.25, 0.04, 2.4), kit.cmat(Color(0.5, 0.35, 0.2)))
		anim.append({"t": "spin", "n": fan, "sp": 4.0})
	# door signs and entrance sign
	var names_n: Array = ["КАБИНЕТ 1", "БИОЛОГИЯ", "ХИМИЯ", "БИБЛИОТЕКА", "УЧИТЕЛЬСКАЯ"]
	var names_s: Array = ["СПОРТЗАЛ", "СПОРТЗАЛ", "СТОЛОВАЯ", "КАБИНЕТ 2", "ДИРЕКТОР"]
	for i in 5:
		_label(kit, names_n[i], Vector3(doors[i], 3.0, -2.3), 44, 0.008, Color(1, 0.95, 0.6), 0.0)
		_label(kit, names_s[i], Vector3(doors[i], 3.0, 2.3), 44, 0.008, Color(1, 0.95, 0.6), 180.0)
	_label(kit, "ШКОЛА №13", Vector3(-40.35, 3.0, 0), 120, 0.012, Color(1, 1, 1), -90.0)
	_label(kit, "Добро пожаловать!", Vector3(-40.35, 2.35, 0), 40, 0.01, Color(1, 0.9, 0.5), -90.0)
	_label(kit, "ШКОЛА №13", Vector3(40.35, 3.0, 0), 120, 0.012, Color(1, 1, 1), 90.0)
	_label(kit, "КОРИДОР", Vector3(0, 3.05, 0.0), 1, 0.01, Color(1, 1, 1), 0.0).visible = false
	# corridor decor: portraits and cartoon posters
	for i in 8:
		var px: float = -36.0 + float(i) * 10.0
		kit.add_box(kit, Vector3(px + 4.0, 1.9, -2.32), Vector3(0.9, 1.1, 0.04), kit.cmat(Color(0.5, 0.33, 0.2)))
		kit.add_box(kit, Vector3(px + 4.0, 1.9, -2.3), Vector3(0.75, 0.95, 0.04), kit.cmat(Color(0.95, 0.85, 0.7 - float(i % 3) * 0.15)))
	_label(kit, "БЕГАТЬ ПО КОРИДОРУ\nЗАПРЕЩЕНО!\n(кроме физрука)", Vector3(-20.0, 1.9, 2.32), 40, 0.007, Color(1, 0.3, 0.3), 180.0)
	_label(kit, "СМЕНКА ОБУВИ\nОБЯЗАТЕЛЬНА!", Vector3(20.0, 1.9, 2.32), 40, 0.007, Color(0.3, 0.3, 1.0), 180.0)

# ---------- furniture ----------
func _desk(pos: Vector3, rot: float) -> void:
	var b: StaticBody3D = kit.body_at(pos, rot)
	kit.add_box(b, Vector3(0, 0.74, 0), Vector3(1.2, 0.06, 0.55), kit.mat("planks", Color(0.9, 0.8, 0.6), 0.6))
	kit.add_box(b, Vector3(-0.54, 0.37, 0), Vector3(0.05, 0.74, 0.5), kit.cmat(Color(0.3, 0.3, 0.35)))
	kit.add_box(b, Vector3(0.54, 0.37, 0), Vector3(0.05, 0.74, 0.5), kit.cmat(Color(0.3, 0.3, 0.35)))
	kit.add_box(b, Vector3(0, 0.45, 0.6), Vector3(0.42, 0.05, 0.42), kit.cmat(Color(0.25, 0.45, 0.8)))
	kit.add_box(b, Vector3(0, 0.72, 0.8), Vector3(0.42, 0.4, 0.05), kit.cmat(Color(0.25, 0.45, 0.8)))
	kit.add_col(b, Vector3(0, 0.4, 0.2), Vector3(1.2, 0.8, 1.2))

func _table(pos: Vector3, rot: float, w: float, d: float, benches: bool) -> void:
	var b: StaticBody3D = kit.body_at(pos, rot)
	kit.add_box(b, Vector3(0, 0.76, 0), Vector3(w, 0.08, d), kit.mat("planks", Color(0.95, 0.85, 0.65), 0.6))
	for sx in [-1.0, 1.0]:
		kit.add_box(b, Vector3(sx * (w / 2.0 - 0.1), 0.38, 0), Vector3(0.08, 0.76, d - 0.1), kit.cmat(Color(0.3, 0.3, 0.35)))
	if benches:
		for sz in [-1.0, 1.0]:
			kit.add_box(b, Vector3(0, 0.45, sz * (d / 2.0 + 0.35)), Vector3(w, 0.08, 0.35), kit.cmat(Color(0.85, 0.35, 0.25)))
	kit.add_col(b, Vector3(0, 0.45, 0), Vector3(w, 0.9, d + (1.1 if benches else 0.0)))

func _board(pos: Vector3, rot: float, txt: String) -> void:
	var n: Node3D = Node3D.new()
	n.position = pos
	n.rotation_degrees = Vector3(0, rot, 0)
	kit.add_child(n)
	kit.add_box(n, Vector3(0, 1.75, 0), Vector3(4.2, 1.4, 0.06), kit.cmat(Color(0.15, 0.35, 0.25)))
	kit.add_box(n, Vector3(0, 1.0, 0.05), Vector3(4.4, 0.08, 0.14), kit.cmat(Color(0.5, 0.35, 0.2)))
	_label(n, txt, Vector3(0, 1.8, 0.05), 36, 0.007, Color(1, 1, 1))

func _shelf(pos: Vector3, rot: float, w: float) -> void:
	var b: StaticBody3D = kit.body_at(pos, rot)
	kit.add_box(b, Vector3(0, 1.2, 0), Vector3(w, 2.4, 0.5), kit.mat("books", Color.WHITE, 0.7))
	kit.add_col(b, Vector3(0, 1.2, 0), Vector3(w, 2.4, 0.5))

func _flask(parent: Node3D, pos: Vector3, col: Color) -> void:
	kit.add_cyl(parent, pos + Vector3(0, 0.12, 0), 0.08, 0.1, 0.24, kit.cmat(col), 10)
	kit.add_cyl(parent, pos + Vector3(0, 0.3, 0), 0.03, 0.03, 0.16, kit.cmat(Color(0.8, 0.9, 1.0)), 8)

func _classroom(cx: float, north: bool, board_txt: String) -> void:
	var z0: float = -14.0 if north else 14.0
	var dr: float = 1.0 if north else -1.0
	var rot: float = 0.0 if north else 180.0
	for r in 4:
		var z: float = z0 + dr * (2.3 + float(r) * 2.2)
		for dx in [-5.2, -2.8, 2.8, 5.2]:
			_desk(Vector3(cx + float(dx), 0, z), rot)
	_board(Vector3(cx, 0, z0 + dr * 0.2), rot, board_txt)
	var td: StaticBody3D = kit.body_at(Vector3(cx + 4.8, 0, z0 + dr * 1.6), rot)
	kit.add_box(td, Vector3(0, 0.74, 0), Vector3(1.8, 0.08, 0.8), kit.mat("planks", Color(0.8, 0.6, 0.4), 0.6))
	kit.add_box(td, Vector3(0, 0.37, 0), Vector3(1.7, 0.74, 0.7), kit.cmat(Color(0.55, 0.4, 0.28)))
	kit.add_col(td, Vector3(0, 0.45, 0), Vector3(1.8, 0.9, 0.8))

func _plant(pos: Vector3) -> void:
	var b: StaticBody3D = kit.body_at(pos)
	kit.add_cyl(b, Vector3(0, 0.25, 0), 0.28, 0.2, 0.5, kit.cmat(Color(0.7, 0.35, 0.2)), 10)
	kit.add_sphere(b, Vector3(0, 0.75, 0), 0.4, kit.cmat(Color(0.25, 0.65, 0.3)))
	kit.add_cyl_col(b, Vector3(0, 0.5, 0), 0.3, 1.0)

func _rooms() -> void:
	_classroom(-32.0, true, "ЗАДАЧА №5:\nЕсли из А в Б вышел поезд...")
	_classroom(-16.0, true, "ТЕМА: КАРТОШКА\nкак форма жизни")
	_classroom(16.0, false, "ДИКТАНТ:\n«Жы-шы пиши с буквой Ы»")
	# biology decor
	var sk: StaticBody3D = kit.body_at(Vector3(-22.6, 0, -12.8))
	var bone: Material = kit.cmat(Color(0.96, 0.95, 0.88))
	kit.add_sphere(sk, Vector3(0, 1.75, 0), 0.17, bone)
	kit.add_cyl(sk, Vector3(0, 1.2, 0), 0.04, 0.04, 1.0, bone, 6)
	for i in 4:
		kit.add_box(sk, Vector3(0, 1.45 - float(i) * 0.12, 0), Vector3(0.45, 0.04, 0.2), bone)
	kit.add_box(sk, Vector3(0, 0.72, 0), Vector3(0.35, 0.12, 0.2), bone)
	kit.add_cyl_col(sk, Vector3(0, 1.0, 0), 0.35, 2.0)
	for z in [-6.0, -8.5, -11.0]:
		_plant(Vector3(-8.7, 0, z))
	_label(kit, "КАРТОШКА —\nВТОРОЙ ХЛЕБ!", Vector3(-8.2, 2.1, -8.0), 44, 0.008, Color(1, 0.9, 0.5), -90.0)
	var globe: Node3D = Node3D.new()
	globe.position = Vector3(-22.0, 1.4, -4.0)
	kit.add_child(globe)
	kit.add_cyl(globe, Vector3(0, -0.6, 0), 0.04, 0.04, 1.0, kit.cmat(Color(0.4, 0.3, 0.2)), 6)
	kit.add_sphere(globe, Vector3.ZERO, 0.4, kit.cmat(Color(0.3, 0.6, 0.95)))
	kit.add_sphere(globe, Vector3(0.2, 0.15, 0.28), 0.18, kit.cmat(Color(0.3, 0.75, 0.35)))
	anim.append({"t": "spin", "n": globe, "sp": 1.0})
	# chemistry
	for p in [Vector3(-3.6, 0, -9.5), Vector3(3.6, 0, -9.5), Vector3(-3.6, 0, -6.0), Vector3(3.6, 0, -6.0)]:
		_table(p, 0.0, 3.0, 1.0, false)
		var cols: Array = [Color(0.2, 0.9, 0.3), Color(1.0, 0.3, 0.7), Color(0.3, 0.6, 1.0), Color(1.0, 0.8, 0.2)]
		for i in 4:
			_flask(self, p + Vector3(-1.1 + float(i) * 0.7, 0.8, 0), cols[i])
	kit.add_box(kit, Vector3(0, 1.9, -13.9), Vector3(4.2, 2.4, 0.04), kit.mat("rainbow", Color.WHITE, 0.4))
	_label(kit, "ТАБЛИЦА МЕНДЕЛЕЕВА", Vector3(0, 3.25, -13.85), 30, 0.007, Color(1, 1, 1))
	# library
	for x in [10.5, 13.5, 18.5, 21.5]:
		_shelf(Vector3(x, 0, -13.6), 0.0, 2.8)
	for x in [12.0, 20.0]:
		_table(Vector3(x, 0, -5.2), 0.0, 2.2, 1.0, false)
	_shelf(Vector3(8.5, 0, -8.0), 90.0, 4.0)
	_shelf(Vector3(23.5, 0, -8.0), 90.0, 4.0)
	_label(kit, "ТИШЕ!", Vector3(16.0, 2.9, -13.8), 80, 0.01, Color(1, 0.4, 0.3))
	# teachers' room
	_table(Vector3(32.0, 0, -8.0), 0.0, 5.0, 1.6, true)
	var sofa: StaticBody3D = kit.body_at(Vector3(37.0, 0, -12.6))
	kit.add_box(sofa, Vector3(0, 0.3, 0), Vector3(3.0, 0.6, 1.0), kit.cmat(Color(0.7, 0.25, 0.3)))
	kit.add_box(sofa, Vector3(0, 0.8, -0.4), Vector3(3.0, 0.9, 0.25), kit.cmat(Color(0.6, 0.2, 0.25)))
	kit.add_col(sofa, Vector3(0, 0.5, 0), Vector3(3.0, 1.0, 1.0))
	kit.add_cyl(self, Vector3(32.6, 0.9, -8.0), 0.12, 0.14, 0.24, kit.cmat(Color(0.85, 0.85, 0.9)), 10)
	_label(kit, "ЧАЙ ТОЛЬКО\nДЛЯ ПЕДСОСТАВА!", Vector3(26.0, 2.0, -13.8), 36, 0.008, Color(1, 0.9, 0.4))
	# gym
	for hz in [8.25]:
		for hx in [-39.4, -8.6]:
			var h: StaticBody3D = kit.body_at(Vector3(hx, 0, hz))
			kit.add_box(h, Vector3(0, 3.0, 0), Vector3(0.1, 1.1, 1.8), kit.cmat(Color(1, 1, 1)))
			var rg: TorusMesh = TorusMesh.new()
			rg.inner_radius = 0.2
			rg.outer_radius = 0.26
			var rmi: MeshInstance3D = MeshInstance3D.new()
			rmi.mesh = rg
			rmi.material_override = kit.cmat(Color(1.0, 0.45, 0.1))
			rmi.position = Vector3(0.4 if hx < 0 and hx < -20 else -0.4, 2.7, 0)
			h.add_child(rmi)
	for p in [Vector3(-32, 0.15, 12.8), Vector3(-29.5, 0.15, 12.8), Vector3(-27, 0.15, 12.8)]:
		_box_body(p, Vector3(2.2, 0.3, 1.0), Color(0.3, 0.55, 0.95))
	_box_body(Vector3(-32, 0.5, 6.2), Vector3(1.4, 1.0, 0.7), Color(0.75, 0.3, 0.25))
	_box_body(Vector3(-16, 0.2, 3.3), Vector3(3.0, 0.4, 0.4), Color(0.6, 0.45, 0.25))
	for x in [-16.0, -15.4, -14.8]:
		kit.add_cyl(self, Vector3(x, 1.85, 12.6), 0.05, 0.05, 3.0, kit.cmat(Color(0.75, 0.6, 0.35)), 6)
	var ball: MeshInstance3D = kit.add_sphere(self, Vector3(-20.0, 0.3, 8.0), 0.25, kit.cmat(Color(1.0, 0.5, 0.15)))
	anim.append({"t": "ball", "n": ball, "base": 0.3})
	_label(kit, "СДАЛ НОРМУ —\nНЕ ХВАСТАЙСЯ!", Vector3(-24.0, 2.4, 13.8), 50, 0.01, Color(1, 1, 0.5), 180.0)
	# cafeteria
	for tx in [-4.0, 4.0]:
		for tz in [5.0, 8.0]:
			_table(Vector3(tx, 0, tz), 0.0, 3.2, 0.9, true)
	var cn: StaticBody3D = kit.body_at(Vector3(0, 0, 11.4))
	kit.add_box(cn, Vector3(0, 0.5, 0), Vector3(8.0, 1.0, 0.8), kit.cmat(Color(0.85, 0.85, 0.9)))
	kit.add_box(cn, Vector3(0, 1.02, 0), Vector3(8.2, 0.06, 1.0), kit.cmat(Color(0.35, 0.35, 0.4)))
	kit.add_col(cn, Vector3(0, 0.5, 0), Vector3(8.0, 1.0, 0.9))
	for px in [-2.5, 0.0, 2.5]:
		kit.add_cyl(cn, Vector3(px, 1.3, 0), 0.35, 0.35, 0.5, kit.cmat(Color(0.7, 0.7, 0.75)), 12)
		kit.smoke(cn, Vector3(px, 1.65, 0))
	_label(kit, "МЕНЮ:\nКОМПОТ, БУЛОЧКА\nи тайна повара", Vector3(0.0, 2.3, 13.8), 44, 0.009, Color(1, 0.95, 0.6), 180.0)
	# director's office
	kit.add_box(kit, Vector3(32, 0.04, 8.5), Vector3(6, 0.04, 4), kit.cmat(Color(0.7, 0.1, 0.12)))
	var dk: StaticBody3D = kit.body_at(Vector3(32, 0, 10.8))
	kit.add_box(dk, Vector3(0, 0.74, 0), Vector3(3.2, 0.1, 1.3), kit.mat("planks", Color(0.7, 0.5, 0.35), 0.6))
	kit.add_box(dk, Vector3(0, 0.37, 0), Vector3(3.0, 0.74, 1.2), kit.cmat(Color(0.45, 0.3, 0.2)))
	kit.add_col(dk, Vector3(0, 0.45, 0), Vector3(3.2, 0.9, 1.3))
	var fl: StaticBody3D = kit.body_at(Vector3(25.5, 0, 13.4))
	kit.add_cyl(fl, Vector3(0, 1.4, 0), 0.05, 0.05, 2.8, kit.cmat(Color(0.8, 0.8, 0.8)), 6)
	kit.add_box(fl, Vector3(0.45, 2.4, 0), Vector3(0.9, 0.3, 0.04), kit.cmat(Color(1, 1, 1)))
	kit.add_box(fl, Vector3(0.45, 2.1, 0), Vector3(0.9, 0.3, 0.04), kit.cmat(Color(0.2, 0.4, 0.9)))
	kit.add_box(fl, Vector3(0.45, 1.8, 0), Vector3(0.9, 0.3, 0.04), kit.cmat(Color(0.9, 0.15, 0.15)))
	kit.add_cyl_col(fl, Vector3(0, 1.0, 0), 0.2, 2.0)
	_label(kit, "ДИРЕКТОР\nпринимает по записи\n(записей нет)", Vector3(38.0, 2.0, 13.8), 36, 0.008, Color(1, 0.9, 0.5), 180.0)
	# cabinet 1 / 2 extra funny posters
	_label(kit, "ТАБЛИЦА УМНОЖЕНИЯ:\n2×2=5 (проверено)", Vector3(-24.2, 2.0, -9.0), 36, 0.008, Color(1, 0.9, 0.5), 90.0)
	_label(kit, "ПРАВИЛО: ЧТО НА\nПАРТЕ — ТО В ПЕНАЛЕ", Vector3(8.2, 2.0, 8.0), 36, 0.008, Color(1, 0.9, 0.5), -90.0)

# ---------- NPCs and items ----------
func _make_npc(id: String) -> void:
	var d: Dictionary = NPCS[id]
	var b: StaticBody3D = kit.body_at(d["pos"])
	kit.add_cyl_col(b, Vector3(0, 1.0, 0), 0.5, 2.0)
	var spr: Sprite3D = Sprite3D.new()
	spr.texture = load("res://assets/stickers/%s.png" % d["tex"])
	spr.pixel_size = 0.0095
	spr.billboard = BaseMaterial3D.BILLBOARD_FIXED_Y
	spr.shaded = false
	spr.double_sided = true
	spr.alpha_cut = SpriteBase3D.ALPHA_CUT_OPAQUE_PREPASS
	spr.position = Vector3(0, 1.2, 0)
	b.add_child(spr)
	var lb: Label3D = Label3D.new()
	lb.text = d["name"]
	lb.font_size = 36
	lb.pixel_size = 0.008
	lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lb.outline_size = 10
	lb.position = Vector3(0, 2.75, 0)
	b.add_child(lb)
	var ex: Label3D = Label3D.new()
	ex.text = "!"
	ex.font_size = 140
	ex.pixel_size = 0.01
	ex.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	ex.modulate = Color(1.0, 0.85, 0.1)
	ex.outline_size = 16
	ex.position = Vector3(0, 3.5, 0)
	ex.visible = false
	b.add_child(ex)
	npc_nodes[id] = b
	npc_excl[id] = ex
	anim.append({"t": "bob", "n": spr, "base": 1.2, "ph": randf() * 6.0})

func _make_item(kind: String) -> Node3D:
	var n: Node3D = Node3D.new()
	if kind == "sock":
		kit.add_box(n, Vector3(0, 0.06, 0), Vector3(0.5, 0.1, 0.14), kit.cmat(Color(0.9, 0.2, 0.2)))
		kit.add_box(n, Vector3(-0.2, 0.22, 0), Vector3(0.12, 0.3, 0.14), kit.cmat(Color(0.9, 0.2, 0.2)))
		kit.add_box(n, Vector3(-0.2, 0.3, 0), Vector3(0.13, 0.06, 0.15), kit.cmat(Color(1, 1, 1)))
		kit.add_box(n, Vector3(0.1, 0.07, 0), Vector3(0.1, 0.11, 0.15), kit.cmat(Color(1, 1, 1)))
	elif kind == "potato":
		kit.add_box(n, Vector3(0, 0.28, 0), Vector3(0.5, 0.55, 0.35), kit.cmat(Color(0.78, 0.62, 0.38)))
		kit.add_box(n, Vector3(0, 0.62, 0), Vector3(0.22, 0.14, 0.2), kit.cmat(Color(0.6, 0.45, 0.25)))
		kit.add_sphere(n, Vector3(0.1, 0.35, 0.18), 0.09, kit.cmat(Color(0.65, 0.5, 0.25)))
		kit.add_sphere(n, Vector3(-0.12, 0.2, 0.18), 0.08, kit.cmat(Color(0.65, 0.5, 0.25)))
	elif kind == "cucumber":
		var c: MeshInstance3D = MeshInstance3D.new()
		var cm: CapsuleMesh = CapsuleMesh.new()
		cm.radius = 0.07
		cm.height = 0.4
		c.mesh = cm
		c.material_override = kit.cmat(Color(0.2, 0.7, 0.25))
		c.rotation_degrees = Vector3(0, 0, 90)
		c.position = Vector3(0, 0.08, 0)
		n.add_child(c)
	elif kind == "diary":
		kit.add_box(n, Vector3(0, 0.03, 0), Vector3(0.32, 0.05, 0.42), kit.cmat(Color(0.2, 0.35, 0.85)))
		kit.add_box(n, Vector3(0, 0.06, 0), Vector3(0.3, 0.02, 0.1), kit.cmat(Color(1, 1, 1)))
	else:
		kit.add_sphere(n, Vector3(0, 0.09, 0), 0.14, kit.cmat(Color(0.85, 0.55, 0.25)), Vector3(1.0, 0.65, 1.0))
		kit.add_sphere(n, Vector3(0, 0.15, 0), 0.08, kit.cmat(Color(1.0, 0.95, 0.85)), Vector3(1.0, 0.5, 1.0))
	var mk: Node3D = Node3D.new()
	mk.name = "mk"
	mk.position = Vector3(0, 1.1, 0)
	n.add_child(mk)
	var cone: MeshInstance3D = kit.add_cyl(mk, Vector3.ZERO, 0.0, 0.2, 0.38, kit.cmat(Color(1.0, 0.85, 0.2), true), 8)
	cone.rotation_degrees = Vector3(180, 0, 0)
	mk.visible = false
	return n

func _items() -> void:
	var spots: Dictionary = {
		"sock": [Vector3(-38.3, 0.12, 12.8)],
		"potato": [Vector3(6.5, 0, 13.2), Vector3(-6.5, 0, 13.2), Vector3(22, 0, -5), Vector3(6.5, 0, -12.8), Vector3(-36, 0, -19)],
		"cucumber": [Vector3(-21.5, 0, -6), Vector3(-10, 0, -12.5), Vector3(-18, 0, -4.2), Vector3(-45, 0.24, -20), Vector3(-42, 0.24, -21.5), Vector3(-45, 0.24, -23), Vector3(-5.5, 0, 4.2), Vector3(5.5, 0, 10), Vector3(-26, 0, -6), Vector3(-38, 0, -12.5), Vector3(36.5, 0, -5), Vector3(10, 0, 5)],
		"diary": [Vector3(32, 0.8, -8)],
		"bun": [Vector3(-4.6, 0.8, 5.0), Vector3(-3.4, 0.8, 5.0), Vector3(-4.6, 0.8, 8.0), Vector3(-3.4, 0.8, 8.0), Vector3(3.4, 0.8, 5.0), Vector3(4.6, 0.8, 5.0), Vector3(3.4, 0.8, 8.0), Vector3(4.6, 0.8, 8.0),
			Vector3(-36, 0, 1.6), Vector3(-28, 0, -1.6), Vector3(-20, 0, 1.6), Vector3(-12, 0, -1.6), Vector3(-4, 0, 1.6), Vector3(4, 0, -1.6), Vector3(12, 0, 1.6), Vector3(20, 0, -1.6),
			Vector3(-34.8, 0.8, -9.5), Vector3(-29.2, 0.8, -7.3), Vector3(13.2, 0.8, 9.5), Vector3(18.8, 0.8, 7.3), Vector3(-18.8, 0.8, -9.5), Vector3(-13.2, 0.8, -7.3), Vector3(12, 0.82, -5.2), Vector3(20, 0.82, -5.2),
			Vector3(-30, 0, -20), Vector3(-10, 0, -19), Vector3(10, 0, -21), Vector3(30, 0, -19), Vector3(0, 0, -36), Vector3(-20, 0, -31)],
	}
	var collected: Array = sd["collected"]
	for kind in spots.keys():
		var lst: Array = spots[kind]
		for i in lst.size():
			var id: String = "%s_%d" % [kind, i]
			if collected.has(id):
				continue
			var n: Node3D = _make_item(kind)
			n.position = lst[i]
			kit.add_child(n)
			items.append({"id": id, "kind": kind, "n": n, "mk": n.get_node("mk")})

# ---------- interaction ----------
func _prompt() -> String:
	target = {}
	if ui_lock:
		return ""
	var pp: Vector3 = player.global_position
	var best: float = 1e9
	for it in items:
		var n: Node3D = it["n"]
		var d: float = Vector2(pp.x - n.global_position.x, pp.z - n.global_position.z).length()
		if d < 2.3 and d < best and absf(pp.y + 1.0 - n.global_position.y) < 2.4:
			best = d
			target = {"type": "item", "ref": it}
	for id in npc_nodes.keys():
		var nn: Node3D = npc_nodes[id]
		var d2: float = Vector2(pp.x - nn.global_position.x, pp.z - nn.global_position.z).length()
		if d2 < 3.2 and d2 < best:
			best = d2
			target = {"type": "npc", "ref": id}
	if target.is_empty():
		return ""
	if target["type"] == "item":
		return "Взять: " + String(ITEM_NAMES[target["ref"]["kind"]])
	return "Поговорить: " + String(NPCS[target["ref"]]["name"])

func _do_interact() -> void:
	if target.is_empty():
		return
	if target["type"] == "item":
		var it: Dictionary = target["ref"]
		var kind: String = it["kind"]
		sd["inv"][kind] = int(sd["inv"][kind]) + 1
		sd["collected"].append(it["id"])
		(it["n"] as Node3D).queue_free()
		items.erase(it)
		Game.save_game()
		Game.vibrate(25)
		toast("Взял: %s  (всего: %d)" % [ITEM_NAMES[kind], int(sd["inv"][kind])])
		_update_markers()
	else:
		_talk(String(target["ref"]))

func _goal_met(m: Dictionary) -> bool:
	var goal: Dictionary = m["goal"]
	for k in goal.keys():
		if int(sd["inv"][k]) < int(goal[k]):
			return false
	return true

func _talk(id: String) -> void:
	var d: Dictionary = NPCS[id]
	var done: int = int(sd["done"])
	if done < MISSIONS.size():
		var m: Dictionary = MISSIONS[done]
		if m["npc"] == id:
			if not bool(sd["active"]):
				_show_dialog(d["name"], d["tex"], m["intro"], _accept_mission)
				return
			if _goal_met(m):
				_show_dialog(d["name"], d["tex"], m["done"], _complete_mission)
				return
			var lines: Array = (m["wait"] as Array).duplicate()
			lines.append(_progress_text(m))
			_show_dialog(d["name"], d["tex"], lines, Callable())
			return
	var idle: Array = d["idle"]
	var pick: String = idle[randi() % idle.size()]
	if done >= MISSIONS.size():
		pick = "Ты выполнил все задания! Школа гордится тобой. " + pick
	elif MISSIONS[done]["npc"] != id:
		pick = pick + "\n(Для тебя у меня пока нет заданий.)"
	_show_dialog(d["name"], d["tex"], [pick], Callable())

func _progress_text(m: Dictionary) -> String:
	var s: String = "У тебя сейчас:\n"
	var goal: Dictionary = m["goal"]
	for k in goal.keys():
		s += "%s: %d / %d\n" % [ITEM_NAMES[k], mini(int(sd["inv"][k]), int(goal[k])), int(goal[k])]
	return s

func _accept_mission() -> void:
	sd["active"] = true
	Game.save_game()
	var m: Dictionary = MISSIONS[int(sd["done"])]
	toast("Новое задание: " + String(m["title"]))
	_update_markers()

func _complete_mission() -> void:
	var done: int = int(sd["done"])
	var m: Dictionary = MISSIONS[done]
	var goal: Dictionary = m["goal"]
	for k in goal.keys():
		sd["inv"][k] = int(sd["inv"][k]) - int(goal[k])
	Game.s["coins"] = int(Game.s["coins"]) + int(m["coins"])
	Game.s["gems"] = int(Game.s["gems"]) + int(m["gems"])
	Game.s["xp"] = int(Game.s["xp"]) + 30
	sd["done"] = done + 1
	sd["active"] = false
	Game.save_game()
	Game.vibrate(80)
	banner("ЗАДАНИЕ ВЫПОЛНЕНО!\n+%d монет   +%d гемов" % [m["coins"], m["gems"]], Color("55ff88"), 3.0)
	if done + 1 < MISSIONS.size():
		toast("Новое задание: поговори с " + String(NPCS[MISSIONS[done + 1]["npc"]]["name"]))
	else:
		toast("Все задания выполнены!")
	_update_markers()

# ---------- dialog UI ----------
func _show_dialog(speaker: String, tex_id: String, lines: Array, cb: Callable) -> void:
	ui_lock = true
	move_idx = -1
	look_idx = -1
	sprint_idx = -1
	sprint_held = false
	joy_v = Vector2.ZERO
	dlg_lines = lines
	dlg_idx = 0
	dlg_cb = cb
	dlg_ui = Control.new()
	dlg_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(dlg_ui)
	var dim: ColorRect = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.35)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dlg_ui.add_child(dim)
	var panel: PanelContainer = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", Game.style(Color(0.07, 0.12, 0.4, 0.97), 24, 5))
	panel.position = Vector2(60, vp.y - 320)
	panel.size = Vector2(vp.x - 120, 290)
	dlg_ui.add_child(panel)
	var mg: MarginContainer = MarginContainer.new()
	for k in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + k, 16)
	panel.add_child(mg)
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 18)
	mg.add_child(h)
	var ic: TextureRect = TextureRect.new()
	ic.texture = load("res://assets/stickers/%s.png" % tex_id)
	ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	ic.custom_minimum_size = Vector2(210, 210)
	h.add_child(ic)
	var v: VBoxContainer = VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 8)
	h.add_child(v)
	v.add_child(Game.make_label(speaker, 32, Color("ffd21f")))
	dlg_label = Game.make_label("", 30)
	dlg_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	dlg_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(dlg_label)
	dlg_btn = Game.make_button("Дальше", 30)
	dlg_btn.custom_minimum_size = Vector2(0, 64)
	dlg_btn.pressed.connect(_dlg_next)
	v.add_child(dlg_btn)
	_dlg_refresh()

func _dlg_refresh() -> void:
	dlg_label.text = String(dlg_lines[dlg_idx])
	dlg_btn.text = "Дальше" if dlg_idx < dlg_lines.size() - 1 else "Понятно"

func _dlg_next() -> void:
	dlg_idx += 1
	if dlg_idx >= dlg_lines.size():
		dlg_ui.queue_free()
		dlg_ui = null
		ui_lock = false
		if dlg_cb.is_valid():
			dlg_cb.call()
	else:
		_dlg_refresh()

# ---------- markers / HUD ----------
func _update_markers() -> void:
	var done: int = int(sd["done"])
	var kinds: Array = []
	var cur_npc: String = ""
	var excl: bool = false
	if done < MISSIONS.size():
		var m: Dictionary = MISSIONS[done]
		cur_npc = m["npc"]
		if bool(sd["active"]):
			kinds = (m["goal"] as Dictionary).keys()
			excl = _goal_met(m)
		else:
			excl = true
	for it in items:
		(it["mk"] as Node3D).visible = kinds.has(it["kind"])
	for id in npc_excl.keys():
		(npc_excl[id] as Label3D).visible = (id == cur_npc and excl)

func _objective_text() -> String:
	var done: int = int(sd["done"])
	if done >= MISSIONS.size():
		return "Все задания выполнены! Можно гулять по школе."
	var m: Dictionary = MISSIONS[done]
	var npc: Dictionary = NPCS[m["npc"]]
	var np: Vector3 = npc["pos"]
	var dist: int = int(Vector2(player.global_position.x - np.x, player.global_position.z - np.z).length())
	if not bool(sd["active"]):
		return "Задание %d/%d «%s»\nПоговори: %s (%d м)" % [done + 1, MISSIONS.size(), m["title"], npc["name"], dist]
	var s: String = "Задание %d/%d «%s»\n" % [done + 1, MISSIONS.size(), m["title"]]
	var goal: Dictionary = m["goal"]
	for k in goal.keys():
		s += "%s: %d / %d\n" % [ITEM_NAMES[k], mini(int(sd["inv"][k]), int(goal[k])), int(goal[k])]
	if _goal_met(m):
		s += "Всё собрано! Отнеси: %s (%d м)" % [npc["name"], dist]
	else:
		s += "Ищи предметы (жёлтые стрелки), потом к: %s" % npc["name"]
	return s

func _tick(delta: float) -> void:
	info_l.text = "ШКОЛА №13  |  Выполнено заданий: %d / %d" % [int(sd["done"]), MISSIONS.size()]
	obj_l.text = _objective_text()
	mk_t += delta
	if mk_t > 0.5:
		mk_t = 0.0
		_update_markers()
	for it in items:
		var mk: Node3D = it["mk"]
		if mk.visible:
			mk.rotation.y += delta * 2.5
			mk.position.y = 1.1 + sin(t * 3.0 + (it["n"] as Node3D).position.x) * 0.12
	for a in anim:
		var n: Node3D = a["n"]
		var typ: String = a["t"]
		if typ == "spin":
			n.rotation.y += delta * float(a["sp"])
		elif typ == "bob":
			n.position.y = float(a["base"]) + sin(t * 2.0 + float(a["ph"])) * 0.05
		elif typ == "ball":
			n.position.y = float(a["base"]) + absf(sin(t * 3.2)) * 1.2
