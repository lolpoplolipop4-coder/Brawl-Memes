extends Node
# Autoload "Game": data tables, save/load, economy, UI style helpers.

const SAVE_PATH: String = "user://brawl_memes.json"
const RAR_NAMES: Array = ["Обычный", "Редкий", "Эпический", "Легендарный", "Мифический"]
const RAR_WEIGHTS: Array = [60.0, 25.0, 10.0, 4.0, 1.0]
const DUP_COINS: Array = [10, 25, 60, 150, 400]
const ABIL_TEXT: Dictionary = {
	"blast": "Взрыв: урон по области",
	"heal": "Лечение 40% здоровья",
	"dash": "Рывок и неуязвимость 0.8с",
	"shield": "Щит на 3 секунды",
	"rapid": "Скорострельность 4с",
}
# id, name, rarity, case, ability, ability name
const RAW: Array = [
	["a00", "Кот в Короне", 2, "a", "blast", "Королевский взрыв"],
	["a01", "Троллфейс-Король", 3, "a", "shield", "Троллинг-щит"],
	["a02", "Значок 2026", 0, "a", "rapid", "Новогодний залп"],
	["a03", "Чимс-Доге", 0, "a", "dash", "Рывок за косточкой"],
	["a04", "Орущий Кот", 0, "a", "blast", "Мяу-волна"],
	["a05", "Панда-Дэб", 1, "a", "dash", "Дэб-рывок"],
	["a06", "Стикмен", 0, "a", "shield", "Поза скептика"],
	["a07", "Ржущий Лик", 1, "a", "heal", "Смех лечит"],
	["a08", "Робло-Босс", 2, "a", "rapid", "Золотая цепь"],
	["a09", "Кот Шок", 0, "a", "heal", "Шок-терапия"],
	["a10", "Плачущий Кот", 1, "a", "shield", "Слёзный щит"],
	["a11", "Красный Сус", 4, "a", "dash", "Саботаж"],
	["a12", "Банан Босс", 2, "a", "heal", "Бананолечение"],
	["a13", "Табличка 2026", 1, "a", "rapid", "Табло-залп"],
	["a14", "Пиксель-Скелет", 3, "a", "blast", "Костяной взрыв"],
	["a15", "Очки Свэг", 0, "a", "blast", "Свэг-вспышка"],
	["b00", "Цинский Доге", 1, "b", "dash", "Имперский рывок"],
	["b01", "Дядя Одобрям", 2, "b", "heal", "Одобрение предков"],
	["b02", "Кот Нойон", 2, "b", "shield", "Щит нойона"],
	["b03", "Господин Мем", 1, "b", "rapid", "Мудрый залп"],
	["b04", "Радостный Багатур", 0, "b", "blast", "Ликующий удар"],
	["b05", "Конь Буу", 3, "b", "dash", "Степной галоп"],
	["b06", "Суровый Нойон", 2, "b", "blast", "Взгляд нойона"],
	["b07", "Довольный Кот", 0, "b", "heal", "Мур-лечение"],
	["b08", "Малыш Сваг", 0, "b", "rapid", "Детский задор"],
	["b09", "Значок Сваг", 0, "b", "shield", "Значок-оберег"],
	["b10", "Карта Бурятии", 1, "b", "blast", "Байкальская волна"],
	["b11", "Дацан-Мем", 1, "b", "heal", "Благословение дацана"],
	["b12", "Синий Хадак", 0, "b", "shield", "Хадак-оберег"],
	["b13", "Соёмбо", 4, "b", "blast", "Свет Соёмбо"],
	["b14", "Крутой Нойон", 3, "b", "rapid", "Сваг-шквал"],
	["b15", "Конь-Скакун", 0, "b", "dash", "Рывок скакуна"],
]
const CASES: Dictionary = {
	"a": {"name": "КЕЙС 2026", "cur": "coins", "price": 300, "card": "res://assets/ui/case_a.png", "banner": "res://assets/ui/banner_2026.png"},
	"b": {"name": "БУРЯТСКИЕ СВАГИ", "cur": "gems", "price": 60, "card": "res://assets/ui/case_b.png", "banner": "res://assets/ui/banner_buryat.png"},
}
# key, title, goal, currency, amount
const MISSIONS: Array = [
	["kills", "Победи 20 врагов", 20, "coins", 150],
	["games", "Сыграй 3 матча", 3, "coins", 100],
	["opens", "Открой 1 кейс", 1, "gems", 20],
	["wins", "Выиграй 2 матча", 2, "gems", 30],
]

var rar_colors: Array = [Color("6b7699"), Color("2f8cff"), Color("a04bff"), Color("ffb21f"), Color("ff3d8b")]
var chars: Array = []
var by_id: Dictionary = {}
var s: Dictionary = {}

func _ready() -> void:
	randomize()
	for i in RAW.size():
		var r: Array = RAW[i]
		var rar: int = r[2]
		var d: Dictionary = {
			"id": r[0], "name": r[1], "rar": rar, "case": r[3], "abil": r[4], "abil_name": r[5],
			"hp": 100 + rar * 40 + (i * 7) % 25,
			"dmg": 10 + rar * 5 + (i * 3) % 5,
			"spd": 250 + (i * 11) % 40,
			"tex": "res://assets/stickers/%s.png" % r[0],
		}
		chars.append(d)
		by_id[d["id"]] = d
	load_game()
	_setup_audio()
	apply_sound()

var music: AudioStreamPlayer
var sfx_click: AudioStreamPlayer
var sfx_shot: AudioStreamPlayer
var sfx_run: AudioStreamPlayer
var sfx_amb: AudioStreamPlayer
var cur_music: String = ""
var nickname: String = ""
var mp_roster: Dictionary = {}
var mp_host: bool = false

func _setup_audio() -> void:
	music = AudioStreamPlayer.new()
	music.volume_db = -10.0
	add_child(music)
	sfx_click = AudioStreamPlayer.new()
	sfx_click.stream = load("res://audio/click.wav")
	sfx_click.volume_db = -4.0
	add_child(sfx_click)
	sfx_shot = AudioStreamPlayer.new()
	sfx_shot.stream = load("res://audio/shot.wav")
	sfx_shot.volume_db = -8.0
	sfx_shot.max_polyphony = 4
	add_child(sfx_shot)
	sfx_run = AudioStreamPlayer.new()
	var rs = load("res://audio/run.ogg")
	rs.loop = true
	sfx_run.stream = rs
	sfx_run.volume_db = -6.0
	add_child(sfx_run)
	sfx_amb = AudioStreamPlayer.new()
	var amb = load("res://audio/ambient.ogg")
	amb.loop = true
	sfx_amb.stream = amb
	sfx_amb.volume_db = -8.0
	add_child(sfx_amb)

func apply_sound() -> void:
	AudioServer.set_bus_mute(0, not bool(s["snd"]))

func toggle_sound() -> void:
	s["snd"] = not bool(s["snd"])
	apply_sound()
	save_game()

func play_music(track: String) -> void:
	if cur_music == track and music.playing:
		return
	cur_music = track
	var st = load("res://audio/music_%s.ogg" % track)
	st.loop = true
	music.stream = st
	music.play()

func click() -> void:
	sfx_click.play()

func shot(pitch: float = 1.0) -> void:
	sfx_shot.pitch_scale = pitch
	sfx_shot.play()

func ambient_on(on: bool) -> void:
	if on and not sfx_amb.playing:
		sfx_amb.play()
	elif not on and sfx_amb.playing:
		sfx_amb.stop()

func run_on(on: bool) -> void:
	if on and not sfx_run.playing:
		sfx_run.play()
	elif not on and sfx_run.playing:
		sfx_run.stop()

func default_state() -> Dictionary:
	return {
		"coins": 500, "gems": 150, "trophies": 0, "xp": 0,
		"owned": {"a03": 1, "a06": 1}, "sel": "a03",
		"day": "", "streak": 0, "free_day": "",
		"m": {"kills": 0, "games": 0, "opens": 0, "wins": 0}, "mc": {},
		"vib": true, "snd": true, "name": "", "registered": false, "promos": [], "school": {"done": 0, "active": false, "collected": [], "inv": {"sock": 0, "potato": 0, "cucumber": 0, "diary": 0, "bun": 0}},
	}

func load_game() -> void:
	s = default_state()
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var data = JSON.parse_string(f.get_as_text())
	if typeof(data) != TYPE_DICTIONARY:
		return
	for k in s.keys():
		if data.has(k):
			s[k] = data[k]
	for k in ["coins", "gems", "trophies", "xp", "streak"]:
		s[k] = int(s[k])
	for k in s["owned"].keys():
		s["owned"][k] = int(s["owned"][k])
	for k in s["m"].keys():
		s["m"][k] = int(s["m"][k])
	if not by_id.has(s["sel"]) or not s["owned"].has(s["sel"]):
		s["sel"] = "a03"
	if not bool(s["registered"]):
		wipe_account()
		return
	nickname = str(s["name"])

func save_game() -> void:
	var f: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(s))

func redeem(code: String) -> int:
	var c: String = code.strip_edges().to_lower()
	if c == "test":
		if s["promos"].has("test"):
			return 2
		s["promos"].append("test")
		s["coins"] = int(s["coins"]) + 100000
		s["gems"] = int(s["gems"]) + 100000
		save_game()
		return 0
	if c == "mk890":
		if s["promos"].has("mk890"):
			return 2
		s["promos"].append("mk890")
		for ch in chars:
			if not s["owned"].has(ch["id"]):
				s["owned"][ch["id"]] = 1
		save_game()
		return 3
	return 1

func mp_leave() -> void:
	var api: MultiplayerAPI = get_tree().get_multiplayer()
	if api.multiplayer_peer != null:
		api.multiplayer_peer.close()
	api.multiplayer_peer = OfflineMultiplayerPeer.new()
	mp_roster = {}
	mp_host = false

func reset_school() -> void:
	s["school"] = default_state()["school"]
	save_game()

func register(n: String) -> void:
	s["name"] = n
	s["registered"] = true
	nickname = n
	save_game()

func wipe_account() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
	s = default_state()
	nickname = ""

func reset_game() -> void:
	s = default_state()
	save_game()

func today() -> String:
	return Time.get_date_string_from_system()

func level(id: String) -> int:
	return int(s["owned"].get(id, 1))

func stat(id: String, key: String) -> float:
	return float(by_id[id][key]) * (1.0 + 0.1 * float(level(id) - 1))

func player_level() -> int:
	return 1 + int(s["xp"] / 100)

func can_pay(cur: String, amt: int) -> bool:
	return int(s[cur]) >= amt

func pay(cur: String, amt: int) -> bool:
	if not can_pay(cur, amt):
		return false
	s[cur] = int(s[cur]) - amt
	save_game()
	return true

func add(cur: String, amt: int) -> void:
	s[cur] = int(s[cur]) + amt
	save_game()

func add_trophies(n: int) -> void:
	s["trophies"] = maxi(0, int(s["trophies"]) + n)

func roll_case(cid: String) -> Dictionary:
	var t: float = randf() * 100.0
	var rar: int = 0
	while rar < 4 and t >= float(RAR_WEIGHTS[rar]):
		t -= float(RAR_WEIGHTS[rar])
		rar += 1
	var pool: Array = []
	for c in chars:
		if c["case"] == cid and c["rar"] == rar:
			pool.append(c)
	var got: Dictionary = pool[randi() % pool.size()]
	var dup: bool = s["owned"].has(got["id"])
	var coins: int = 0
	if dup:
		s["owned"][got["id"]] = int(s["owned"][got["id"]]) + 1
		coins = int(DUP_COINS[rar])
		s["coins"] = int(s["coins"]) + coins
	else:
		s["owned"][got["id"]] = 1
	s["m"]["opens"] = int(s["m"]["opens"]) + 1
	s["xp"] = int(s["xp"]) + 15
	save_game()
	return {"char": got, "dup": dup, "coins": coins}

func can_daily() -> bool:
	return s["day"] != today()

func claim_daily() -> int:
	s["day"] = today()
	s["streak"] = int(s["streak"]) + 1
	var g: int = 100 + mini(int(s["streak"]), 7) * 50
	s["coins"] = int(s["coins"]) + g
	if int(s["streak"]) % 7 == 0:
		s["gems"] = int(s["gems"]) + 50
	save_game()
	return g

func free_case_ready() -> bool:
	return s["free_day"] != today()

func mission_done(m: Array) -> bool:
	return int(s["m"][m[0]]) >= int(m[2])

func claim_mission(m: Array) -> void:
	s["mc"][m[0]] = true
	s[m[3]] = int(s[m[3]]) + int(m[4])
	save_game()

func vibrate(ms: int = 40) -> void:
	if s["vib"]:
		Input.vibrate_handheld(ms)

# ---------- UI helpers ----------
func style(col: Color, radius: int = 18, border: int = 4) -> StyleBoxFlat:
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = col
	sb.border_color = Color.BLACK
	sb.set_border_width_all(border)
	sb.set_corner_radius_all(radius)
	sb.shadow_color = Color(0, 0, 0, 0.5)
	sb.shadow_size = 4
	sb.shadow_offset = Vector2(0, 4)
	return sb

const SKIN_COLORS: Dictionary = {"yellow": "ffd21f", "blue": "2f8cff", "navy": "0d1650", "red": "d7322d", "orange": "ff7a1a", "green": "3cc83c", "purple": "9b3fe0"}

func skin_key(col: Color) -> String:
	var best: String = "yellow"
	var bd: float = 1e9
	for k in SKIN_COLORS.keys():
		var c: Color = Color(SKIN_COLORS[k])
		var d: float = pow(c.r - col.r, 2.0) + pow(c.g - col.g, 2.0) + pow(c.b - col.b, 2.0)
		if d < bd:
			bd = d
			best = k
	return best

func skin(key: String, pressed: bool) -> StyleBoxTexture:
	var sb: StyleBoxTexture = StyleBoxTexture.new()
	sb.texture = load("res://assets/skins/%s%s.png" % [key, "_p" if pressed else ""])
	sb.texture_margin_left = 44
	sb.texture_margin_right = 44
	sb.texture_margin_top = 44
	sb.texture_margin_bottom = 44
	sb.content_margin_left = 18
	sb.content_margin_right = 18
	sb.content_margin_top = 24 if pressed else 12
	sb.content_margin_bottom = 12 if pressed else 26
	return sb

func make_button(text: String, font_size: int = 34, col: Color = Color("ffd21f"), font_col: Color = Color.BLACK, radius: int = 18) -> Button:
	var b: Button = Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	var key: String = skin_key(col)
	b.add_theme_font_size_override("font_size", font_size)
	for nm in ["font_color", "font_hover_color", "font_pressed_color"]:
		b.add_theme_color_override(nm, font_col)
	b.add_theme_color_override("font_disabled_color", Color(0.25, 0.25, 0.28))
	if font_col == Color.WHITE:
		b.add_theme_color_override("font_outline_color", Color.BLACK)
		b.add_theme_constant_override("outline_size", maxi(3, int(font_size / 7)))
	b.add_theme_stylebox_override("normal", skin(key, false))
	b.add_theme_stylebox_override("hover", skin(key, false))
	b.add_theme_stylebox_override("pressed", skin(key, true))
	b.add_theme_stylebox_override("disabled", skin("gray", false))
	b.pressed.connect(click)
	b.resized.connect(func(): b.pivot_offset = b.size / 2.0)
	b.button_down.connect(func(): b.create_tween().tween_property(b, "scale", Vector2(0.95, 0.95), 0.06))
	b.button_up.connect(func(): b.create_tween().tween_property(b, "scale", Vector2.ONE, 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT))
	return b

func make_label(text: String, font_size: int = 30, col: Color = Color.WHITE) -> Label:
	var l: Label = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", maxi(2, int(font_size / 8)))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l
