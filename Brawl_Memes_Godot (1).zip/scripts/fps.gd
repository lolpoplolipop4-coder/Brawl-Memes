extends Node3D
# First-person gameplay in the 3D Russian village. Modes: battle, sandbox, survival, arena.
signal exit_requested(again: bool)

const SENS: float = 0.0045
var WEAPONS: Dictionary = {
	"pistol": {"name": "ПИСТОЛЕТ", "mag": 12, "cd": 0.26, "dmg": 1.0, "reload": 1.1, "spread": 0.0, "kick": 0.03, "pitch": 1.0, "muzzle": Vector3(0, 0.02, -0.22), "dist": 0.4},
	"ak47": {"name": "АК-47", "mag": 30, "cd": 0.105, "dmg": 0.65, "reload": 2.0, "spread": 0.015, "kick": 0.022, "pitch": 0.75, "muzzle": Vector3(0, 0.03, -0.74), "dist": 0.9},
}
var cur_weapon: String = "pistol"
var ammo_by: Dictionary = {"pistol": 12, "ak47": 30}
var pistol_node: Node3D
var ak_node: Node3D
var reload_tw: Tween = null
var switching: bool = false
var q_prev: bool = false
var net = null
var mp_dead: bool = false
var respawn_t: float = 0.0
var last_hitter: int = -1
var spawn_idx: int = 0
var MP_SPAWNS: Array = [Vector3(-60, 1, 0), Vector3(-30, 1, 3), Vector3(0, 1, -3), Vector3(30, 1, 0), Vector3(58, 1, 3), Vector3(-45, 1, 24), Vector3(22, 1, -28), Vector3(50, 1, 25)]
const CARRY_MAX: int = 1
const WOOD_GOAL: int = 30
const SHOP_ITEMS: Array = [
	["shawarma", "Шаурма", "+60 HP", 60.0],
	["sandwich", "Бутерброд с колбасой", "+35 HP", 35.0],
	["tea", "Чай", "+20 HP и бодрость 10 с", 20.0],
]

var mode: String = "arena"
var ch: Dictionary = {}
var vp: Vector2 = Vector2(1280, 720)
var village = null
var player: CharacterBody3D
var cam: Camera3D
var gun: Node3D
var flash: MeshInstance3D
var yaw: float = -PI / 2.0
var pitch: float = 0.0
var vel_y: float = 0.0
var hp: float = 100.0
var max_hp: float = 100.0
var shot_dmg: float = 20.0
var speed: float = 5.5
var ammo: int = 12
var reload_t: float = 0.0
var shoot_cd: float = 0.0
var ab_cd: float = 0.0
var shield_t: float = 0.0
var rapid_t: float = 0.0
var dash_t: float = 0.0
var hurt_t: float = 0.0
var hit_t: float = 0.0
var t: float = 0.0
var kills: int = 0
var wave: int = 0
var spawn_cd: float = 1.0
var over: bool = false
var enemies: Array = []
var enemy_tex: Array = []
var bar_tex: Texture2D
var fire_held: bool = false
var jump_req: bool = false
var removing: bool = false
var move_idx: int = -1
var look_idx: int = -1
var fire_idx: int = -1
var joy_o: Vector2 = Vector2.ZERO
var joy_v: Vector2 = Vector2.ZERO
var layer: CanvasLayer
var hud: Control
var hp_l: Label
var info_l: Label
var ammo_l: Label
var btns: Dictionary = {}
var btn_labels: Dictionary = {}
var btn_panels: Dictionary = {}
var shop_open: bool = false
var shop_ui: Control = null
var toast_l: Label
var toast_t: float = 0.0
var speed_t: float = 0.0
var use_near: bool = false
var inspecting: bool = false
var inspect_tw: Tween = null
var kick: float = 0.0
var look_moved: float = 0.0
var casings: Array = []
var truck = null
var held_log: MeshInstance3D = null
var piles: Array = []
var carried: int = 0
var loaded: int = 0
var wood_done: bool = false
var last_full_toast: float = -10.0
var holes: Array = []

func setup(m: String) -> void:
	mode = m
	ch = Game.by_id[Game.s["sel"]]
	vp = get_viewport().get_visible_rect().size
	max_hp = Game.stat(ch["id"], "hp")
	hp = max_hp
	shot_dmg = Game.stat(ch["id"], "dmg") * 1.6
	speed = 5.0 + (Game.stat(ch["id"], "spd") - 250.0) / 40.0
	for id in ["a04", "a09", "a10", "a07", "b07", "b03", "b00", "a15", "a05", "a06"]:
		enemy_tex.append(load("res://assets/stickers/%s.png" % id))
	var img: Image = Image.create(2, 2, false, Image.FORMAT_RGBA8)
	img.fill(Color.WHITE)
	bar_tex = ImageTexture.create_from_image(img)
	village = Node3D.new()
	village.set_script(load("res://scripts/village.gd"))
	add_child(village)
	village.build()
	_make_player()
	_make_hud()
	Game.ambient_on(true)
	if mode == "battle":
		for i in 3:
			_spawn_enemy(true)
	elif mode == "arena":
		_next_wave()
	elif mode == "wood":
		_setup_wood()
	elif mode == "mp":
		_setup_mp()

# ---------- setup helpers ----------
func _box(parent: Node3D, pos: Vector3, size: Vector3, col: Color, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var b: BoxMesh = BoxMesh.new()
	b.size = size
	mi.mesh = b
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = 0.6
	mi.material_override = m
	mi.position = pos
	mi.rotation_degrees = rot
	parent.add_child(mi)
	return mi

func _make_player() -> void:
	player = CharacterBody3D.new()
	player.collision_layer = 4
	player.collision_mask = 1
	var cs: CollisionShape3D = CollisionShape3D.new()
	var cap: CapsuleShape3D = CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0, 0.9, 0)
	player.add_child(cs)
	player.position = village.player_start
	player.rotation.y = yaw
	add_child(player)
	cam = Camera3D.new()
	cam.position = Vector3(0, 1.6, 0)
	cam.fov = 78.0
	cam.near = 0.05
	cam.far = 220.0
	player.add_child(cam)
	cam.current = true
	gun = Node3D.new()
	gun.position = Vector3(0.28, -0.26, -0.55)
	cam.add_child(gun)
	pistol_node = Node3D.new()
	gun.add_child(pistol_node)
	_box(pistol_node, Vector3(0, 0, 0), Vector3(0.07, 0.09, 0.34), Color(0.13, 0.13, 0.16))
	_box(pistol_node, Vector3(0, -0.03, 0.02), Vector3(0.05, 0.05, 0.2), Color(0.2, 0.2, 0.24))
	_box(pistol_node, Vector3(0, -0.12, 0.11), Vector3(0.06, 0.17, 0.08), Color(0.4, 0.25, 0.12), Vector3(14, 0, 0))
	ak_node = Node3D.new()
	ak_node.position = Vector3(0, 0.02, 0.05)
	ak_node.visible = false
	gun.add_child(ak_node)
	var metal: Color = Color(0.1, 0.1, 0.12)
	var wood: Color = Color(0.5, 0.28, 0.1)
	_box(ak_node, Vector3(0, 0, 0), Vector3(0.06, 0.09, 0.42), metal)
	_box(ak_node, Vector3(0, 0.05, 0.02), Vector3(0.05, 0.02, 0.36), Color(0.17, 0.17, 0.19))
	_box(ak_node, Vector3(0, 0.01, -0.45), Vector3(0.024, 0.024, 0.5), Color(0.07, 0.07, 0.08))
	_box(ak_node, Vector3(0, -0.005, -0.28), Vector3(0.07, 0.07, 0.3), wood)
	_box(ak_node, Vector3(0, 0.045, -0.3), Vector3(0.025, 0.025, 0.32), Color(0.15, 0.15, 0.16))
	_box(ak_node, Vector3(0, 0.04, -0.66), Vector3(0.02, 0.05, 0.02), metal)
	_box(ak_node, Vector3(0, -0.14, -0.04), Vector3(0.05, 0.2, 0.09), Color(0.12, 0.12, 0.13), Vector3(18, 0, 0))
	_box(ak_node, Vector3(0, -0.1, 0.16), Vector3(0.05, 0.13, 0.06), wood, Vector3(-15, 0, 0))
	_box(ak_node, Vector3(0, -0.02, 0.4), Vector3(0.05, 0.09, 0.26), wood)
	flash = MeshInstance3D.new()
	var sm: SphereMesh = SphereMesh.new()
	sm.radius = 0.07
	sm.height = 0.14
	flash.mesh = sm
	var fm: StandardMaterial3D = StandardMaterial3D.new()
	fm.albedo_color = Color(1, 0.85, 0.3)
	fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	flash.material_override = fm
	flash.position = Vector3(0, 0.02, -0.22)
	flash.visible = false
	gun.add_child(flash)

func _round_btn(key: String, caption: String, center: Vector2, r: float, col: Color, fs: int) -> void:
	btns[key] = [center, r]
	var p: Panel = Panel.new()
	btn_panels[key] = p
	p.position = center - Vector2(r, r)
	p.size = Vector2(r * 2.0, r * 2.0)
	var sb: StyleBoxFlat = Game.style(col, int(r), 5)
	p.add_theme_stylebox_override("panel", sb)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l: Label = Game.make_label(caption, fs)
	l.position = Vector2(0, r - float(fs) * 0.75)
	l.size = Vector2(r * 2.0, float(fs) * 1.6)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	p.add_child(l)
	layer.add_child(p)
	btn_labels[key] = l

func _make_hud() -> void:
	layer = CanvasLayer.new()
	add_child(layer)
	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.draw.connect(_on_hud_draw)
	layer.add_child(hud)
	hp_l = Game.make_label("", 24)
	hp_l.position = Vector2(34, 16)
	layer.add_child(hp_l)
	info_l = Game.make_label("", 30)
	info_l.position = Vector2(24, 54)
	layer.add_child(info_l)
	ammo_l = Game.make_label("", 38, Color("ffd21f"))
	ammo_l.position = Vector2(vp.x - 250, 100)
	layer.add_child(ammo_l)
	if mode == "sandbox":
		_round_btn("fire", "ПОСТАВИТЬ", Vector2(vp.x - 170, vp.y - 160), 100.0, Color("3cc83c"), 24)
		_round_btn("ab", "БЛОК", Vector2(vp.x - 380, vp.y - 110), 70.0, Color("2f8cff"), 24)
	elif mode != "wood":
		_round_btn("fire", "ОГОНЬ", Vector2(vp.x - 170, vp.y - 160), 100.0, Color("e03030"), 34)
		_round_btn("ab", "СПОСОБ-\nНОСТЬ", Vector2(vp.x - 380, vp.y - 110), 70.0, Color("ffd21f"), 20)
		_round_btn("reload", "ПЕРЕЗ.", Vector2(vp.x - 90, vp.y - 330), 52.0, Color("2f8cff"), 18)
		_round_btn("weapon", "АК-47", Vector2(vp.x - 560, vp.y - 100), 52.0, Color("7a5230"), 15)
	_round_btn("jump", "ПРЫЖОК", Vector2(vp.x - 330, vp.y - 250), 56.0, Color("9b3fe0"), 18)
	_round_btn("inspect", "ОСМОТР", Vector2(vp.x - 230, vp.y - 350), 46.0, Color("ff7a1a"), 15)
	_round_btn("use", "НИНА\nМАГАЗИН", Vector2(vp.x - 490, vp.y - 250), 58.0, Color("3cc83c"), 16)
	btn_panels["use"].visible = false
	_round_btn("exit", "X", Vector2(vp.x - 60, 56), 40.0, Color("0d1650"), 36)
	toast_l = Game.make_label("", 36, Color("ffd21f"))
	toast_l.position = Vector2(vp.x / 2.0 - 350, 130)
	toast_l.size = Vector2(700, 50)
	toast_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_l.visible = false
	layer.add_child(toast_l)
	if mode == "sandbox":
		btn_labels["ab"].text = "БЛОК"

func _on_hud_draw() -> void:
	hud.draw_rect(Rect2(24, 16, 320, 30), Color(0, 0, 0, 0.6))
	hud.draw_rect(Rect2(28, 20, 312.0 * clampf(hp / max_hp, 0.0, 1.0), 22), Color("44ee66"))
	var c: Vector2 = vp / 2.0
	var wc: Color = Color(1, 1, 1, 0.9)
	hud.draw_line(c + Vector2(-16, 0), c + Vector2(-6, 0), wc, 3.0)
	hud.draw_line(c + Vector2(6, 0), c + Vector2(16, 0), wc, 3.0)
	hud.draw_line(c + Vector2(0, -16), c + Vector2(0, -6), wc, 3.0)
	hud.draw_line(c + Vector2(0, 6), c + Vector2(0, 16), wc, 3.0)
	hud.draw_circle(c, 2.0, wc)
	if hit_t > 0.0:
		var hc: Color = Color(1, 0.2, 0.2, 1)
		hud.draw_line(c + Vector2(-22, -22), c + Vector2(-10, -10), hc, 4.0)
		hud.draw_line(c + Vector2(22, -22), c + Vector2(10, -10), hc, 4.0)
		hud.draw_line(c + Vector2(-22, 22), c + Vector2(-10, 10), hc, 4.0)
		hud.draw_line(c + Vector2(22, 22), c + Vector2(10, 10), hc, 4.0)
	if move_idx != -1:
		hud.draw_circle(joy_o, 90.0, Color(1, 1, 1, 0.12))
		hud.draw_arc(joy_o, 90.0, 0.0, TAU, 40, Color(1, 1, 1, 0.5), 4.0)
		hud.draw_circle(joy_o + joy_v * 90.0, 38.0, Color(1, 1, 1, 0.5))
	if hurt_t > 0.0:
		hud.draw_rect(Rect2(Vector2.ZERO, vp), Color(1, 0, 0, minf(0.4, hurt_t)))
	if shield_t > 0.0:
		hud.draw_rect(Rect2(Vector2.ZERO, vp), Color(0.2, 0.9, 1.0, 0.12))

# ---------- input ----------
func _hit_btn(p: Vector2) -> String:
	for k in btns.keys():
		if mode == "sandbox" and k == "reload":
			continue
		if k == "use" and not use_near:
			continue
		var b: Array = btns[k]
		if p.distance_to(b[0]) <= float(b[1]) * 1.2:
			return k
	return ""

func _input(ev: InputEvent) -> void:
	if over or shop_open:
		return
	if ev is InputEventScreenTouch:
		var te: InputEventScreenTouch = ev as InputEventScreenTouch
		var p: Vector2 = te.position
		if te.pressed:
			var k: String = _hit_btn(p)
			if k != "":
				_press(k, te.index)
			elif p.x < vp.x * 0.45 and move_idx == -1:
				move_idx = te.index
				joy_o = p
				joy_v = Vector2.ZERO
			elif look_idx == -1:
				look_idx = te.index
				look_moved = 0.0
		else:
			if te.index == move_idx:
				move_idx = -1
				joy_v = Vector2.ZERO
			if te.index == look_idx:
				look_idx = -1
				if look_moved < 14.0:
					_tap(p)
			if te.index == fire_idx:
				fire_idx = -1
				fire_held = false
	elif ev is InputEventScreenDrag:
		var de: InputEventScreenDrag = ev as InputEventScreenDrag
		if de.index == move_idx:
			joy_v = (de.position - joy_o).limit_length(90.0) / 90.0
		elif de.index == look_idx:
			look_moved += de.relative.length()
			yaw -= de.relative.x * SENS
			pitch = clampf(pitch - de.relative.y * SENS, -1.3, 1.3)

func _press(k: String, idx: int) -> void:
	Game.click()
	if k == "fire":
		fire_held = true
		fire_idx = idx
	elif k == "jump":
		jump_req = true
	elif k == "reload":
		_start_reload()
	elif k == "weapon":
		_switch_weapon()
	elif k == "ab":
		if mode == "sandbox":
			removing = not removing
			btn_labels["ab"].text = "УБРАТЬ" if removing else "БЛОК"
			btn_labels["fire"].text = "УБРАТЬ" if removing else "ПОСТАВИТЬ"
		else:
			_use_ability()
	elif k == "inspect":
		_inspect()
	elif k == "use":
		_open_shop()
	elif k == "exit":
		_on_exit()

func _on_exit() -> void:
	if mode == "mp":
		if net != null:
			net.leave()
		exit_requested.emit(false)
	elif mode != "sandbox" and mode != "wood" and not over and t > 3.0:
		_finish(false)
	else:
		exit_requested.emit(false)

func _exit_tree() -> void:
	Game.run_on(false)
	Game.ambient_on(false)

# ---------- gameplay ----------
func _mag() -> int:
	return int(WEAPONS[cur_weapon]["mag"])

func _start_reload() -> void:
	if reload_t <= 0.0 and ammo < _mag() and not switching:
		var rt: float = float(WEAPONS[cur_weapon]["reload"])
		reload_t = rt
		_cancel_inspect()
		Game.click()
		reload_tw = create_tween()
		reload_tw.tween_property(gun, "position", Vector3(0.22, -0.55, -0.45), 0.3)
		reload_tw.parallel().tween_property(gun, "rotation_degrees", Vector3(-35, 0, 10), 0.3)
		reload_tw.tween_interval(maxf(0.1, rt - 0.6))
		reload_tw.tween_callback(Game.click)
		reload_tw.tween_property(gun, "position", Vector3(0.28, -0.26, -0.55), 0.3)
		reload_tw.parallel().tween_property(gun, "rotation_degrees", Vector3.ZERO, 0.3)

func _switch_weapon() -> void:
	if switching or over or mode == "sandbox" or mode == "wood" or carried > 0:
		return
	_cancel_inspect()
	if reload_tw != null and reload_tw.is_valid():
		reload_tw.kill()
	reload_t = 0.0
	ammo_by[cur_weapon] = ammo
	switching = true
	var nxt: String = "ak47" if cur_weapon == "pistol" else "pistol"
	Game.click()
	gun.rotation_degrees = Vector3.ZERO
	var tw: Tween = create_tween()
	tw.tween_property(gun, "position", Vector3(0.28, -0.7, -0.55), 0.18)
	tw.tween_callback(_apply_weapon.bind(nxt))
	tw.tween_property(gun, "position", Vector3(0.28, -0.26, -0.55), 0.22)
	tw.tween_callback(func(): switching = false)

func _apply_weapon(w: String) -> void:
	cur_weapon = w
	ammo = int(ammo_by[w])
	pistol_node.visible = (w == "pistol")
	ak_node.visible = (w == "ak47")
	flash.position = WEAPONS[w]["muzzle"]
	shoot_cd = 0.15
	if btn_labels.has("weapon"):
		btn_labels["weapon"].text = "ПИСТОЛЕТ" if w == "ak47" else "АК-47"
	Game.click()

func _cancel_inspect() -> void:
	if inspect_tw != null and inspect_tw.is_valid():
		inspect_tw.kill()
	if inspecting:
		inspecting = false
		gun.position = Vector3(0.28, -0.26, -0.55)
		gun.rotation_degrees = Vector3.ZERO

func _inspect() -> void:
	if inspecting or reload_t > 0.0 or over or carried > 0:
		return
	inspecting = true
	inspect_tw = create_tween()
	inspect_tw.tween_property(gun, "position", Vector3(0.1, -0.17, -0.4), 0.35)
	inspect_tw.parallel().tween_property(gun, "rotation_degrees", Vector3(0, -60, 10), 0.35)
	inspect_tw.tween_interval(0.35)
	inspect_tw.tween_property(gun, "rotation_degrees", Vector3(-28, -60, 10), 0.4)
	inspect_tw.tween_callback(Game.click)
	inspect_tw.tween_interval(0.3)
	inspect_tw.tween_property(gun, "rotation_degrees", Vector3(0, 55, -10), 0.5)
	inspect_tw.tween_interval(0.45)
	inspect_tw.tween_property(gun, "position", Vector3(0.28, -0.26, -0.55), 0.35)
	inspect_tw.parallel().tween_property(gun, "rotation_degrees", Vector3.ZERO, 0.35)
	inspect_tw.tween_callback(func(): inspecting = false)

func _tap(p: Vector2) -> void:
	if not use_near or shop_open:
		return
	var np: Vector3 = village.nina_pos
	if cam.is_position_behind(np):
		return
	var sp: Vector2 = cam.unproject_position(np)
	if p.distance_to(sp) < 150.0:
		_open_shop()

func _toast(text: String) -> void:
	toast_l.text = text
	toast_l.visible = true
	toast_t = 1.8

func _process(delta: float) -> void:
	if toast_t > 0.0:
		toast_t -= delta
		if toast_t <= 0.0:
			toast_l.visible = false

func _icon(path: String, sz: float) -> TextureRect:
	var tr: TextureRect = TextureRect.new()
	tr.texture = load(path)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.custom_minimum_size = Vector2(sz, sz)
	return tr

func _open_shop() -> void:
	if shop_open or over or mode == "mp":
		return
	shop_open = true
	fire_held = false
	move_idx = -1
	look_idx = -1
	joy_v = Vector2.ZERO
	Game.run_on(false)
	Game.click()
	shop_ui = Control.new()
	shop_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(shop_ui)
	var dim: ColorRect = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.72)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	shop_ui.add_child(dim)
	var panel: PanelContainer = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", Game.style(Color("12236e"), 26, 5))
	panel.size = Vector2(1080, 540)
	panel.position = (vp - panel.size) / 2.0
	shop_ui.add_child(panel)
	var mg: MarginContainer = MarginContainer.new()
	for k in ["left", "right", "top", "bottom"]:
		mg.add_theme_constant_override("margin_" + k, 20)
	panel.add_child(mg)
	var v: VBoxContainer = VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	mg.add_child(v)
	var head: HBoxContainer = HBoxContainer.new()
	head.add_theme_constant_override("separation", 16)
	head.add_child(_icon("res://assets/stickers/a03.png", 130))
	var hv: VBoxContainer = VBoxContainer.new()
	hv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hv.alignment = BoxContainer.ALIGNMENT_CENTER
	hv.add_child(Game.make_label("Магазин у Нины", 44, Color("ffd21f")))
	var sp: Label = Game.make_label("Угощайся, дорогой! Всё бесплатно, лишь бы на здоровье!", 28)
	sp.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hv.add_child(sp)
	head.add_child(hv)
	v.add_child(head)
	var row: HBoxContainer = HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_theme_constant_override("separation", 14)
	for i in SHOP_ITEMS.size():
		var it: Array = SHOP_ITEMS[i]
		var card: PanelContainer = PanelContainer.new()
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.add_theme_stylebox_override("panel", Game.style(Color("0d1650"), 20, 4))
		var cv: VBoxContainer = VBoxContainer.new()
		cv.add_theme_constant_override("separation", 6)
		cv.alignment = BoxContainer.ALIGNMENT_CENTER
		cv.add_child(_icon("res://assets/food/%s.png" % it[0], 150))
		var nl: Label = Game.make_label(it[1], 28)
		nl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		nl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		cv.add_child(nl)
		var el: Label = Game.make_label(it[2], 24, Color("55ee88"))
		el.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		cv.add_child(el)
		var b: Button = Game.make_button("Взять бесплатно", 26, Color("3cc83c"))
		b.custom_minimum_size = Vector2(0, 70)
		b.pressed.connect(_eat.bind(i))
		cv.add_child(b)
		card.add_child(cv)
		row.add_child(card)
	v.add_child(row)
	var close: Button = Game.make_button("Закрыть", 30, Color("0d1650"), Color.WHITE)
	close.custom_minimum_size = Vector2(0, 64)
	close.pressed.connect(_close_shop)
	v.add_child(close)
	layer.move_child(toast_l, layer.get_child_count() - 1)

func _close_shop() -> void:
	if shop_ui != null:
		shop_ui.queue_free()
		shop_ui = null
	shop_open = false

func _eat(i: int) -> void:
	var it: Array = SHOP_ITEMS[i]
	if i != 2 and hp >= max_hp - 0.5:
		_toast("Здоровье уже полное!")
		return
	hp = minf(max_hp, hp + float(it[3]))
	if i == 2:
		speed_t = 10.0
	Game.vibrate(30)
	_toast("%s: %s" % [it[1], it[2]])

func _eject_casing() -> void:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var bm: BoxMesh = BoxMesh.new()
	bm.size = Vector3(0.015, 0.015, 0.04)
	mi.mesh = bm
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = Color(0.9, 0.7, 0.2)
	m.metallic = 0.8
	mi.material_override = m
	add_child(mi)
	var bs: Basis = cam.global_transform.basis
	mi.global_position = gun.global_position + bs.x * 0.06
	casings.append({"n": mi, "v": bs.x * (1.2 + randf()) + bs.y * 1.8 - bs.z * 0.3, "t": 0.0})

func _update_casings(delta: float) -> void:
	var keep: Array = []
	for c in casings:
		var n: MeshInstance3D = c["n"]
		c["t"] = float(c["t"]) + delta
		if n.global_position.y > 0.03:
			c["v"] = c["v"] + Vector3(0, -9.8, 0) * delta
			n.global_position += c["v"] * delta
			n.rotation += Vector3(8, 5, 3) * delta
		if float(c["t"]) > 6.0:
			n.queue_free()
		else:
			keep.append(c)
	casings = keep

func _hole(pos: Vector3, n: Vector3) -> void:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var qm: QuadMesh = QuadMesh.new()
	qm.size = Vector2(0.14, 0.14)
	mi.mesh = qm
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = Color(0.05, 0.05, 0.05, 0.85)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	mi.material_override = m
	add_child(mi)
	var up: Vector3 = Vector3.UP if absf(n.dot(Vector3.UP)) < 0.95 else Vector3.RIGHT
	mi.look_at_from_position(pos + n * 0.012, pos - n, up)
	holes.append(mi)
	if holes.size() > 50:
		var old = holes.pop_front()
		if is_instance_valid(old):
			old.queue_free()

func _use_ability() -> void:
	if over or ab_cd > 0.0 or mode == "sandbox":
		return
	ab_cd = 8.0
	var a: String = ch["abil"]
	if a == "heal":
		hp = minf(max_hp, hp + max_hp * 0.4)
	elif a == "dash":
		dash_t = 0.8
	elif a == "shield":
		shield_t = 3.0
	elif a == "rapid":
		rapid_t = 4.0
	else:
		_ring(player.global_position + Vector3(0, 0.3, 0), 10.0)
		for e in enemies.duplicate():
			if player.global_position.distance_to(e.global_position) < 10.0:
				_damage_enemy(e, shot_dmg * 4.0)
	Game.vibrate(60)

func _ring(pos: Vector3, radius: float) -> void:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var tm: TorusMesh = TorusMesh.new()
	tm.inner_radius = 0.9
	tm.outer_radius = 1.0
	mi.mesh = tm
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = Color(1, 0.85, 0.2)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = m
	add_child(mi)
	mi.global_position = pos
	var tw: Tween = create_tween()
	tw.tween_property(mi, "scale", Vector3(radius, radius, radius), 0.35)
	tw.tween_callback(mi.queue_free)

func _hurt(a: float) -> void:
	if shield_t > 0.0 or dash_t > 0.0 or over:
		return
	hp -= a
	hurt_t = maxf(hurt_t, 0.3)
	if hp <= 0.0:
		hp = 0.0
		if mode == "mp":
			_mp_die()
		else:
			_finish(false)

func _spawn_enemy(strong: bool) -> void:
	var e: CharacterBody3D = CharacterBody3D.new()
	e.collision_layer = 2
	e.collision_mask = 1
	var cs: CollisionShape3D = CollisionShape3D.new()
	var cap: CapsuleShape3D = CapsuleShape3D.new()
	cap.radius = 0.55
	cap.height = 1.9
	cs.shape = cap
	cs.position = Vector3(0, 0.95, 0)
	e.add_child(cs)
	var base: float = 40.0 + float(wave) * 9.0 + t * 0.25
	var tex_e: Texture2D = enemy_tex[randi() % enemy_tex.size()]
	var sc: float = 1.0
	if strong:
		base = 150.0
		var c: Dictionary = Game.chars[randi() % Game.chars.size()]
		tex_e = load(c["tex"])
		sc = 1.2
	var spr: Sprite3D = Sprite3D.new()
	spr.texture = tex_e
	spr.pixel_size = 0.0085 * sc
	spr.billboard = BaseMaterial3D.BILLBOARD_FIXED_Y
	spr.shaded = false
	spr.double_sided = true
	spr.alpha_cut = SpriteBase3D.ALPHA_CUT_OPAQUE_PREPASS
	spr.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	spr.position = Vector3(0, 1.1 * sc, 0)
	e.add_child(spr)
	var bg: Sprite3D = Sprite3D.new()
	bg.texture = bar_tex
	bg.pixel_size = 0.01
	bg.scale = Vector3(60, 7, 1)
	bg.modulate = Color(0, 0, 0, 0.8)
	bg.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	bg.shaded = false
	bg.position = Vector3(0, 2.5 * sc, 0)
	e.add_child(bg)
	var fg: Sprite3D = Sprite3D.new()
	fg.texture = bar_tex
	fg.pixel_size = 0.01
	fg.scale = Vector3(58, 5, 1)
	fg.modulate = Color(1, 0.2, 0.25)
	fg.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	fg.shaded = false
	fg.no_depth_test = true
	fg.position = Vector3(0, 2.5 * sc, 0)
	e.add_child(fg)
	var d: Dictionary = {
		"hp": base, "mhp": base, "spd": 3.2 + randf() * 1.2 + float(wave) * 0.15,
		"shoot": strong, "cd": 1.5, "hit": 0.0, "vy": 0.0, "spr": spr, "fg": fg,
		"side": 1.0 if randf() < 0.5 else -1.0, "mw": 58.0,
	}
	if strong:
		d["spd"] = 3.6
	e.set_meta("d", d)
	add_child(e)
	e.global_position = village.random_spawn(player.global_position)
	enemies.append(e)

func _next_wave() -> void:
	wave += 1
	if wave > 5:
		_finish(true)
		return
	for i in 4 + wave * 2:
		_spawn_enemy(false)

func _damage_enemy(e: Node, amount: float) -> void:
	var d: Dictionary = e.get_meta("d")
	d["hp"] = float(d["hp"]) - amount
	d["hit"] = 0.12
	hit_t = 0.18
	var fg: Sprite3D = d["fg"]
	fg.scale.x = maxf(0.01, float(d["mw"]) * clampf(float(d["hp"]) / float(d["mhp"]), 0.0, 1.0))
	if float(d["hp"]) <= 0.0:
		_kill(e)

func _kill(e: Node) -> void:
	if not enemies.has(e):
		return
	enemies.erase(e)
	kills += 1
	Game.s["m"]["kills"] = int(Game.s["m"]["kills"]) + 1
	var cb: CharacterBody3D = e as CharacterBody3D
	cb.collision_layer = 0
	var tw: Tween = create_tween()
	tw.tween_property(cb, "scale", Vector3(0.01, 0.01, 0.01), 0.25)
	tw.tween_callback(cb.queue_free)

func _tracer(a: Vector3, b: Vector3, col: Color) -> void:
	var dist: float = a.distance_to(b)
	if dist < 0.2:
		return
	var mi: MeshInstance3D = MeshInstance3D.new()
	var bm: BoxMesh = BoxMesh.new()
	bm.size = Vector3(0.025, 0.025, dist)
	mi.mesh = bm
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = col
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = m
	add_child(mi)
	mi.global_position = (a + b) / 2.0
	if absf((b - a).normalized().dot(Vector3.UP)) < 0.99:
		mi.look_at(b, Vector3.UP)
	var tw: Tween = create_tween()
	tw.tween_interval(0.06)
	tw.tween_callback(mi.queue_free)

func _spark(pos: Vector3) -> void:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var sm: SphereMesh = SphereMesh.new()
	sm.radius = 0.12
	sm.height = 0.24
	mi.mesh = sm
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = Color(1, 0.8, 0.3)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = m
	add_child(mi)
	mi.global_position = pos
	var tw: Tween = create_tween()
	tw.tween_property(mi, "scale", Vector3(0.05, 0.05, 0.05), 0.18)
	tw.tween_callback(mi.queue_free)

func _fire() -> void:
	if mode == "wood":
		return
	if shoot_cd > 0.0 or reload_t > 0.0 or switching:
		return
	if mode == "sandbox":
		_sandbox_action()
		shoot_cd = 0.25
		return
	if ammo <= 0:
		_start_reload()
		return
	_cancel_inspect()
	ammo -= 1
	var wp: Dictionary = WEAPONS[cur_weapon]
	shoot_cd = float(wp["cd"]) * (0.45 if rapid_t > 0.0 else 1.0)
	Game.shot(float(wp["pitch"]))
	kick += float(wp["kick"])
	_eject_casing()
	var from: Vector3 = cam.global_position
	var dir: Vector3 = -cam.global_transform.basis.z
	var spr_v: float = float(wp["spread"])
	if spr_v > 0.0:
		var cb: Basis = cam.global_transform.basis
		dir = (dir + cb.x * randf_range(-spr_v, spr_v) + cb.y * randf_range(-spr_v, spr_v)).normalized()
	var endp: Vector3 = from + dir * 90.0
	var q: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(from, endp, 3)
	q.exclude = [player.get_rid()]
	var r: Dictionary = get_world_3d().direct_space_state.intersect_ray(q)
	var muzzle: Vector3 = gun.global_position + dir * float(wp["dist"])
	if not r.is_empty():
		endp = r["position"]
		var col = r["collider"]
		if col != null and col.has_meta("d"):
			_damage_enemy(col, shot_dmg * float(wp["dmg"]))
		elif col != null and col.has_meta("peer"):
			_mp_hit(col, shot_dmg * float(wp["dmg"]))
		else:
			_spark(endp)
			_hole(endp, r["normal"])
	_tracer(muzzle, endp, Color(1, 0.9, 0.4))
	if mode == "mp" and net != null:
		net.rpc("remote_shot", muzzle, endp, float(wp["pitch"]))
	flash.visible = true
	gun.position.z = -0.45
	var tw: Tween = create_tween()
	tw.tween_property(gun, "position:z", -0.55, 0.1)
	tw.tween_callback(func(): flash.visible = false)
	if ammo <= 0:
		_start_reload()

func _sandbox_action() -> void:
	var from: Vector3 = cam.global_position
	var dir: Vector3 = -cam.global_transform.basis.z
	var q: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(from, from + dir * 9.0, 1)
	q.exclude = [player.get_rid()]
	var r: Dictionary = get_world_3d().direct_space_state.intersect_ray(q)
	if r.is_empty():
		return
	var col = r["collider"]
	if removing:
		if col != null and col.has_meta("block"):
			col.queue_free()
		return
	var pos: Vector3 = (r["position"] + r["normal"] * 0.5).floor() + Vector3(0.5, 0.5, 0.5)
	var pp: Vector3 = player.global_position
	if absf(pos.x - pp.x) < 0.95 and absf(pos.z - pp.z) < 0.95 and pos.y + 0.5 > pp.y and pos.y - 0.5 < pp.y + 1.8:
		return
	var b: StaticBody3D = StaticBody3D.new()
	b.set_meta("block", true)
	var mi: MeshInstance3D = MeshInstance3D.new()
	var bm: BoxMesh = BoxMesh.new()
	bm.size = Vector3(1, 1, 1)
	mi.mesh = bm
	mi.material_override = village.mat("planks", Color(1.0, 0.9, 0.75), 1.0)
	b.add_child(mi)
	var cs: CollisionShape3D = CollisionShape3D.new()
	var bs: BoxShape3D = BoxShape3D.new()
	bs.size = Vector3(1, 1, 1)
	cs.shape = bs
	b.add_child(cs)
	add_child(b)
	b.global_position = pos
	Game.vibrate(15)

func _physics_process(delta: float) -> void:
	if over or shop_open:
		return
	t += delta
	if mode == "mp" and mp_dead:
		respawn_t -= delta
		_toast("Ты убит! Возрождение через %d" % int(ceil(maxf(respawn_t, 0.0))))
		if respawn_t <= 0.0:
			_mp_respawn()
		_update_hud()
		return
	player.rotation.y = yaw
	kick = move_toward(kick, 0.0, delta * 0.3)
	cam.rotation.x = pitch + kick
	var inp: Vector2 = Vector2(joy_v.x, joy_v.y)
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		inp.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		inp.y += 1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		inp.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		inp.x += 1.0
	if inp.length() > 1.0:
		inp = inp.normalized()
	var bs: Basis = player.global_transform.basis
	var mv: Vector3 = bs.x * inp.x + bs.z * inp.y
	var sp: float = speed * (2.0 if dash_t > 0.0 else 1.0) * (1.25 if speed_t > 0.0 else 1.0)
	if player.is_on_floor():
		vel_y = -1.0
		if jump_req or Input.is_key_pressed(KEY_SPACE):
			vel_y = 7.5
	else:
		vel_y -= 22.0 * delta
	jump_req = false
	player.velocity = Vector3(mv.x * sp, vel_y, mv.z * sp)
	player.move_and_slide()
	vel_y = player.velocity.y
	Game.run_on(inp.length() > 0.2 and player.is_on_floor())
	if gun.position.z <= -0.54:
		gun.position.y = -0.26 + sin(t * 11.0) * 0.012 * inp.length()
	ab_cd = maxf(0.0, ab_cd - delta)
	shield_t = maxf(0.0, shield_t - delta)
	rapid_t = maxf(0.0, rapid_t - delta)
	dash_t = maxf(0.0, dash_t - delta)
	hurt_t = maxf(0.0, hurt_t - delta)
	hit_t = maxf(0.0, hit_t - delta)
	speed_t = maxf(0.0, speed_t - delta)
	_update_casings(delta)
	shoot_cd = maxf(0.0, shoot_cd - delta)
	if reload_t > 0.0:
		reload_t -= delta
		if reload_t <= 0.0:
			ammo = _mag()
	if Input.is_key_pressed(KEY_R):
		_start_reload()
	var qn: bool = Input.is_key_pressed(KEY_Q)
	if qn and not q_prev:
		_switch_weapon()
	q_prev = qn
	if fire_held or Input.is_key_pressed(KEY_F):
		_fire()
	_update_enemies(delta)
	if over:
		return
	if mode == "wood":
		_update_wood(delta)
	if mode == "battle" and enemies.is_empty():
		_finish(true)
	elif mode == "arena" and enemies.is_empty():
		_next_wave()
	elif mode == "survival":
		spawn_cd -= delta
		if spawn_cd <= 0.0 and enemies.size() < 30:
			_spawn_enemy(false)
			spawn_cd = maxf(0.4, 2.0 - t * 0.012)
	_update_hud()

func _update_enemies(delta: float) -> void:
	for e in enemies:
		var d: Dictionary = e.get_meta("d")
		var to: Vector3 = player.global_position - e.global_position
		to.y = 0.0
		var dist: float = to.length()
		var dirn: Vector3 = to / maxf(dist, 0.001)
		var spd_e: float = float(d["spd"])
		var mv: Vector3 = Vector3.ZERO
		if d["shoot"]:
			if dist > 16.0:
				mv = dirn * spd_e
			elif dist < 9.0:
				mv = -dirn * spd_e * 0.6
			else:
				mv = dirn.cross(Vector3.UP) * spd_e * 0.6 * float(d["side"])
			d["cd"] = float(d["cd"]) - delta
			if float(d["cd"]) <= 0.0:
				d["cd"] = 1.1 + randf() * 0.6
				_enemy_shot(e)
		else:
			if dist > 1.5:
				mv = dirn * spd_e
			else:
				_hurt(14.0 * delta)
		if e.is_on_floor():
			d["vy"] = -1.0
		else:
			d["vy"] = float(d["vy"]) - 22.0 * delta
		e.velocity = Vector3(mv.x, float(d["vy"]), mv.z)
		e.move_and_slide()
		d["vy"] = e.velocity.y
		d["hit"] = float(d["hit"]) - delta
		var spr: Sprite3D = d["spr"]
		spr.modulate = Color(1, 0.4, 0.4) if float(d["hit"]) > 0.0 else Color.WHITE

func _enemy_shot(e: Node3D) -> void:
	var from: Vector3 = e.global_position + Vector3(0, 1.4, 0)
	var to: Vector3 = player.global_position + Vector3(0, 1.4, 0)
	var q: PhysicsRayQueryParameters3D = PhysicsRayQueryParameters3D.create(from, to, 1)
	var r: Dictionary = get_world_3d().direct_space_state.intersect_ray(q)
	if not r.is_empty():
		return
	_tracer(from, to, Color(1, 0.3, 0.3))
	if randf() < 0.55:
		_hurt(9.0)

func _update_hud() -> void:
	hp_l.text = "HP %d / %d" % [int(hp), int(max_hp)]
	if mode == "survival":
		info_l.text = "Время %d с  |  Убито %d" % [int(t), kills]
	elif mode == "arena":
		info_l.text = "Волна %d / 5  |  Убито %d" % [mini(wave, 5), kills]
	elif mode == "battle":
		info_l.text = "Соперников: %d  |  Убито %d" % [enemies.size(), kills]
	elif mode == "mp":
		info_l.text = net.info_text()
	elif mode == "wood":
		var tp: Vector3 = truck.global_position + Vector3(-1.4, 0, 0)
		var dt: int = int(Vector2(player.global_position.x - tp.x, player.global_position.z - tp.z).length())
		info_l.text = "Дрова в грузовике: %d / %d  |  В руке: %s\nДо грузовика: %d м" % [loaded, WOOD_GOAL, "полено" if carried > 0 else "пусто", dt]
	else:
		info_l.text = "Песочница: цельтесь и жмите кнопку"
	if mode == "sandbox" or mode == "wood":
		ammo_l.text = ""
	elif reload_t > 0.0:
		ammo_l.text = "Перезарядка..."
	else:
		ammo_l.text = "%s  %d / %d" % [WEAPONS[cur_weapon]["name"], ammo, _mag()]
	if mode != "sandbox" and mode != "wood":
		btn_labels["ab"].text = "СПОСОБ-\nНОСТЬ" if ab_cd <= 0.0 else str(int(ceil(ab_cd)))
	use_near = mode != "mp" and player.global_position.distance_to(village.nina_pos) < 6.5
	btn_panels["use"].visible = use_near
	hud.queue_redraw()

# ---------- result ----------
func _finish(win: bool) -> void:
	if over:
		return
	over = true
	Game.run_on(false)
	fire_held = false
	var tr: int = 0
	var co: int = 0
	if win:
		tr = 30 if mode == "arena" else 25
		co = 200 if mode == "wood" else 80 + kills * 3
		Game.s["m"]["wins"] = int(Game.s["m"]["wins"]) + 1
	elif mode == "survival":
		tr = mini(30, int(t / 8.0))
		co = kills * 3 + int(t)
	else:
		tr = -8
		co = kills * 3
	Game.s["m"]["games"] = int(Game.s["m"]["games"]) + 1
	Game.add_trophies(tr)
	Game.s["coins"] = int(Game.s["coins"]) + co
	Game.s["xp"] = int(Game.s["xp"]) + 20 + kills
	Game.save_game()
	Game.vibrate(200)
	_show_result(win, tr, co)

func _show_result(win: bool, tr: int, co: int) -> void:
	var dim: ColorRect = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.75)
	dim.size = vp
	layer.add_child(dim)
	var v: VBoxContainer = VBoxContainer.new()
	v.size = Vector2(560, 560)
	v.position = (vp - v.size) / 2.0
	v.add_theme_constant_override("separation", 16)
	layer.add_child(v)
	var title: String = "ПОБЕДА!" if win else ("ИГРА ОКОНЧЕНА" if mode == "survival" else "ПОРАЖЕНИЕ")
	var tl: Label = Game.make_label(title, 76, Color("ffd21f") if win else Color.WHITE)
	tl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(tl)
	var st: Label = Game.make_label(("Дров загружено: %d\nТрофеи: %+d\nМонеты: +%d" % [loaded, tr, co]) if mode == "wood" else ("Убито: %d\nТрофеи: %+d\nМонеты: +%d" % [kills, tr, co]), 40)
	st.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(st)
	var again: Button = Game.make_button("Ещё раз", 44)
	again.custom_minimum_size = Vector2(0, 96)
	again.pressed.connect(func(): exit_requested.emit(true))
	v.add_child(again)
	var menu: Button = Game.make_button("В меню", 44, Color("0d1650"), Color.WHITE)
	menu.custom_minimum_size = Vector2(0, 96)
	menu.pressed.connect(func(): exit_requested.emit(false))
	v.add_child(menu)

# ---------- wood mode ----------
func _setup_wood() -> void:
	held_log = MeshInstance3D.new()
	var hc: CylinderMesh = CylinderMesh.new()
	hc.top_radius = 0.09
	hc.bottom_radius = 0.09
	hc.height = 0.75
	hc.radial_segments = 10
	held_log.mesh = hc
	held_log.material_override = village.mat("logs", Color(1.0, 0.9, 0.8), 0.9)
	held_log.position = Vector3(0.3, -0.32, -0.6)
	held_log.rotation_degrees = Vector3(25, 0, 62)
	held_log.visible = false
	cam.add_child(held_log)
	truck = village.spawn_truck(Vector3(-44.0, 0.0, -4.4), 0.0)
	for i in 36:
		var n: Node3D = village.wood_pile(village.random_free())
		piles.append({"n": n, "mk": n.get_node("mk")})

func _update_wood(delta: float) -> void:
	if wood_done:
		return
	var pp: Vector3 = player.global_position
	for p in piles.duplicate():
		var n: Node3D = p["n"]
		var mk: Node3D = p["mk"]
		mk.rotation.y += delta * 2.0
		mk.position.y = 1.7 + sin(t * 3.0 + n.position.x) * 0.15
		if Vector2(pp.x - n.global_position.x, pp.z - n.global_position.z).length() < 1.8:
			if carried < CARRY_MAX:
				carried += 1
				piles.erase(p)
				n.queue_free()
				Game.click()
				held_log.visible = true
				gun.visible = false
				_toast("Взял полено! Неси в грузовик")
			elif t - last_full_toast > 2.0:
				last_full_toast = t
				_toast("Руки заняты! Отнеси полено в грузовик")
	if carried > 0:
		var tp: Vector3 = truck.global_position + Vector3(-1.4, 0, 0)
		if Vector2(pp.x - tp.x, pp.z - tp.z).length() < 5.0:
			if loaded < WOOD_GOAL:
				village.truck_add_log(truck, loaded)
				loaded += 1
			carried = 0
			held_log.visible = false
			gun.visible = true
			Game.click()
			Game.vibrate(40)
			_toast("Полено в кузове! (%d / %d)" % [loaded, WOOD_GOAL])
			if loaded >= WOOD_GOAL:
				_truck_leave()

func _truck_leave() -> void:
	wood_done = true
	_toast("Грузовик полон! Он уезжает...")
	var tw: Tween = create_tween()
	tw.tween_interval(1.0)
	tw.tween_property(truck, "position:x", truck.position.x + 140.0, 6.0).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.tween_callback(func(): _finish(true))

# ---------- multiplayer ----------
func _setup_mp() -> void:
	var ids: Array = Game.mp_roster.keys()
	ids.sort()
	spawn_idx = maxi(0, ids.find(multiplayer.get_unique_id()))
	player.position = MP_SPAWNS[spawn_idx % MP_SPAWNS.size()]
	net = Node3D.new()
	net.name = "Net"
	net.set_script(load("res://scripts/net.gd"))
	add_child(net)
	net.setup(self)
	_toast("Бой до %d убийств! Удачи!" % net.KILL_LIMIT)

func _mp_hit(col: Node, dmg: float) -> void:
	hit_t = 0.18
	net.rpc_id(int(col.get_meta("peer")), "take_hit", dmg, multiplayer.get_unique_id())

func _mp_take_hit(dmg: float, shooter: int) -> void:
	if mp_dead or over:
		return
	last_hitter = shooter
	_hurt(dmg)

func _mp_die() -> void:
	if mp_dead:
		return
	mp_dead = true
	respawn_t = 3.0
	hp = 0.0
	fire_held = false
	Game.vibrate(150)
	if multiplayer.is_server():
		net.register_kill(last_hitter, 1)
	else:
		net.rpc_id(1, "report_death", last_hitter)

func _mp_respawn() -> void:
	mp_dead = false
	hp = max_hp
	ammo_by = {"pistol": 12, "ak47": 30}
	ammo = _mag()
	reload_t = 0.0
	shield_t = 2.0
	vel_y = 0.0
	player.position = MP_SPAWNS[randi() % MP_SPAWNS.size()]
	_toast("Ты снова в бою!")

func _mp_finish(sc: Dictionary) -> void:
	if over:
		return
	over = true
	Game.run_on(false)
	var my: int = multiplayer.get_unique_id()
	var ids: Array = sc.keys()
	ids.sort_custom(func(a, b2): return int(sc[a]) > int(sc[b2]))
	var rank: int = ids.find(my) + 1
	var kills_me: int = int(sc.get(my, 0))
	var win: bool = rank == 1 and kills_me > 0
	var tr: int = 20 if win else (8 if rank == 2 else 0)
	var co: int = 60 + kills_me * 25 + (150 if win else 0)
	Game.add_trophies(tr)
	Game.s["coins"] = int(Game.s["coins"]) + co
	Game.s["xp"] = int(Game.s["xp"]) + 20 + kills_me
	Game.s["m"]["games"] = int(Game.s["m"]["games"]) + 1
	Game.s["m"]["kills"] = int(Game.s["m"]["kills"]) + kills_me
	if win:
		Game.s["m"]["wins"] = int(Game.s["m"]["wins"]) + 1
	Game.save_game()
	var txt: String = ""
	for i in ids.size():
		var nm: String = str(Game.mp_roster[ids[i]]["name"]) if Game.mp_roster.has(ids[i]) else "?"
		txt += "%d. %s — %d\n" % [i + 1, nm, int(sc[ids[i]])]
	txt += "\nТрофеи: %+d   Монеты: +%d" % [tr, co]
	var dim: ColorRect = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.78)
	dim.size = vp
	layer.add_child(dim)
	var v: VBoxContainer = VBoxContainer.new()
	v.size = Vector2(640, 580)
	v.position = (vp - v.size) / 2.0
	v.add_theme_constant_override("separation", 14)
	layer.add_child(v)
	var tl: Label = Game.make_label("ПОБЕДА!" if win else "МАТЧ ЗАВЕРШЁН", 70, Color("ffd21f") if win else Color.WHITE)
	tl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(tl)
	var st: Label = Game.make_label(txt, 32)
	st.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(st)
	var menu: Button = Game.make_button("В меню", 44, Color("0d1650"), Color.WHITE)
	menu.custom_minimum_size = Vector2(0, 90)
	menu.pressed.connect(_on_exit)
	v.add_child(menu)
