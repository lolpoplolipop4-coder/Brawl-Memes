extends Node3D
# Procedural Russian village: izbas, church, well, banya, barn, fences, birches, spruces.

var tex_cache: Dictionary = {}
var mat_cache: Dictionary = {}
var occupied: Array = []
var player_start: Vector3 = Vector3(-55.0, 1.0, 0.0)
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var nina_pos: Vector3 = Vector3(-46.0, 1.4, 5.5)

# ---------- textures / materials ----------
func make_tex(kind: String) -> ImageTexture:
	if tex_cache.has(kind):
		return tex_cache[kind]
	var n: int = 64
	var img: Image = Image.create(n, n, false, Image.FORMAT_RGB8)
	var r: RandomNumberGenerator = RandomNumberGenerator.new()
	r.seed = hash(kind)
	for y in n:
		for x in n:
			var c: Color = Color.WHITE
			var nz: float = r.randf()
			if kind == "logs":
				var edge: float = -0.22 if (y % 8 == 7 or y % 8 == 0) else 0.0
				var v: float = 0.85 + nz * 0.15 + edge + (0.05 if (y / 8) % 2 == 0 else 0.0)
				c = Color(0.58 * v, 0.38 * v, 0.2 * v)
			elif kind == "roof":
				var row: int = y / 8
				var col: int = (x + (row % 2) * 4) / 8
				var sh: float = 0.75 + 0.25 * fposmod(sin(float(row * 13 + col * 7)) * 43758.5, 1.0)
				var edge2: float = -0.3 if (y % 8 >= 6) else 0.0
				var v2: float = sh + edge2 + nz * 0.05
				c = Color(0.5 * v2, 0.2 * v2, 0.15 * v2)
			elif kind == "grass":
				var v3: float = 0.8 + nz * 0.35
				c = Color(0.28 * v3, 0.5 * v3, 0.18 * v3)
			elif kind == "dirt":
				var v4: float = 0.8 + nz * 0.3
				c = Color(0.46 * v4, 0.35 * v4, 0.23 * v4)
			elif kind == "planks":
				var pn: int = x / 8
				var v5: float = 0.85 + 0.12 * fposmod(sin(float(pn * 17)) * 9999.0, 1.0) + nz * 0.04
				if x % 8 == 0:
					v5 *= 0.55
				c = Color(0.68 * v5, 0.5 * v5, 0.3 * v5)
			elif kind == "birch":
				c = Color(0.93, 0.93, 0.9) * (0.92 + nz * 0.08)
				if (y % 12 == 3 or y % 12 == 4) and fposmod(sin(float(x / 5 * 31 + y / 12 * 7)) * 5555.0, 1.0) > 0.4:
					c = Color(0.1, 0.1, 0.1)
			elif kind == "stone":
				var by: int = y / 16
				var bx: int = (x + (by % 2) * 8) / 16
				var v6: float = 0.55 + 0.1 * fposmod(sin(float(bx * 5 + by * 11)) * 7777.0, 1.0) + nz * 0.05
				if y % 16 == 0 or (x + (by % 2) * 8) % 16 == 0:
					v6 *= 0.6
				c = Color(v6, v6, v6 * 0.97)
			elif kind == "plaster":
				var v7: float = 0.94 + nz * 0.05
				c = Color(v7, v7 * 0.99, v7 * 0.94)
			elif kind == "tiles":
				var chk: int = ((x / 16) + (y / 16)) % 2
				var v9: float = 0.9 + nz * 0.08
				c = Color(0.86 * v9, 0.78 * v9, 0.6 * v9) if chk == 0 else Color(0.62 * v9, 0.5 * v9, 0.38 * v9)
			elif kind == "rainbow":
				var k2: int = ((x / 16) * 7 + (y / 16) * 13) % 6
				var pal: Array = [Color(1.0, 0.45, 0.6), Color(1.0, 0.8, 0.25), Color(0.4, 0.85, 0.5), Color(0.35, 0.7, 1.0), Color(0.7, 0.5, 1.0), Color(1.0, 0.6, 0.25)]
				var base_c: Color = pal[k2]
				var v10: float = 0.95 + nz * 0.05
				if x % 16 == 0 or y % 16 == 0:
					v10 *= 0.7
				c = Color(base_c.r * v10, base_c.g * v10, base_c.b * v10)
			elif kind == "books":
				var shelf: int = y / 21
				var bx2: int = x / 5
				var hsh: float = fposmod(sin(float(bx2 * 12 + shelf * 31)) * 9876.0, 1.0)
				var bp: Array = [Color(0.8, 0.2, 0.2), Color(0.2, 0.4, 0.8), Color(0.2, 0.6, 0.3), Color(0.9, 0.7, 0.2), Color(0.5, 0.25, 0.6), Color(0.85, 0.5, 0.2)]
				c = bp[int(hsh * 6.0) % 6] * (0.8 + nz * 0.2)
				if y % 21 > 18 or x % 5 == 0:
					c = Color(0.35, 0.22, 0.12)
				if y % 21 < 3 + int(hsh * 4.0):
					c = Color(0.55, 0.38, 0.2)
			elif kind == "leaf":
				var v8: float = 0.7 + nz * 0.5
				c = Color(0.2 * v8, 0.5 * v8, 0.16 * v8)
			img.set_pixel(x, y, c)
	img.generate_mipmaps()
	var t: ImageTexture = ImageTexture.create_from_image(img)
	tex_cache[kind] = t
	return t

func mat(kind: String, tint: Color = Color.WHITE, sc: float = 0.5) -> StandardMaterial3D:
	var key: String = "%s_%s_%s" % [kind, tint.to_html(), sc]
	if mat_cache.has(key):
		return mat_cache[key]
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_texture = make_tex(kind)
	m.albedo_color = tint
	m.uv1_triplanar = true
	m.uv1_scale = Vector3(sc, sc, sc)
	m.roughness = 1.0
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	mat_cache[key] = m
	return m

func cmat(col: Color, unshaded: bool = false) -> StandardMaterial3D:
	var key: String = "c_%s_%s" % [col.to_html(), unshaded]
	if mat_cache.has(key):
		return mat_cache[key]
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = 0.9
	if unshaded:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat_cache[key] = m
	return m

# ---------- mesh helpers ----------
func add_box(parent: Node3D, pos: Vector3, size: Vector3, m: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var b: BoxMesh = BoxMesh.new()
	b.size = size
	mi.mesh = b
	mi.material_override = m
	mi.position = pos
	mi.rotation_degrees = rot
	parent.add_child(mi)
	return mi

func add_cyl(parent: Node3D, pos: Vector3, r_top: float, r_bot: float, h: float, m: Material, seg: int = 14) -> MeshInstance3D:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var c: CylinderMesh = CylinderMesh.new()
	c.top_radius = r_top
	c.bottom_radius = r_bot
	c.height = h
	c.radial_segments = seg
	c.rings = 1
	mi.mesh = c
	mi.material_override = m
	mi.position = pos
	parent.add_child(mi)
	return mi

func add_sphere(parent: Node3D, pos: Vector3, radius: float, m: Material, sc: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var s: SphereMesh = SphereMesh.new()
	s.radius = radius
	s.height = radius * 2.0
	s.radial_segments = 14
	s.rings = 8
	mi.mesh = s
	mi.material_override = m
	mi.position = pos
	mi.scale = sc
	parent.add_child(mi)
	return mi

func add_prism(parent: Node3D, pos: Vector3, size: Vector3, m: Material) -> MeshInstance3D:
	var mi: MeshInstance3D = MeshInstance3D.new()
	var p: PrismMesh = PrismMesh.new()
	p.size = size
	mi.mesh = p
	mi.material_override = m
	mi.position = pos
	parent.add_child(mi)
	return mi

func add_col(body: StaticBody3D, pos: Vector3, size: Vector3) -> void:
	var cs: CollisionShape3D = CollisionShape3D.new()
	var s: BoxShape3D = BoxShape3D.new()
	s.size = size
	cs.shape = s
	cs.position = pos
	body.add_child(cs)

func add_cyl_col(body: StaticBody3D, pos: Vector3, radius: float, h: float) -> void:
	var cs: CollisionShape3D = CollisionShape3D.new()
	var s: CylinderShape3D = CylinderShape3D.new()
	s.radius = radius
	s.height = h
	cs.shape = s
	cs.position = pos
	body.add_child(cs)

func body_at(pos: Vector3, rot_y: float = 0.0) -> StaticBody3D:
	var b: StaticBody3D = StaticBody3D.new()
	b.position = pos
	b.rotation_degrees = Vector3(0, rot_y, 0)
	add_child(b)
	return b

func occupy(pos: Vector3, radius: float) -> void:
	occupied.append([pos, radius])

# ---------- build ----------
func build() -> void:
	rng.seed = 20260707
	_environment()
	_ground()
	_roads()
	for i in 7:
		var x: float = -48.0 + float(i) * 16.0
		house(Vector3(x, 0.0, -17.0), 0.0, 5.0 + float(i % 3) * 0.6, 7.0, Color(1.0, 0.95 - float(i % 2) * 0.12, 0.9))
		house(Vector3(x + 5.0, 0.0, 17.0), 180.0, 5.0 + float((i + 1) % 3) * 0.6, 6.5, Color(0.95, 0.88 + float(i % 2) * 0.1, 0.85))
	kiosk(Vector3(-46.0, 0.0, 6.6), 180.0)
	well(Vector3(8.0, 0.0, 6.0))
	church(Vector3(30.0, 0.0, -38.0))
	barn(Vector3(-50.0, 0.0, 36.0), 20.0)
	banya(Vector3(-20.0, 0.0, -34.0), 10.0)
	banya(Vector3(48.0, 0.0, 34.0), -20.0)
	for p in [Vector3(-44, 0, 31), Vector3(-41, 0, 39), Vector3(-56, 0, 32)]:
		haystack(p)
	for p in [Vector3(-28, 0, 6), Vector3(14, 0, -6), Vector3(40, 0, 6), Vector3(-6, 0, -6)]:
		barrel(p)
		woodpile(p + Vector3(2.5, 0, 1.0), 20.0)
	_forest()
	_bounds()
	_sign()
	player_start = Vector3(-62.0, 1.0, 0.0)

func _environment() -> void:
	var we: WorldEnvironment = WorldEnvironment.new()
	var env: Environment = Environment.new()
	var sky: Sky = Sky.new()
	var sm: ProceduralSkyMaterial = ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.25, 0.5, 0.9)
	sm.sky_horizon_color = Color(0.75, 0.85, 0.95)
	sm.ground_horizon_color = Color(0.7, 0.8, 0.85)
	sm.ground_bottom_color = Color(0.35, 0.45, 0.3)
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	we.environment = env
	add_child(we)
	var sun: DirectionalLight3D = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48.0, 35.0, 0.0)
	sun.light_energy = 1.15
	sun.light_color = Color(1.0, 0.96, 0.88)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 70.0
	add_child(sun)

func _ground() -> void:
	var g: StaticBody3D = body_at(Vector3(0, 0, 0))
	add_box(g, Vector3(0, -0.05, 0), Vector3(180, 0.1, 140), mat("grass", Color(0.95, 1.0, 0.9), 0.3))
	add_col(g, Vector3(0, -1.0, 0), Vector3(180, 2.0, 140))

func _roads() -> void:
	var dirt: Material = mat("dirt", Color.WHITE, 0.3)
	add_box(self, Vector3(0, 0.02, 0), Vector3(170, 0.04, 5.0), dirt)
	add_box(self, Vector3(-14, 0.02, 0), Vector3(4.0, 0.04, 100), dirt)
	add_box(self, Vector3(24, 0.02, -19), Vector3(4.0, 0.04, 38), dirt)
	add_box(self, Vector3(40, 0.025, 20), Vector3(40, 0.04, 3.0), dirt)

func _bounds() -> void:
	for d in [[Vector3(0, 5, -68), Vector3(190, 10, 2)], [Vector3(0, 5, 68), Vector3(190, 10, 2)], [Vector3(-88, 5, 0), Vector3(2, 10, 140)], [Vector3(88, 5, 0), Vector3(2, 10, 140)]]:
		var b: StaticBody3D = body_at(d[0])
		add_col(b, Vector3.ZERO, d[1])

func _sign() -> void:
	var b: StaticBody3D = body_at(Vector3(-58, 0, -3.5), 90.0)
	add_cyl(b, Vector3(-1.2, 1.2, 0), 0.1, 0.1, 2.4, mat("logs"))
	add_cyl(b, Vector3(1.2, 1.2, 0), 0.1, 0.1, 2.4, mat("logs"))
	add_box(b, Vector3(0, 2.1, 0), Vector3(3.2, 0.9, 0.12), mat("planks", Color(1, 0.9, 0.7), 0.6))
	add_col(b, Vector3(0, 1.2, 0), Vector3(3.0, 2.4, 0.3))
	var l: Label3D = Label3D.new()
	l.text = "ДЕРЕВНЯ\nВАСИЛЬЕВКА"
	l.font_size = 48
	l.pixel_size = 0.0125
	l.modulate = Color(0.25, 0.1, 0.05)
	l.outline_size = 0
	l.position = Vector3(0, 2.1, 0.08)
	b.add_child(l)

# ---------- objects ----------
func house(pos: Vector3, rot: float, w: float, d: float, tint: Color) -> void:
	var b: StaticBody3D = body_at(pos, rot)
	var h: float = 2.8
	var logs: Material = mat("logs", tint, 0.5)
	var white: Material = cmat(Color(0.96, 0.96, 0.93))
	var blue: Material = cmat(Color(0.2, 0.45, 0.8))
	var glass: Material = cmat(Color(0.55, 0.78, 0.95))
	add_box(b, Vector3(0, 0.25, 0), Vector3(w + 0.3, 0.5, d + 0.3), mat("stone", Color.WHITE, 0.5))
	add_box(b, Vector3(0, 0.5 + h / 2.0, 0), Vector3(w, h, d), logs)
	add_col(b, Vector3(0, (h + 0.5) / 2.0, 0), Vector3(w, h + 0.5, d))
	add_prism(b, Vector3(0, 0.5 + h + 1.0, 0), Vector3(w + 1.1, 2.0, d + 1.1), mat("roof", Color.WHITE, 0.4))
	add_prism(b, Vector3(0, 0.5 + h + 0.95, d / 2.0 + 0.58), Vector3(w + 0.5, 1.7, 0.06), mat("planks", Color(1.0, 0.9, 0.75), 0.5))
	add_box(b, Vector3(0, 0.5 + h + 0.7, d / 2.0 + 0.63), Vector3(0.55, 0.55, 0.06), white)
	add_box(b, Vector3(0, 0.5 + h + 0.7, d / 2.0 + 0.66), Vector3(0.38, 0.38, 0.06), glass)
	add_box(b, Vector3(0.0, 0.5 + h + 1.8, -1.6), Vector3(0.7, 1.8, 0.7), cmat(Color(0.55, 0.25, 0.2)))
	smoke(b, Vector3(0.0, 0.5 + h + 2.8, -1.6))
	# front: door + window
	add_box(b, Vector3(-1.0, 1.45, d / 2.0 + 0.04), Vector3(1.2, 2.1, 0.08), white)
	add_box(b, Vector3(-1.0, 1.4, d / 2.0 + 0.08), Vector3(0.9, 1.9, 0.08), cmat(Color(0.35, 0.2, 0.1)))
	add_box(b, Vector3(-1.0, 0.3, d / 2.0 + 0.7), Vector3(1.6, 0.3, 1.2), mat("planks", Color.WHITE, 0.6))
	_window(b, Vector3(1.4, 2.0, d / 2.0), 0.0, white, blue, glass)
	# long sides: two windows each
	for sx in [-1.0, 1.0]:
		for wz in [-1.8, 1.8]:
			_window(b, Vector3(sx * w / 2.0, 2.0, wz), 90.0 * sx, white, blue, glass)
	# yard
	garden(b, Vector3(w / 2.0 + 2.6, 0.0, -1.0))
	occupy(pos, maxf(w, d) * 0.5 + 2.0)
	var t: Transform3D = Transform3D(Basis(Vector3.UP, deg_to_rad(rot)), pos)
	var fz: float = d / 2.0 + 4.6
	var bz: float = -(d / 2.0 + 5.0)
	var sxe: float = w / 2.0 + 5.2
	fence(t * Vector3(-sxe, 0, fz), t * Vector3(-3.2, 0, fz))
	fence(t * Vector3(-0.8, 0, fz), t * Vector3(sxe, 0, fz))
	fence(t * Vector3(-sxe, 0, bz), t * Vector3(sxe, 0, bz))
	fence(t * Vector3(-sxe, 0, bz), t * Vector3(-sxe, 0, fz))
	fence(t * Vector3(sxe, 0, bz), t * Vector3(sxe, 0, fz))
	birch(t * Vector3(-sxe + 1.2, 0, fz - 1.5))
	var p2: Vector3 = t * Vector3(sxe - 1.5, 0, bz + 2.0)
	spruce(p2)

func _window(parent: Node3D, pos: Vector3, rot_y: float, white: Material, blue: Material, glass: Material) -> void:
	var w: Node3D = Node3D.new()
	w.position = pos
	w.rotation_degrees = Vector3(0, rot_y, 0)
	parent.add_child(w)
	add_box(w, Vector3(0, 0, 0.03), Vector3(1.25, 1.5, 0.08), white)
	add_box(w, Vector3(0, 0, 0.08), Vector3(0.85, 1.1, 0.06), glass)
	add_box(w, Vector3(0, 0, 0.12), Vector3(0.06, 1.1, 0.03), white)
	add_box(w, Vector3(0, 0, 0.12), Vector3(0.85, 0.06, 0.03), white)
	add_box(w, Vector3(-0.62, 0, 0.1), Vector3(0.34, 1.1, 0.05), blue)
	add_box(w, Vector3(0.62, 0, 0.1), Vector3(0.34, 1.1, 0.05), blue)

func garden(parent: Node3D, pos: Vector3) -> void:
	add_box(parent, pos + Vector3(0, 0.08, 0), Vector3(2.2, 0.16, 4.0), cmat(Color(0.28, 0.18, 0.1)))
	for i in 4:
		add_box(parent, pos + Vector3(-0.6 + float(i % 2) * 1.2, 0.35, -1.4 + float(i / 2) * 2.4), Vector3(0.6, 0.45, 0.6), cmat(Color(0.2, 0.55, 0.2)))

func fence(a: Vector3, b: Vector3) -> void:
	var flen: float = a.distance_to(b)
	if flen < 0.5:
		return
	var mid: Vector3 = (a + b) / 2.0
	var ang: float = rad_to_deg(atan2(-(b.z - a.z), (b.x - a.x)))
	var f: StaticBody3D = body_at(mid, ang)
	add_box(f, Vector3(0, 0.55, 0), Vector3(flen, 1.1, 0.1), mat("planks", Color(0.95, 0.85, 0.7), 0.7))
	add_box(f, Vector3(0, 1.12, 0), Vector3(flen, 0.08, 0.16), mat("logs"))
	add_col(f, Vector3(0, 0.55, 0), Vector3(flen, 1.1, 0.25))

func birch(pos: Vector3) -> void:
	var b: StaticBody3D = body_at(pos)
	add_cyl(b, Vector3(0, 3.0, 0), 0.16, 0.22, 6.0, mat("birch", Color.WHITE, 0.6), 8)
	var leaf: Material = mat("leaf", Color(0.85, 1.0, 0.7), 0.5)
	add_sphere(b, Vector3(0, 5.6, 0), 1.7, leaf, Vector3(1.0, 0.9, 1.0))
	add_sphere(b, Vector3(0.8, 6.6, 0.3), 1.3, leaf)
	add_sphere(b, Vector3(-0.8, 6.2, -0.4), 1.4, leaf)
	add_cyl_col(b, Vector3(0, 2.0, 0), 0.28, 4.0)
	occupy(pos, 1.0)

func spruce(pos: Vector3) -> void:
	var b: StaticBody3D = body_at(pos)
	var dk: Material = mat("leaf", Color(0.35, 0.65, 0.4), 0.5)
	add_cyl(b, Vector3(0, 1.0, 0), 0.2, 0.28, 2.0, mat("logs"), 8)
	add_cyl(b, Vector3(0, 2.8, 0), 0.0, 2.2, 3.0, dk)
	add_cyl(b, Vector3(0, 4.5, 0), 0.0, 1.8, 2.8, dk)
	add_cyl(b, Vector3(0, 6.0, 0), 0.0, 1.3, 2.6, dk)
	add_cyl_col(b, Vector3(0, 2.0, 0), 0.4, 4.0)
	occupy(pos, 1.5)

func well(pos: Vector3) -> void:
	var b: StaticBody3D = body_at(pos)
	add_cyl(b, Vector3(0, 0.5, 0), 1.0, 1.0, 1.0, mat("stone", Color.WHITE, 0.8), 16)
	add_cyl(b, Vector3(0, 0.95, 0), 0.8, 0.8, 0.06, cmat(Color(0.1, 0.2, 0.35)), 16)
	add_box(b, Vector3(-1.0, 1.6, 0), Vector3(0.18, 2.2, 0.18), mat("logs"))
	add_box(b, Vector3(1.0, 1.6, 0), Vector3(0.18, 2.2, 0.18), mat("logs"))
	add_box(b, Vector3(0, 1.9, 0), Vector3(2.4, 0.14, 0.14), mat("logs"))
	add_prism(b, Vector3(0, 2.95, 0), Vector3(2.6, 0.9, 2.0), mat("roof", Color.WHITE, 0.4))
	add_cyl(b, Vector3(0, 1.35, 0), 0.22, 0.2, 0.3, mat("planks"), 10)
	add_cyl_col(b, Vector3(0, 0.6, 0), 1.0, 1.2)
	occupy(pos, 2.5)

func church(pos: Vector3) -> void:
	var b: StaticBody3D = body_at(pos, 0.0)
	var pl: Material = mat("plaster", Color.WHITE, 0.4)
	var green: Material = cmat(Color(0.12, 0.45, 0.3))
	var gold: Material = cmat(Color(1.0, 0.8, 0.2))
	var arch: Material = cmat(Color(0.15, 0.25, 0.5))
	add_box(b, Vector3(0, 0.4, 0), Vector3(10.5, 0.8, 14.5), mat("stone", Color.WHITE, 0.5))
	add_box(b, Vector3(0, 4.3, 0), Vector3(9, 7, 13), pl)
	add_col(b, Vector3(0, 4.0, 0), Vector3(9, 8, 13))
	add_prism(b, Vector3(0, 9.3, 0), Vector3(10, 3.0, 14), green)
	# bell tower
	add_box(b, Vector3(0, 6.0, 8.2), Vector3(5, 11, 4.5), pl)
	add_col(b, Vector3(0, 5.5, 8.2), Vector3(5, 11, 4.5))
	add_box(b, Vector3(0, 12.2, 8.2), Vector3(4.2, 2.6, 3.8), pl)
	add_cyl(b, Vector3(0, 15.4, 8.2), 0.0, 3.0, 3.8, green, 4)
	add_sphere(b, Vector3(0, 17.8, 8.2), 0.9, gold, Vector3(1.0, 1.4, 1.0))
	add_box(b, Vector3(0, 19.6, 8.2), Vector3(0.12, 1.8, 0.12), gold)
	add_box(b, Vector3(0, 19.9, 8.2), Vector3(0.9, 0.12, 0.12), gold)
	# main drum + onion dome
	add_cyl(b, Vector3(0, 11.6, -1.5), 2.2, 2.2, 2.4, pl, 16)
	add_sphere(b, Vector3(0, 14.0, -1.5), 2.2, gold, Vector3(1.0, 1.5, 1.0))
	add_box(b, Vector3(0, 17.2, -1.5), Vector3(0.14, 2.4, 0.14), gold)
	add_box(b, Vector3(0, 17.6, -1.5), Vector3(1.2, 0.14, 0.14), gold)
	# apse
	add_cyl(b, Vector3(0, 3.0, -7.4), 3.0, 3.0, 6.0, pl, 14)
	add_cyl(b, Vector3(0, 6.6, -7.4), 0.0, 3.2, 1.6, green, 14)
	# door + windows
	add_box(b, Vector3(0, 1.8, 10.5), Vector3(2.2, 3.4, 0.2), cmat(Color(0.3, 0.17, 0.08)))
	add_box(b, Vector3(0, 3.7, 10.5), Vector3(1.6, 0.5, 0.2), cmat(Color(0.3, 0.17, 0.08)))
	for sx in [-1.0, 1.0]:
		for wz in [-3.5, 0.5, 4.0]:
			add_box(b, Vector3(sx * 4.55, 4.5, wz), Vector3(0.12, 2.4, 1.1), arch)
			add_box(b, Vector3(sx * 4.55, 5.8, wz), Vector3(0.12, 0.5, 0.8), arch)
	occupy(pos + Vector3(0, 0, 3.0), 12.0)

func barn(pos: Vector3, rot: float) -> void:
	var b: StaticBody3D = body_at(pos, rot)
	add_box(b, Vector3(0, 2.5, 0), Vector3(10, 5, 7), mat("planks", Color(0.8, 0.7, 0.6), 0.5))
	add_col(b, Vector3(0, 2.5, 0), Vector3(10, 5, 7))
	add_prism(b, Vector3(0, 6.3, 0), Vector3(7.8, 2.6, 11), cmat(Color(0.4, 0.4, 0.42)))
	add_box(b, Vector3(0, 2.0, 3.55), Vector3(3.2, 4.0, 0.1), cmat(Color(0.35, 0.2, 0.1)))
	occupy(pos, 8.0)

func banya(pos: Vector3, rot: float) -> void:
	var b: StaticBody3D = body_at(pos, rot)
	add_box(b, Vector3(0, 1.4, 0), Vector3(4, 2.8, 4.5), mat("logs", Color(0.55, 0.45, 0.4), 0.5))
	add_col(b, Vector3(0, 1.4, 0), Vector3(4, 2.8, 4.5))
	add_prism(b, Vector3(0, 3.6, 0), Vector3(4.8, 1.6, 5.3), mat("planks", Color(0.6, 0.5, 0.45), 0.5))
	add_box(b, Vector3(1.2, 4.2, -1.0), Vector3(0.5, 1.8, 0.5), cmat(Color(0.3, 0.3, 0.3)))
	smoke(b, Vector3(1.2, 5.3, -1.0))
	add_box(b, Vector3(-0.6, 1.1, 2.28), Vector3(0.9, 1.9, 0.08), cmat(Color(0.3, 0.17, 0.08)))
	occupy(pos, 4.0)

func haystack(pos: Vector3) -> void:
	var b: StaticBody3D = body_at(pos)
	add_sphere(b, Vector3(0, 0.6, 0), 1.6, cmat(Color(0.85, 0.7, 0.3)), Vector3(1.0, 1.15, 1.0))
	add_cyl_col(b, Vector3(0, 1.0, 0), 1.5, 2.0)
	occupy(pos, 2.2)

func barrel(pos: Vector3) -> void:
	var b: StaticBody3D = body_at(pos)
	add_cyl(b, Vector3(0, 0.5, 0), 0.45, 0.45, 1.0, mat("planks", Color(0.9, 0.75, 0.55), 0.8), 12)
	add_box(b, Vector3(0, 0.25, 0), Vector3(0.95, 0.06, 0.95), cmat(Color(0.2, 0.2, 0.2)))
	add_cyl_col(b, Vector3(0, 0.5, 0), 0.45, 1.0)

func woodpile(pos: Vector3, rot: float) -> void:
	var b: StaticBody3D = body_at(pos, rot)
	for i in 3:
		add_box(b, Vector3(0, 0.25 + float(i) * 0.5, 0), Vector3(1.8 - float(i) * 0.2, 0.5, 0.9), mat("logs", Color(1.0, 0.9, 0.8), 0.9))
	add_col(b, Vector3(0, 0.75, 0), Vector3(1.8, 1.5, 0.9))

func _forest() -> void:
	var x: float = -84.0
	while x <= 84.0:
		var jx: float = rng.randf_range(-1.5, 1.5)
		_tree(Vector3(x + jx, 0, -62.0 + rng.randf_range(-3, 3)))
		_tree(Vector3(x + jx, 0, 62.0 + rng.randf_range(-3, 3)))
		x += 5.0
	var z: float = -56.0
	while z <= 56.0:
		_tree(Vector3(-82.0 + rng.randf_range(-3, 3), 0, z))
		_tree(Vector3(82.0 + rng.randf_range(-3, 3), 0, z))
		z += 5.0
	var placed: int = 0
	var tries: int = 0
	while placed < 40 and tries < 400:
		tries += 1
		var p: Vector3 = Vector3(rng.randf_range(-76, 76), 0, rng.randf_range(-56, 56))
		if absf(p.z) < 4.5 or absf(p.x + 14.0) < 3.5 or p.distance_to(Vector3(-62, 0, 0)) < 5.0:
			continue
		var ok: bool = true
		for o in occupied:
			if Vector2(p.x - o[0].x, p.z - o[0].z).length() < float(o[1]) + 2.0:
				ok = false
				break
		if ok:
			_tree(p)
			placed += 1

func _tree(p: Vector3) -> void:
	if rng.randf() < 0.55:
		birch(p)
	else:
		spruce(p)

func random_spawn(from: Vector3) -> Vector3:
	for i in 40:
		var p: Vector3 = Vector3(rng.randf_range(-66, 66), 0.6, rng.randf_range(-54, 54))
		var dpl: float = Vector2(p.x - from.x, p.z - from.z).length()
		if dpl < 22.0 or dpl > 75.0:
			continue
		var ok: bool = true
		for o in occupied:
			if Vector2(p.x - o[0].x, p.z - o[0].z).length() < float(o[1]) + 1.0:
				ok = false
				break
		if ok:
			return p
	return Vector3(40, 0.6, 0)

func smoke(parent: Node3D, pos: Vector3) -> void:
	var p: CPUParticles3D = CPUParticles3D.new()
	p.position = pos
	p.amount = 10
	p.lifetime = 4.0
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = 0.2
	p.direction = Vector3.UP
	p.spread = 12.0
	p.initial_velocity_min = 0.7
	p.initial_velocity_max = 1.1
	p.gravity = Vector3(0.4, 0.1, 0.0)
	var sm: SphereMesh = SphereMesh.new()
	sm.radius = 0.35
	sm.height = 0.7
	sm.radial_segments = 8
	sm.rings = 4
	var m: StandardMaterial3D = StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.material = m
	p.mesh = sm
	var g: Gradient = Gradient.new()
	g.set_color(0, Color(0.85, 0.85, 0.85, 0.55))
	g.set_color(1, Color(0.7, 0.7, 0.7, 0.0))
	p.color_ramp = g
	var c: Curve = Curve.new()
	c.add_point(Vector2(0.0, 0.6))
	c.add_point(Vector2(1.0, 2.2))
	p.scale_amount_curve = c
	parent.add_child(p)

func kiosk(pos: Vector3, rot: float) -> void:
	var b: StaticBody3D = body_at(pos, rot)
	var wood: Material = mat("planks", Color(0.85, 0.7, 0.5), 0.6)
	var logs: Material = mat("logs", Color(0.9, 0.8, 0.7), 0.6)
	add_box(b, Vector3(0, 0.1, 0), Vector3(4.2, 0.2, 3.4), mat("stone", Color.WHITE, 0.5))
	add_box(b, Vector3(0, 1.5, -1.5), Vector3(4.0, 2.6, 0.2), logs)
	add_box(b, Vector3(-1.9, 1.5, -0.1), Vector3(0.2, 2.6, 3.0), logs)
	add_box(b, Vector3(1.9, 1.5, -0.1), Vector3(0.2, 2.6, 3.0), logs)
	add_box(b, Vector3(0, 0.7, 1.1), Vector3(4.0, 1.0, 0.7), wood)
	add_box(b, Vector3(0, 1.22, 1.1), Vector3(4.3, 0.08, 0.95), mat("planks", Color(1.0, 0.9, 0.75), 0.5))
	add_box(b, Vector3(0, 2.9, 0), Vector3(4.4, 0.18, 3.6), mat("roof", Color.WHITE, 0.4))
	for i in 8:
		var col: Color = Color(0.85, 0.15, 0.15) if i % 2 == 0 else Color(0.96, 0.96, 0.96)
		add_box(b, Vector3(-1.925 + float(i) * 0.55, 2.55, 2.1), Vector3(0.55, 0.06, 1.1), cmat(col), Vector3(25, 0, 0))
	add_box(b, Vector3(-1.4, 1.45, 1.1), Vector3(0.55, 0.35, 0.32), cmat(Color(0.8, 0.55, 0.25)))
	add_box(b, Vector3(-0.7, 1.45, 1.1), Vector3(0.55, 0.35, 0.32), cmat(Color(0.75, 0.5, 0.22)))
	add_cyl(b, Vector3(1.0, 1.45, 1.1), 0.12, 0.12, 0.45, cmat(Color(0.3, 0.6, 0.35)), 10)
	add_cyl(b, Vector3(1.4, 1.45, 1.1), 0.12, 0.12, 0.45, cmat(Color(0.9, 0.9, 0.85)), 10)
	add_box(b, Vector3(0, 3.5, 1.7), Vector3(3.8, 0.75, 0.12), cmat(Color(0.12, 0.3, 0.6)))
	var board: Label3D = Label3D.new()
	board.text = "МАГАЗИН У НИНЫ"
	board.font_size = 56
	board.pixel_size = 0.0095
	board.modulate = Color(1, 0.95, 0.7)
	board.outline_size = 10
	board.outline_modulate = Color(0, 0, 0)
	board.position = Vector3(0, 3.5, 1.78)
	b.add_child(board)
	var nina: Sprite3D = Sprite3D.new()
	nina.texture = load("res://assets/stickers/a03.png")
	nina.pixel_size = 0.0075
	nina.billboard = BaseMaterial3D.BILLBOARD_FIXED_Y
	nina.shaded = false
	nina.double_sided = true
	nina.alpha_cut = SpriteBase3D.ALPHA_CUT_OPAQUE_PREPASS
	nina.position = Vector3(0, 1.15, -0.5)
	b.add_child(nina)
	var nm: Label3D = Label3D.new()
	nm.text = "Нина"
	nm.font_size = 48
	nm.pixel_size = 0.008
	nm.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	nm.modulate = Color(1, 0.85, 0.3)
	nm.outline_size = 10
	nm.outline_modulate = Color(0, 0, 0)
	nm.position = Vector3(0, 2.35, -0.5)
	b.add_child(nm)
	add_col(b, Vector3(0, 1.5, -1.5), Vector3(4.0, 3.0, 0.3))
	add_col(b, Vector3(-1.9, 1.5, -0.1), Vector3(0.3, 3.0, 3.0))
	add_col(b, Vector3(1.9, 1.5, -0.1), Vector3(0.3, 3.0, 3.0))
	add_col(b, Vector3(0, 0.7, 1.1), Vector3(4.3, 1.4, 0.95))
	nina_pos = b.global_transform * Vector3(0, 1.4, -0.5)
	occupy(pos, 4.5)

func random_free() -> Vector3:
	for i in 60:
		var p: Vector3 = Vector3(rng.randf_range(-72, 72), 0.0, rng.randf_range(-56, 56))
		var ok: bool = true
		for o in occupied:
			if Vector2(p.x - o[0].x, p.z - o[0].z).length() < float(o[1]) + 1.2:
				ok = false
				break
		if ok and p.distance_to(Vector3(-62, 0, 0)) > 6.0:
			return p
	return Vector3(0, 0, 10)

func wood_pile(pos: Vector3) -> Node3D:
	var n: Node3D = Node3D.new()
	n.position = pos
	n.rotation_degrees = Vector3(0, rng.randf_range(0, 360), 0)
	var lm: Material = mat("logs", Color(1.0, 0.9, 0.8), 0.9)
	for i in 3:
		var c: MeshInstance3D = add_cyl(n, Vector3(0.0, 0.14 + float(i / 2) * 0.24, float(i % 2) * 0.28 - 0.14), 0.14, 0.14, 1.1, lm, 8)
		c.rotation_degrees = Vector3(0, 0, 90)
	var mk: Node3D = Node3D.new()
	mk.name = "mk"
	mk.position = Vector3(0, 1.7, 0)
	n.add_child(mk)
	var cone: MeshInstance3D = add_cyl(mk, Vector3.ZERO, 0.0, 0.28, 0.5, cmat(Color(1.0, 0.85, 0.2), true), 8)
	cone.rotation_degrees = Vector3(180, 0, 0)
	add_child(n)
	return n

func spawn_truck(pos: Vector3, rot: float) -> StaticBody3D:
	var b: StaticBody3D = body_at(pos, rot)
	var green: Material = cmat(Color(0.2, 0.42, 0.3))
	var dark: Material = cmat(Color(0.12, 0.12, 0.13))
	var glass: Material = cmat(Color(0.55, 0.78, 0.95))
	var wood: Material = mat("planks", Color(0.9, 0.75, 0.55), 0.6)
	add_box(b, Vector3(0, 0.7, 0), Vector3(7.4, 0.3, 2.0), dark)
	add_box(b, Vector3(1.7, 1.85, 0), Vector3(1.8, 1.7, 2.1), green)
	add_box(b, Vector3(2.62, 2.1, 0), Vector3(0.06, 0.8, 1.8), glass)
	add_box(b, Vector3(1.7, 1.3, 1.07), Vector3(1.2, 0.5, 0.06), green)
	add_box(b, Vector3(3.3, 1.45, 0), Vector3(1.4, 0.9, 2.0), green)
	add_box(b, Vector3(4.02, 1.4, 0), Vector3(0.06, 0.6, 1.4), dark)
	add_box(b, Vector3(4.03, 1.5, 0.7), Vector3(0.08, 0.22, 0.3), cmat(Color(1.0, 0.95, 0.6), true))
	add_box(b, Vector3(4.03, 1.5, -0.7), Vector3(0.08, 0.22, 0.3), cmat(Color(1.0, 0.95, 0.6), true))
	add_box(b, Vector3(4.12, 0.8, 0), Vector3(0.2, 0.25, 2.2), cmat(Color(0.75, 0.75, 0.78)))
	add_box(b, Vector3(-1.4, 0.98, 0), Vector3(4.4, 0.12, 2.2), wood)
	add_box(b, Vector3(-1.4, 1.5, 1.05), Vector3(4.4, 0.95, 0.1), wood)
	add_box(b, Vector3(-1.4, 1.5, -1.05), Vector3(4.4, 0.95, 0.1), wood)
	add_box(b, Vector3(-3.55, 1.5, 0), Vector3(0.1, 0.95, 2.2), wood)
	add_box(b, Vector3(0.75, 1.65, 0), Vector3(0.1, 1.25, 2.2), wood)
	for wp in [Vector3(3.0, 0.55, 1.0), Vector3(3.0, 0.55, -1.0), Vector3(-0.9, 0.55, 1.0), Vector3(-0.9, 0.55, -1.0), Vector3(-2.5, 0.55, 1.0), Vector3(-2.5, 0.55, -1.0)]:
		var w: MeshInstance3D = add_cyl(b, wp, 0.55, 0.55, 0.4, dark, 14)
		w.rotation_degrees = Vector3(90, 0, 0)
	add_col(b, Vector3(-1.4, 1.2, 0), Vector3(4.4, 1.6, 2.2))
	add_col(b, Vector3(2.4, 1.3, 0), Vector3(3.4, 2.2, 2.1))
	var arrow: MeshInstance3D = add_cyl(b, Vector3(1.7, 4.3, 0), 0.0, 0.45, 0.8, cmat(Color(1.0, 0.85, 0.2), true), 8)
	arrow.rotation_degrees = Vector3(180, 0, 0)
	occupy(pos, 6.0)
	return b

func truck_add_log(b: Node3D, n: int) -> void:
	var lay: int = n / 8
	var idx: int = n % 8
	var c: MeshInstance3D = add_cyl(b, Vector3(-3.1 + float(idx) * 0.5 + float(lay % 2) * 0.25, 1.2 + float(lay) * 0.26, 0.0), 0.14, 0.14, 1.9, mat("logs", Color(1.0, 0.9, 0.8), 0.9), 8)
	c.rotation_degrees = Vector3(90, 0, 0)
