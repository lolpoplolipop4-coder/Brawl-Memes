extends Node3D
# Simple internet/LAN multiplayer deathmatch over ENet (host = peer 1).
# Every player simulates their own character; shots are hitscan on the shooter's side,
# the victim applies damage; the host keeps the score and ends the match.
const KILL_LIMIT: int = 10
const MATCH_TIME: float = 300.0

var b = null
var proxies: Dictionary = {}
var scores: Dictionary = {}
var send_t: float = 0.0
var start_t: float = 0.0
var match_t: float = MATCH_TIME
var ended: bool = false

func setup(battle) -> void:
	b = battle
	for id in Game.mp_roster.keys():
		scores[int(id)] = 0
		if int(id) != multiplayer.get_unique_id():
			_make_proxy(int(id))

func _make_proxy(id: int) -> void:
	var info: Dictionary = Game.mp_roster[id]
	var n: CharacterBody3D = CharacterBody3D.new()
	n.collision_layer = 2
	n.collision_mask = 0
	var cs: CollisionShape3D = CollisionShape3D.new()
	var cap: CapsuleShape3D = CapsuleShape3D.new()
	cap.radius = 0.55
	cap.height = 1.9
	cs.shape = cap
	cs.position = Vector3(0, 0.95, 0)
	n.add_child(cs)
	n.set_meta("peer", id)
	var cid: String = str(info["char"])
	if not Game.by_id.has(cid):
		cid = "a03"
	var spr: Sprite3D = Sprite3D.new()
	spr.texture = load(Game.by_id[cid]["tex"])
	spr.pixel_size = 0.0085
	spr.billboard = BaseMaterial3D.BILLBOARD_FIXED_Y
	spr.shaded = false
	spr.double_sided = true
	spr.alpha_cut = SpriteBase3D.ALPHA_CUT_OPAQUE_PREPASS
	spr.position = Vector3(0, 1.1, 0)
	n.add_child(spr)
	var lb: Label3D = Label3D.new()
	lb.text = str(info["name"])
	lb.font_size = 40
	lb.pixel_size = 0.008
	lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lb.outline_size = 10
	lb.modulate = Color(0.6, 1.0, 0.6)
	lb.position = Vector3(0, 2.5, 0)
	n.add_child(lb)
	b.add_child(n)
	n.position = Vector3(0, -50, 0)
	proxies[id] = {"n": n, "tp": Vector3(0, -50, 0), "alive": true, "seen": false}

func _process(delta: float) -> void:
	if b == null or ended:
		return
	start_t += delta
	for id in proxies.keys():
		var p: Dictionary = proxies[id]
		var n: CharacterBody3D = p["n"]
		var tp: Vector3 = p["tp"]
		if not bool(p["seen"]):
			n.position = tp
		else:
			n.position = n.position.lerp(tp, 0.35)
		n.visible = bool(p["alive"]) and bool(p["seen"])
		n.collision_layer = 2 if bool(p["alive"]) else 0
	if start_t < 1.5:
		return
	send_t += delta
	if send_t >= 0.05:
		send_t = 0.0
		rpc("remote_state", b.player.global_position, not b.mp_dead)
	if multiplayer.is_server():
		match_t -= delta
		if match_t <= 0.0:
			rpc("end_match", scores)
	else:
		match_t = maxf(0.0, match_t - delta)

func info_text() -> String:
	var ids: Array = scores.keys()
	ids.sort_custom(func(a, b2): return int(scores[a]) > int(scores[b2]))
	var s: String = "МУЛЬТИПЛЕЕР | до %d убийств | осталось %d с\n" % [KILL_LIMIT, int(match_t)]
	for id in ids:
		var nm: String = str(Game.mp_roster[id]["name"]) if Game.mp_roster.has(id) else "?"
		var me: String = " (ты)" if int(id) == multiplayer.get_unique_id() else ""
		s += "%s%s: %d\n" % [nm, me, int(scores[id])]
	return s

func sync_roster() -> void:
	for id in proxies.keys():
		if not Game.mp_roster.has(id):
			(proxies[id]["n"] as Node).queue_free()
			proxies.erase(id)

func leave() -> void:
	ended = true
	Game.mp_leave()

# ---------- RPCs ----------
@rpc("any_peer", "call_remote", "unreliable")
func remote_state(pos: Vector3, alive: bool) -> void:
	var id: int = multiplayer.get_remote_sender_id()
	if not proxies.has(id):
		return
	var p: Dictionary = proxies[id]
	p["tp"] = pos
	p["alive"] = alive
	p["seen"] = true

@rpc("any_peer", "call_remote", "unreliable")
func remote_shot(from: Vector3, to: Vector3, pitch: float) -> void:
	if b == null:
		return
	b._tracer(from, to, Color(1.0, 0.6, 0.3))
	if b.player.global_position.distance_to(from) < 70.0:
		Game.shot(pitch)

@rpc("any_peer", "call_remote", "reliable")
func take_hit(dmg: float, shooter: int) -> void:
	if b == null or ended:
		return
	if multiplayer.get_remote_sender_id() != shooter:
		return
	b._mp_take_hit(dmg, shooter)

@rpc("any_peer", "call_remote", "reliable")
func report_death(killer: int) -> void:
	if not multiplayer.is_server():
		return
	register_kill(killer, multiplayer.get_remote_sender_id())

func register_kill(killer: int, victim: int) -> void:
	if not multiplayer.is_server() or ended:
		return
	if scores.has(killer) and killer != victim:
		scores[killer] = int(scores[killer]) + 1
	rpc("sync_scores", scores, killer, victim)
	if scores.has(killer) and int(scores[killer]) >= KILL_LIMIT:
		rpc("end_match", scores)

@rpc("authority", "call_local", "reliable")
func sync_scores(sc: Dictionary, killer: int, victim: int) -> void:
	scores = sc
	if b == null:
		return
	var kn: String = str(Game.mp_roster[killer]["name"]) if Game.mp_roster.has(killer) else "кто-то"
	var vn: String = str(Game.mp_roster[victim]["name"]) if Game.mp_roster.has(victim) else "кто-то"
	b._toast("%s убил %s" % [kn, vn])

@rpc("authority", "call_local", "reliable")
func end_match(sc: Dictionary) -> void:
	if ended:
		return
	scores = sc
	ended = true
	if b != null:
		b._mp_finish(sc)
